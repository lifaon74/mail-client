/** TYPES **/

export type InferEmailHeaderGKey<GEmailHeader extends IGenericEmailHeader> =
  GEmailHeader extends EmailHeader<infer GKey>
    ? GKey
    : never;

export type IGenericEmailHeader = EmailHeader<string>;

/** CLASS **/

export class EmailHeader<GKey extends string> {
  static parse<GKey extends string>(
    input: string,
  ): EmailHeader<GKey> {
    const index: number = input.indexOf(': ');

    // TODO improve parsing
    // TODO handle index === -1

    return new EmailHeader<GKey>(
      input.slice(0, index) as GKey,
      input.slice(index + 2),
    );
  }

  readonly #key!: GKey;
  #value!: string;

  constructor(
    key: GKey,
    value: string,
  ) {
    this.#key = key;
    this.value = value;
  }

  get key(): GKey {
    return this.#key;
  }

  get value(): string {
    return this.#value;
  }

  set value(
    value: string,
  ) {
    this.#value = value;
  }

  toString(): string {
    return `${this.key}: ${this.value}`;
  }
}
