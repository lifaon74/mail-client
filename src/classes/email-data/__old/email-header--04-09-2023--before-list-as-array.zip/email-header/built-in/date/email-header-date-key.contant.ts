export const EMAIL_HEADER_DATE_KEY = 'Date';

export type IEmailHeaderDateKey = typeof EMAIL_HEADER_DATE_KEY;
