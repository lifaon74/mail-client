import { formatDateToEmailDataDateHeader } from './functions/format-date-to-email-data-date-header';
import { EMAIL_HEADER_DATE_KEY, IEmailHeaderDateKey } from './email-header-date-key.contant';
import { convertEmailDataDateHeaderToDate } from './functions/convert-email-data-date-header-to-date';
import { EmailHeader } from '../../email-header.class';

/** TYPES **/

export type IEmailHeaderDateLike =
  | Date
  | string
  ;

/** CLASS **/

export class EmailHeaderDate extends EmailHeader<IEmailHeaderDateKey> {
  static now(): EmailHeaderDate {
    return new EmailHeaderDate(new Date());
  }

  constructor(
    input: IEmailHeaderDateLike,
  ) {
    super(
      EMAIL_HEADER_DATE_KEY,
      (typeof input === 'string')
        ? input
        : formatDateToEmailDataDateHeader(input),
    );
  }

  get date(): Date {
    return convertEmailDataDateHeaderToDate(this.value);
  }

  set date(
    input: Date,
  ) {
    this.value = formatDateToEmailDataDateHeader(input);
  }
}
