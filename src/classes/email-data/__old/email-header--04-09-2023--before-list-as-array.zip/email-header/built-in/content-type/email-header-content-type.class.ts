import { IEmailHeaderContentTypeKey, EMAIL_HEADER_CONTENT_TYPE_KEY } from './email-header-content-type-key.contant';
import { EmailHeader } from '../../email-header.class';
import { MimeTypeClass } from '../../../../mime-type/mime-type.class';

export class EmailHeaderContentType extends EmailHeader<IEmailHeaderContentTypeKey> {
  constructor(
    mimeType: MimeTypeClass | string,
  ) {
    super(
      EMAIL_HEADER_CONTENT_TYPE_KEY,
      (typeof mimeType === 'string')
        ? mimeType
        : mimeType.toString(),
    );
  }

  get mimeType(): MimeTypeClass {
    return MimeTypeClass.parse(this.value);
  }

  set mimeType(
    mimeType: MimeTypeClass,
  ) {
    this.value = mimeType.toString();
  }
}
