export const EMAIL_HEADER_FROM_KEY = 'From';

export type IEmailHeaderFromKey = typeof EMAIL_HEADER_FROM_KEY;

