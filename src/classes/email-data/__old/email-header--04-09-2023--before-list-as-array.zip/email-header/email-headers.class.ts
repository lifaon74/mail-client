import { CRLF } from '../../../constants/crlf';
import { EmailHeader, IGenericEmailHeader } from './email-header.class';
import { iterableToArray } from '../../../misc/iterable-to-array';

/** TYPES **/

export type IEmailHeaderTuple = [
  key: string,
  value: string,
];

export type InferEmailHeadersGetReturn<GHeader extends IGenericEmailHeader, GKey extends string> =
  GHeader extends EmailHeader<infer GValue>
    ? (
      Lowercase<GValue> extends Lowercase<GKey>
        ? GHeader | undefined
        : (
          string extends GValue
            ? EmailHeader<GKey> | undefined
            : undefined
          )
      )
    : never
  ;

export type IGenericEmailHeaders = EmailHeaders<IGenericEmailHeader>;

/** CLASS **/

export class EmailHeaders<GHeader extends IGenericEmailHeader> {
  static parse(
    input: string,
  ): IGenericEmailHeaders {
    const headers: string[] = [];

    const appendLine = (
      line: string,
    ): void => {
      if (
        line.startsWith(' ')
        || line.startsWith('\t')
      ) {
        if (headers.length === 0) {
          throw new Error(`Not an header list`);
        } else {
          headers[headers.length - 1] += line;
        }
      } else {
        headers.push(line);
      }
    };

    let position: number = 0;

    while (true) {
      const index: number = input.indexOf(CRLF, position);
      if (index === -1) {
        appendLine(input.slice(position));
        break;
      } else {
        appendLine(input.slice(position, index));
        position = index + 2;
      }
    }

    return new EmailHeaders<IGenericEmailHeader>(
      headers.map((header: string): IGenericEmailHeader => {
        return EmailHeader.parse(header);
      }),
    );
  }

  static fromTuples<GHeader extends IGenericEmailHeader = IGenericEmailHeader>(
    tuples: Iterable<IEmailHeaderTuple>,
  ): EmailHeaders<GHeader> {
    return new EmailHeaders<GHeader>(
      iterableToArray(tuples).map(([key, value]): GHeader => {
        return new EmailHeader<any>(key, value) as GHeader;
      }),
    );
  }

  readonly #headers: Map<string, GHeader>;

  constructor(
    headers: Iterable<GHeader> = [],
  ) {
    this.#headers = new Map<string, GHeader>();

    const iterator: Iterator<GHeader> = headers[Symbol.iterator]();
    let result: IteratorResult<GHeader>;
    while (!(result = iterator.next()).done) {
      this.set(result.value);
    }
  }

  get size(): number {
    return this.#headers.size;
  }

  has(
    key: string,
  ): boolean {
    return this.#headers.has(key);
  }

  get<GKey extends string>(
    key: GKey,
  ): InferEmailHeadersGetReturn<GHeader, GKey> {
    return this.#headers.get(key.toLowerCase()) as InferEmailHeadersGetReturn<GHeader, GKey>;
  }

  set(
    header: GHeader,
  ): void {
    this.#headers.set(
      header.key.toLowerCase(),
      header,
    );
  }

  delete<GKey extends string>(
    key: GKey,
  ): boolean {
    return this.#headers.delete(key.toLowerCase());
  }

  clear(): void {
    this.#headers.clear();
  }

  values(): IterableIterator<GHeader> {
    return this.#headers.values();
  }

  [Symbol.iterator](): IterableIterator<GHeader> {
    return this.values();
  }

  toString(): string {
    let output: string = '';

    const iterator: Iterator<GHeader> = this.values();
    let result: IteratorResult<GHeader>;
    while (!(result = iterator.next()).done) {

      if (output !== '') {
        output += CRLF;
      }

      output += result.value.toString();
    }

    return output;
  }
}
