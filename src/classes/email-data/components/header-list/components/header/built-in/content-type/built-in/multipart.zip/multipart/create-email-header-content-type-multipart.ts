import { createMimeTypeMultipart } from '../../../../../../../../../mime-type/built-in/multipart/create-mime-type-multipart';
import {
  IMimeTypeParameterList,
} from '../../../../../../../../../mime-type/components/mime-type-parameter-list/mime-type-parameter-list.type';
import { createEmailHeaderContentType } from '../../create-email-header-content-type';
import { IEmailHeaderContentType } from '../../email-header-content-type.type';

export function createEmailHeaderContentTypeMultipart(
  subtype: string,
  parameters?: IMimeTypeParameterList,
): IEmailHeaderContentType {
  return createEmailHeaderContentType(
    createMimeTypeMultipart(
      subtype,
      parameters,
    ),
  );
}
