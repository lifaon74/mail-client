import {
  IMimeTypeParameterList,
} from '../../../../../../../../../mime-type/components/mime-type-parameter-list/mime-type-parameter-list.type';
import { IEmailHeaderContentType } from '../../email-header-content-type.type';
import { createEmailHeaderContentTypeMultipart } from './create-email-header-content-type-multipart';

export function createEmailHeaderContentTypeMultipartAlternative(
  parameters?: IMimeTypeParameterList,
): IEmailHeaderContentType {
  return createEmailHeaderContentTypeMultipart(
    'alternative',
    parameters,
  );
}
