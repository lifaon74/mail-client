import { IMimeTypeParameterList } from '../../components/mime-type-parameter-list/mime-type-parameter-list.type';
import { createMimeTypeFromParts } from '../../create-mime-type';
import { IMimeType } from '../../mime-type.type';

export function createMimeTypeMultipart(
  subtype: string,
  parameters?: IMimeTypeParameterList,
): IMimeType {
  return createMimeTypeFromParts(
    'multipart',
    subtype,
    parameters,
  );
}
