import { IMimeTypeParameterList } from '../../components/mime-type-parameter-list/mime-type-parameter-list.type';
import { IMimeType } from '../../mime-type.type';
import { createMimeTypeMultipart } from './create-mime-type-multipart';

export function createMimeTypeMultipartAlternative(
  parameters?: IMimeTypeParameterList,
): IMimeType {
  return createMimeTypeMultipart(
    'alternative',
    parameters,
  );
}
