export type IByteSequenceLike =
  | Uint8Array
  | string
  | ArrayLike<number>
  | ArrayBufferLike
  ;

export function byteSequenceLikeToUint8Array(
  input: IByteSequenceLike,
): Uint8Array {
  if (input instanceof Uint8Array) {
    return input;
  } else if (typeof input === 'string') {
    return new TextEncoder().encode(input);
  } else {
    return new Uint8Array(input);
  }
}
