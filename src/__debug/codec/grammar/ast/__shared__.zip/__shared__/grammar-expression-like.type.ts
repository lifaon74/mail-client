import { IGrammarExpressionAstNode, isGrammarExpressionAstNode } from '../grammar-expression/grammar-expression-ast-node.type';
import { IGrammarRuleAstNode, isGrammarRuleAstNode } from '../grammar-rule/grammar-rule-ast-node.type';
import { GrammarRuleIdentifier } from '../grammar-rule-identifier/grammar-rule-identifier';
import { IByteSequenceLike } from './byte-sequence-like.type';
import { isObject } from '@lirx/utils';

export type IGrammarExpressionLike =
  | IGrammarExpressionAstNode
  | IGrammarRuleAstNode
  | IByteSequenceLike
  ;

export function grammarExpressionLikeToExpression(
  input: IGrammarExpressionLike,
): IGrammarExpressionAstNode {
  if (isObject(input)) {
    if (isGrammarExpressionAstNode(input)) {
      return input;
    } else if (isGrammarRuleAstNode(input)) {
      return GrammarRuleIdentifier(input.name);
    }
  }

  throw 'TODO';
  // return GrammarByteSequenceLike(input);
}

export type IGrammarExpressionLikeList = readonly IGrammarExpressionLike[];

export function grammarExpressionLikeListToExpressionList(
  input: IGrammarExpressionLikeList,
): IGrammarExpressionAstNode[] {
  return input.map(grammarExpressionLikeToExpression);
}
