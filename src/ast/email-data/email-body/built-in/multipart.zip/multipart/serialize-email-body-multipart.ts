import { IEmailBodyMultipartAstNode } from './email-body-multipart-ast-node.type';
import { isEmailBodyMultipartAlternativeAstNode } from './alternative/email-body-multipart-alternative-ast-node.type';
import { serializeEmailBodyMultipartAlternative } from './alternative/serialize-email-body-multipart-alternative';

/** FUNCTION **/

export function serializeEmailBodyMultipart(
  node: IEmailBodyMultipartAstNode,
): string {
  if (isEmailBodyMultipartAlternativeAstNode(node)) {
    return serializeEmailBodyMultipartAlternative(node);
  } else {
    throw new Error(`Unknown type: ${(node as any).__type__}`);
  }
}
