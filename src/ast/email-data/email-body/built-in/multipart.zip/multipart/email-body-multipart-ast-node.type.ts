import { IEmailBodyMultipartAlternativeAstNode, isEmailBodyMultipartAlternativeAstNode } from './alternative/email-body-multipart-alternative-ast-node.type';

/** AST NODE **/

export type IEmailBodyMultipartAstNode =
  | IEmailBodyMultipartAlternativeAstNode
  ;

export function isEmailBodyMultipartAstNode(
  input: object,
): input is IEmailBodyMultipartAstNode {
  return isEmailBodyMultipartAlternativeAstNode(input);
}
