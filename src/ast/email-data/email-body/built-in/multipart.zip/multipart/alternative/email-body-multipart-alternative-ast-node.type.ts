import { IEmailBodySharedAstNode } from '../../__shared__/email-body-shared-ast-node.type';
import { isAstNode } from '../../../../../__shared__/is-ast-node';
import { IEmailDataAstNode } from '../../../../email-data/email-data-ast-node.type';

/** AST NODE **/

export const EmailBodyMultipartAlternativeAstNodeType = 'EmailBodyMultipartAlternative';

export type IEmailBodyMultipartAlternativeAstNodeType = typeof EmailBodyMultipartAlternativeAstNodeType;

export interface IEmailBodyMultipartAlternativeAstNode extends IEmailBodySharedAstNode<IEmailBodyMultipartAlternativeAstNodeType> {
  readonly value: string;
  readonly parts: readonly IEmailDataAstNode[];
}

export function isEmailBodyMultipartAlternativeAstNode(
  input: object,
): input is IEmailBodyMultipartAlternativeAstNode {
  return isAstNode<IEmailBodyMultipartAlternativeAstNodeType>(input, EmailBodyMultipartAlternativeAstNodeType);
}
