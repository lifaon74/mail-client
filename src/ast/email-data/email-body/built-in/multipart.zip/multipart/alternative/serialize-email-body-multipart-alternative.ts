import { IEmailBodyMultipartAlternativeAstNode } from './email-body-multipart-alternative-ast-node.type';

/** FUNCTION **/

export function serializeEmailBodyMultipartAlternative(
  {
    value,
  }: IEmailBodyMultipartAlternativeAstNode,
): string {
  // TODO support various encodings
  return value;
}
