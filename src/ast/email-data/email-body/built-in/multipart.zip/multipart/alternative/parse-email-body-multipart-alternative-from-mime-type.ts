import { IEmailBodyMultipartAlternativeAstNode, EmailBodyMultipartAlternativeAstNodeType } from './email-body-multipart-alternative-ast-node.type';
import {
  IContentTransferEncoding,
} from '../../../../../email-header/email-header/built-in/content-transfer-encoding/content-transfer-encoding.type';
import { IMimeTypeAstNode } from '../../../../../mime-type/mime-type-ast-node.type';
import {
  IMimeTypeParameterAstNode
} from '../../../../../mime-type/fragments/mime-type-parameter-list/fragments/mime-type-parameter/mime-type-parameter-ast-node.type';
import { serializeMimeType } from '../../../../../mime-type/serialize-mime-type';
import { CRLF } from '../../../../../../constants/crlf';

/** FUNCTION **/

export function parseEmailBodyMultipartAlternativeFromMimeType(
  input: string,
  mimeType: IMimeTypeAstNode,
): IEmailBodyMultipartAlternativeAstNode {
  const boundaryMimeTypeParameterAstNode: IMimeTypeParameterAstNode | undefined = mimeType.parameters.items.find((parameter: IMimeTypeParameterAstNode): boolean => {
    return parameter.key.value === 'boundary';
  });

  if (boundaryMimeTypeParameterAstNode === void 0) {
    throw new Error(`Missing boundary in mimeType: ${serializeMimeType(mimeType)}`);
  } else {
    const boundary: string = boundaryMimeTypeParameterAstNode!.value.value;
    const boundaryPrefixed: string = `--${boundary}`;

    const parts: string[] = input.split(`--${boundary}${CRLF}`);
    console.log(parts);

    return {
      __type__: EmailBodyMultipartAlternativeAstNodeType,
      value: input,
    };
  }
}
