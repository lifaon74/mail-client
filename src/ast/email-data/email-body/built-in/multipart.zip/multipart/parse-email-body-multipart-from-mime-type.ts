import { IEmailBodyMultipartAstNode } from './email-body-multipart-ast-node.type';
import { IMimeTypeAstNode } from '../../../../mime-type/mime-type-ast-node.type';
import { parseEmailBodyMultipartAlternativeFromMimeType } from './alternative/parse-email-body-multipart-alternative-from-mime-type';

/** FUNCTION **/

export function parseEmailBodyMultipartFromMimeType(
  input: string,
  mimeType: IMimeTypeAstNode,
): IEmailBodyMultipartAstNode {
  const subtype: string = mimeType.subtype.value;
  if (subtype === 'alternative') {
    return parseEmailBodyMultipartAlternativeFromMimeType(
      input,
      mimeType,
    );
  } else {
    throw new Error(`Unknown subtype: ${subtype}`);
  }
}
