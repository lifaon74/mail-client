import { IEmailBodyTextPlainAstNode, isEmailBodyTextPlainAstNode } from './plain/email-body-text-plain-ast-node.type';
import { IEmailBodyTextHtmlAstNode, isEmailBodyTextHtmlAstNode } from './html/email-body-text-html-ast-node.type';

/** AST NODE **/

export type IEmailBodyTextAstNode =
  | IEmailBodyTextPlainAstNode
  | IEmailBodyTextHtmlAstNode
  ;

export function isEmailBodyTextAstNode(
  input: object,
): input is IEmailBodyTextAstNode {
  return isEmailBodyTextPlainAstNode(input)
    || isEmailBodyTextHtmlAstNode(input)
    ;
}
