import { IEmailBodyTextPlainAstNode } from './email-body-text-plain-ast-node.type';

/** FUNCTION **/

export function serializeEmailBodyTextPlain(
  {
    value,
  }: IEmailBodyTextPlainAstNode,
): string {
  // TODO support various encodings
  return value;
}
