import { IEmailBodyTextPlainAstNode, EmailBodyTextPlainAstNodeType } from './email-body-text-plain-ast-node.type';
import {
  IContentTransferEncoding,
} from '../../../../../email-header/email-header/built-in/content-transfer-encoding/content-transfer-encoding.type';
import { IMimeTypeAstNode } from '../../../../../mime-type/mime-type-ast-node.type';
import { CRLF } from '../../../../../../constants/crlf';
import {
  IMimeTypeParameterAstNode,
} from '../../../../../mime-type/fragments/mime-type-parameter-list/fragments/mime-type-parameter/mime-type-parameter-ast-node.type';

/** FUNCTION **/

export function parseEmailBodyTextPlainFromMimeTypeAndContentTransferEncoding(
  input: string,
  mimeType: IMimeTypeAstNode,
  contentTransferEncoding: IContentTransferEncoding,
): IEmailBodyTextPlainAstNode {
  const charsetMimeTypeParameterAstNode: IMimeTypeParameterAstNode | undefined = mimeType.parameters.items.find((parameter: IMimeTypeParameterAstNode): boolean => {
    return parameter.key.value === 'charset';
  });

  const charset: string = (charsetMimeTypeParameterAstNode === void 0)
    ? 'utf-8'
    : charsetMimeTypeParameterAstNode!.value.value.toLowerCase();

  let value: string;

  if (
    (contentTransferEncoding === '7bit')
    || (contentTransferEncoding === '8bit')
    || (contentTransferEncoding === 'binary')
  ) {
    // TODO support multiline
    // TODO support different charset

  } else if (contentTransferEncoding === 'base64') {
    const data: string = atob(input.replace(new RegExp(CRLF, 'g'), ''));
    return {
      __type__: EmailBodyTextPlainAstNodeType,
      encoding: contentTransferEncoding,
      value: input,
    };
  } else {
    throw new Error(`Unknown contentTransferEncoding: ${contentTransferEncoding}`);
  }

  return {
    __type__: EmailBodyTextPlainAstNodeType,
    encoding: contentTransferEncoding,
    value: (charset === 'utf-8') || (charset === 'utf-8'),
  };
}
