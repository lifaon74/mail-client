import { isAstNode } from '../../../../../__shared__/is-ast-node';
import { IEmailBodyTextSharedAstNode } from '../__shared__/email-body-text-shared-ast-node.type';

/** AST NODE **/

export const EmailBodyTextPlainAstNodeType = 'EmailBodyTextPlain';

export type IEmailBodyTextPlainAstNodeType = typeof EmailBodyTextPlainAstNodeType;

export interface IEmailBodyTextPlainAstNode extends IEmailBodyTextSharedAstNode<IEmailBodyTextPlainAstNodeType> {
  readonly value: string;
}

export function isEmailBodyTextPlainAstNode(
  input: object,
): input is IEmailBodyTextPlainAstNode {
  return isAstNode<IEmailBodyTextPlainAstNodeType>(input, EmailBodyTextPlainAstNodeType);
}
