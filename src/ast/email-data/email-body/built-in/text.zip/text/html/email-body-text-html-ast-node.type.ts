import { isAstNode } from '../../../../../__shared__/is-ast-node';
import { IEmailBodyTextSharedAstNode } from '../__shared__/email-body-text-shared-ast-node.type';

/** AST NODE **/

export const EmailBodyTextHtmlAstNodeType = 'EmailBodyTextHtml';

export type IEmailBodyTextHtmlAstNodeType = typeof EmailBodyTextHtmlAstNodeType;

export interface IEmailBodyTextHtmlAstNode extends IEmailBodyTextSharedAstNode<IEmailBodyTextHtmlAstNodeType> {
  readonly value: string;
}

export function isEmailBodyTextHtmlAstNode(
  input: object,
): input is IEmailBodyTextHtmlAstNode {
  return isAstNode<IEmailBodyTextHtmlAstNodeType>(input, EmailBodyTextHtmlAstNodeType);
}
