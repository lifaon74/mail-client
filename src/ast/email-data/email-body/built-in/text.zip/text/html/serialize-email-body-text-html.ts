import { IEmailBodyTextHtmlAstNode } from './email-body-text-html-ast-node.type';

/** FUNCTION **/

export function serializeEmailBodyTextHtml(
  {
    value,
  }: IEmailBodyTextHtmlAstNode,
): string {
  // TODO support various encodings
  return value;
}
