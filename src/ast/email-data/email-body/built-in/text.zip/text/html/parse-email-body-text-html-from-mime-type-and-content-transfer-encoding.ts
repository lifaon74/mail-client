import { IEmailBodyTextHtmlAstNode, EmailBodyTextHtmlAstNodeType } from './email-body-text-html-ast-node.type';
import {
  IContentTransferEncoding,
} from '../../../../../email-header/email-header/built-in/content-transfer-encoding/content-transfer-encoding.type';
import { IMimeTypeAstNode } from '../../../../../mime-type/mime-type-ast-node.type';

/** FUNCTION **/

export function parseEmailBodyTextHtmlFromMimeTypeAndContentTransferEncoding(
  input: string,
  mimeType: IMimeTypeAstNode,
  contentTransferEncoding: IContentTransferEncoding,
): IEmailBodyTextHtmlAstNode {

  if (
    (contentTransferEncoding === '7bit')
    || (contentTransferEncoding === '8bit')
    || (contentTransferEncoding === 'binary')
  ) {
    // TODO support multiline
    // TODO support different charset
    return {
      __type__: EmailBodyTextHtmlAstNodeType,
      encoding: contentTransferEncoding,
      value: input,
    };
  } else if (contentTransferEncoding === 'base64') {
    throw 'TODO'; // TODO
  } else {
    throw new Error(`Unknown contentTransferEncoding: ${contentTransferEncoding}`);
  }
}
