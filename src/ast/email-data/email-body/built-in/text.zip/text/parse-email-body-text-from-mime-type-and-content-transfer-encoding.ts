import { IEmailBodyTextAstNode } from './email-body-text-ast-node.type';
import { IMimeTypeAstNode } from '../../../../mime-type/mime-type-ast-node.type';
import {
  IContentTransferEncoding,
} from '../../../../email-header/email-header/built-in/content-transfer-encoding/content-transfer-encoding.type';
import {
  parseEmailBodyTextPlainFromMimeTypeAndContentTransferEncoding,
} from './plain/parse-email-body-text-plain-from-mime-type-and-content-transfer-encoding';
import {
  parseEmailBodyTextHtmlFromMimeTypeAndContentTransferEncoding
} from './html/parse-email-body-text-html-from-mime-type-and-content-transfer-encoding';

/** FUNCTION **/

export function parseEmailBodyTextFromMimeTypeAndContentTransferEncoding(
  input: string,
  mimeType: IMimeTypeAstNode,
  contentTransferEncoding: IContentTransferEncoding,
): IEmailBodyTextAstNode {
  const subtype: string = mimeType.subtype.value;
  if (subtype === 'plain') {
    return parseEmailBodyTextPlainFromMimeTypeAndContentTransferEncoding(
      input,
      mimeType,
      contentTransferEncoding,
    );
  } else if (subtype === 'html') {
    return parseEmailBodyTextHtmlFromMimeTypeAndContentTransferEncoding(
      input,
      mimeType,
      contentTransferEncoding,
    );
  } else {
    throw new Error(`Unknown subtype: ${subtype}`);
  }
}
