import { IEmailBodySharedAstNode } from '../../__shared__/email-body-shared-ast-node.type';

export interface IEmailBodyTextSharedAstNode<GType extends string> extends IEmailBodySharedAstNode<GType> {
  readonly charset: string;
  readonly encoding: string;
}

