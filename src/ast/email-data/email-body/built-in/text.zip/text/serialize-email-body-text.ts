import { IEmailBodyTextAstNode } from './email-body-text-ast-node.type';
import { isEmailBodyTextPlainAstNode } from './plain/email-body-text-plain-ast-node.type';
import { serializeEmailBodyTextPlain } from './plain/serialize-email-body-text-plain';
import { isEmailBodyTextHtmlAstNode } from './html/email-body-text-html-ast-node.type';
import { serializeEmailBodyTextHtml } from './html/serialize-email-body-text-html';

/** FUNCTION **/

export function serializeEmailBodyText(
  node: IEmailBodyTextAstNode,
): string {
  if (isEmailBodyTextPlainAstNode(node)) {
    return serializeEmailBodyTextPlain(node);
  } else if (isEmailBodyTextHtmlAstNode(node)) {
    return serializeEmailBodyTextHtml(node);
  } else {
    throw new Error(`Unknown type: ${(node as any).__type__}`);
  }
}
