import { IEmailBodyAstNode, EmailBodyAstNodeType } from './email-body-ast-node.type';

/** FUNCTION **/

export function parseEmailBody(
  input: string,
): IEmailBodyAstNode {
  return {
    __type__: EmailBodyAstNodeType,
    value: input,
  };
}
