import { IEmailBodyAstNode } from './email-body-ast-node.type';

/** FUNCTION **/

export function serializeEmailBody(
  {
    value,
  }: IEmailBodyAstNode,
): string {
  return value;
}
