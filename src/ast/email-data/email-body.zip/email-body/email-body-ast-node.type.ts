import { AstNode } from '../../__shared__/ast-node.type';

export const EmailBodyAstNodeType = 'EmailBody';

export type IEmailBodyAstNodeType = typeof EmailBodyAstNodeType;

export interface IEmailBodyAstNode extends AstNode<IEmailBodyAstNodeType> {
  readonly value: string;
}

