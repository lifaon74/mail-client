import { IEmailHeaderAstNode } from './email-header-ast-node.type';
import { serializeEmailHeaderValue } from './value/serialize-email-header-value';

/** FUNCTION **/

export function serializeEmailHeader(
  {
    value,
    key,
  }: IEmailHeaderAstNode,
): string {
  return `${key}: ${serializeEmailHeaderValue(value)}`;
}
