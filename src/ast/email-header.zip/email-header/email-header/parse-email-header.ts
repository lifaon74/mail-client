import { IEmailHeaderAstNode, EmailHeaderAstNodeType } from './email-header-ast-node.type';
import { createEmailHeaderFromKeyValueStrings } from './create/create-email-header-from-key-value-strings';

/** FUNCTION **/

export function parseEmailHeader(
  input: string,
): IEmailHeaderAstNode {
  const index: number = input.indexOf(': ');

  // TODO improve parsing
  if (index === -1) {
    throw new Error(`Invalid ${EmailHeaderAstNodeType}`);
  } else {
    return createEmailHeaderFromKeyValueStrings(
      input.slice(0, index),
      input.slice(index + 2),
    );
  }
}
