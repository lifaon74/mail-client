import { AstNode } from '../../__shared__/ast-node.type';
import { IEmailHeaderValueAstNode } from './value/email-header-value-ast-node.type';

export const EmailHeaderAstNodeType = 'EmailHeader';

export type IEmailHeaderAstNodeType = typeof EmailHeaderAstNodeType;

export interface IEmailHeaderAstNode extends AstNode<IEmailHeaderAstNodeType> {
  readonly key: string;
  readonly value: IEmailHeaderValueAstNode;
}

