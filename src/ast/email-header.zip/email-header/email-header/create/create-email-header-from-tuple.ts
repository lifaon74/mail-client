import { createEmailHeaderFromKeyValueStrings } from './create-email-header-from-key-value-strings';
import { IEmailHeaderAstNode } from '../email-header-ast-node.type';

/** TYPES **/

export type IEmailHeaderTuple = [
  key: string,
  value: string,
];

/** FUNCTION **/

export function createEmailHeaderFromTuple(
  [key, value]: IEmailHeaderTuple,
): IEmailHeaderAstNode {
  return createEmailHeaderFromKeyValueStrings(
    key,
    value,
  );
}
