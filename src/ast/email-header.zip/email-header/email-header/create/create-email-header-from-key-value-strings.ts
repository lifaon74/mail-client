import { EmailHeaderAstNodeType, IEmailHeaderAstNode } from '../email-header-ast-node.type';
import { parseEmailHeaderValue } from '../value/parse-email-header-value';

/** FUNCTION **/

export function createEmailHeaderFromKeyValueStrings(
  key: string,
  value: string,
): IEmailHeaderAstNode {
  return {
    __type__: EmailHeaderAstNodeType,
    key,
    value: parseEmailHeaderValue(
      key,
      value,
    ),
  };
}
