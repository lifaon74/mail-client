import { IEmailHeaderValueAstNode } from './email-header-value-ast-node.type';
import { parseEmailHeaderValueGeneric } from './built-in/generic/parse-email-header-value-generic';
import { parseEmailHeaderValueDate } from './built-in/date/parse-email-header-value-date';
import { parseEmailHeaderValueContentType } from './built-in/content-type/parse-email-header-value-content-type';
import { parseEmailHeaderValueFrom } from './built-in/from/parse-email-header-value-from';

/** FUNCTION **/

export function parseEmailHeaderValue(
  key: string,
  input: string,
): IEmailHeaderValueAstNode {
  if (key === 'Date') {
    return parseEmailHeaderValueDate(input);
  } else if (key === 'Content-Type') {
    return parseEmailHeaderValueContentType(input);
  } else if (key === 'From') {
    return parseEmailHeaderValueFrom(input);
  } else {
    return parseEmailHeaderValueGeneric(input);
  }
}
