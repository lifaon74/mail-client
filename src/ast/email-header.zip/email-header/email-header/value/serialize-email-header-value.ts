import { IEmailHeaderValueAstNode } from './email-header-value-ast-node.type';
import { EmailHeaderValueGenericAstNodeType } from './built-in/generic/email-header-value-generic-ast-node.type';
import { serializeEmailHeaderValueGeneric } from './built-in/generic/serialize-email-header-value-generic';
import { EmailHeaderValueDateAstNodeType } from './built-in/date/email-header-value-date-ast-node.type';
import { serializeEmailHeaderValueDate } from './built-in/date/serialize-email-header-value-date';
import { serializeEmailHeaderValueContentType } from './built-in/content-type/serialize-email-header-value-content-type';
import { EmailHeaderValueContentTypeAstNodeType } from './built-in/content-type/email-header-value-content-type-ast-node.type';
import { serializeEmailHeaderValueFrom } from './built-in/from/serialize-email-header-value-from';
import { EmailHeaderValueFromAstNodeType } from './built-in/from/email-header-value-from-ast-node.type';

/** FUNCTION **/

export function serializeEmailHeaderValue(
  node: IEmailHeaderValueAstNode,
): string {
  if (node.__type__ === EmailHeaderValueGenericAstNodeType) {
    return serializeEmailHeaderValueGeneric(node);
  } else if (node.__type__ === EmailHeaderValueDateAstNodeType) {
    return serializeEmailHeaderValueDate(node);
  } else if (node.__type__ === EmailHeaderValueContentTypeAstNodeType) {
    return serializeEmailHeaderValueContentType(node);
  } else if (node.__type__ === EmailHeaderValueFromAstNodeType) {
    return serializeEmailHeaderValueFrom(node);
  } else {
    throw new Error(`Unknown type: ${(node as any).__type__}`);
  }
}
