import { AstNode } from '../../../../../__shared__/ast-node.type';
import { IMimeTypeAstNode } from '../../../../../mime-type/mime-type-ast-node.type';

export const EmailHeaderValueContentTypeAstNodeType = 'EmailHeaderValueContentType';

export type IEmailHeaderValueContentTypeAstNodeType = typeof EmailHeaderValueContentTypeAstNodeType;

export interface IEmailHeaderValueContentTypeAstNode extends AstNode<IEmailHeaderValueContentTypeAstNodeType> {
  readonly mimeType: IMimeTypeAstNode;
}

