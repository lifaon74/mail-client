import { IEmailHeaderValueContentTypeAstNode, EmailHeaderValueContentTypeAstNodeType } from './email-header-value-content-type-ast-node.type';
import { parseMimeType } from '../../../../../mime-type/parse-mime-type';

/** FUNCTION **/

export function parseEmailHeaderValueContentType(
  input: string,
): IEmailHeaderValueContentTypeAstNode {
  return {
    __type__: EmailHeaderValueContentTypeAstNodeType,
    mimeType: parseMimeType(input),
  };
}
