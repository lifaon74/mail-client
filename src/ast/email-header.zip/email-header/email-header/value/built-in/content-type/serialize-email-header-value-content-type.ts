import { IEmailHeaderValueContentTypeAstNode } from './email-header-value-content-type-ast-node.type';
import { serializeMimeType } from '../../../../../mime-type/serialize-mime-type';

/** FUNCTION **/

export function serializeEmailHeaderValueContentType(
  {
    mimeType,
  }: IEmailHeaderValueContentTypeAstNode,
): string {
  return serializeMimeType(mimeType);
}
