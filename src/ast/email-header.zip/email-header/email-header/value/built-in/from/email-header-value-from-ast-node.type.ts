import { AstNode } from '../../../../../__shared__/ast-node.type';
import { IEmailContactListAstNode } from '../../../../../email-contact/email-contact-list/email-contact-list-ast-node.type';

export const EmailHeaderValueFromAstNodeType = 'EmailHeaderValueFrom';

export type IEmailHeaderValueFromAstNodeType = typeof EmailHeaderValueFromAstNodeType;

export interface IEmailHeaderValueFromAstNode extends AstNode<IEmailHeaderValueFromAstNodeType> {
  readonly contacts: IEmailContactListAstNode;
}

