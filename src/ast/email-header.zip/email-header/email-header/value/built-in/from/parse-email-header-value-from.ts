import { IEmailHeaderValueFromAstNode, EmailHeaderValueFromAstNodeType } from './email-header-value-from-ast-node.type';
import { parseEmailContactList } from '../../../../../email-contact/email-contact-list/parse-email-contact-list';

/** FUNCTION **/

export function parseEmailHeaderValueFrom(
  input: string,
): IEmailHeaderValueFromAstNode {
  return {
    __type__: EmailHeaderValueFromAstNodeType,
    contacts: parseEmailContactList(input),
  };
}
