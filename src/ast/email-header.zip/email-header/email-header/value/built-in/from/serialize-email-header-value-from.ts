import { IEmailHeaderValueFromAstNode } from './email-header-value-from-ast-node.type';
import { serializeEmailContactList } from '../../../../../email-contact/email-contact-list/serialize-email-contact-list';

/** FUNCTION **/

export function serializeEmailHeaderValueFrom(
  {
    contacts,
  }: IEmailHeaderValueFromAstNode,
): string {
  return serializeEmailContactList(contacts);
}
