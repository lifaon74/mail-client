import { IEmailHeaderValueDateAstNode } from './email-header-value-date-ast-node.type';
import { formatDateToEmailDataDateHeader } from './functions/format-date-to-email-data-date-header';

/** FUNCTION **/

export function serializeEmailHeaderValueDate(
  {
    date,
  }: IEmailHeaderValueDateAstNode,
): string {
  return formatDateToEmailDataDateHeader(date);
}
