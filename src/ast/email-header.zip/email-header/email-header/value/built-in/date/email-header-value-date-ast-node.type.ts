import { AstNode } from '../../../../../__shared__/ast-node.type';

export const EmailHeaderValueDateAstNodeType = 'EmailHeaderValueDate';

export type IEmailHeaderValueDateAstNodeType = typeof EmailHeaderValueDateAstNodeType;

export interface IEmailHeaderValueDateAstNode extends AstNode<IEmailHeaderValueDateAstNodeType> {
  readonly date: Date;
}

