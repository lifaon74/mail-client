import { IEmailHeaderValueDateAstNode, EmailHeaderValueDateAstNodeType } from './email-header-value-date-ast-node.type';
import { convertEmailDataDateHeaderToDate } from './functions/convert-email-data-date-header-to-date';

/** FUNCTION **/

export function parseEmailHeaderValueDate(
  input: string,
): IEmailHeaderValueDateAstNode {
  return {
    __type__: EmailHeaderValueDateAstNodeType,
    date: convertEmailDataDateHeaderToDate(input),
  };
}
