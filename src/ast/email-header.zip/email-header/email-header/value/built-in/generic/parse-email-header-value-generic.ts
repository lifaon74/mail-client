import { IEmailHeaderValueGenericAstNode, EmailHeaderValueGenericAstNodeType } from './email-header-value-generic-ast-node.type';

/** FUNCTION **/

export function parseEmailHeaderValueGeneric(
  input: string,
): IEmailHeaderValueGenericAstNode {
  return {
    __type__: EmailHeaderValueGenericAstNodeType,
    value: input,
  };
}
