import { AstNode } from '../../../../../__shared__/ast-node.type';

export const EmailHeaderValueGenericAstNodeType = 'EmailHeaderValueGeneric';

export type IEmailHeaderValueGenericAstNodeType = typeof EmailHeaderValueGenericAstNodeType;

export interface IEmailHeaderValueGenericAstNode extends AstNode<IEmailHeaderValueGenericAstNodeType> {
  readonly value: string;
}

