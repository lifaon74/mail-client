import { IEmailHeaderValueGenericAstNode } from './email-header-value-generic-ast-node.type';

/** FUNCTION **/

export function serializeEmailHeaderValueGeneric(
  {
    value,
  }: IEmailHeaderValueGenericAstNode,
): string {
  return value;
}
