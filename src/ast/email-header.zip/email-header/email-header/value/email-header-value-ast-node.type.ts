import { IEmailHeaderValueGenericAstNode } from './built-in/generic/email-header-value-generic-ast-node.type';
import { IEmailHeaderValueDateAstNode } from './built-in/date/email-header-value-date-ast-node.type';
import { IEmailHeaderValueContentTypeAstNode } from './built-in/content-type/email-header-value-content-type-ast-node.type';
import { IEmailHeaderValueFromAstNode } from './built-in/from/email-header-value-from-ast-node.type';

export type IEmailHeaderValueAstNode =
  | IEmailHeaderValueGenericAstNode
  | IEmailHeaderValueDateAstNode
  | IEmailHeaderValueContentTypeAstNode
  | IEmailHeaderValueFromAstNode
;

