import { IMimeTypeParameterListAstNode } from '../mime-type-parameter-list-ast-node.type';
import { IMimeTypeParameterAstNode } from '../fragments/mime-type-parameter/mime-type-parameter-ast-node.type';
import {
  getMimeTypeParameterIndexFromMimeTypeParameterListAndKey
} from './get-mime-type-parameter-index-from-mime-type-parameter-list-and-key';

/** FUNCTION **/

export function getMimeTypeParameterFromMimeTypeParameterListAndKey(
  ast: IMimeTypeParameterListAstNode,
  key: string,
  fromIndex: number = 0,
): IMimeTypeParameterAstNode | undefined {
  const index: number = getMimeTypeParameterIndexFromMimeTypeParameterListAndKey(ast, key, fromIndex);
  return (index === -1)
    ? void 0
    : ast.items[index];
}
