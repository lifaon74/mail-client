import { IMimeTypeParameterListAstNode } from '../mime-type-parameter-list-ast-node.type';
import { IMimeTypeParameterAstNode } from '../fragments/mime-type-parameter/mime-type-parameter-ast-node.type';

/** FUNCTION **/

export function getMimeTypeParameterIndexFromMimeTypeParameterListAndKey(
  {
    items,
  }: IMimeTypeParameterListAstNode,
  key: string,
  fromIndex: number = 0,
): number {
  for (const l: number = items.length; fromIndex < l; fromIndex++) {
    const parameter: IMimeTypeParameterAstNode = items[fromIndex];
    if (parameter.key.toString() === key) {
      return fromIndex;
    }
  }
  return -1;
}
