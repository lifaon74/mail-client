import { IMimeTypeParameterValueAstNode } from './mime-type-parameter-value-ast-node.type';
import { quoteMimeTypeParameterValue } from './helpers/quote-mime-type-parameter-value';

/** TYPES **/

export type ISerializeMimeTypeParameterValueQuoting =
  // | 'none' // WARNING
  | 'default'
  | 'quoted'
  | 'quoted-if-required'
  ;

export interface ISerializeMimeTypeParameterValueOptions {
  quoting?: ISerializeMimeTypeParameterValueQuoting;
}

/** FUNCTION **/

export function serializeMimeTypeParameterValue(
  {
    value,
    quoting,
  }: IMimeTypeParameterValueAstNode,
  {
    quoting: _quoting = 'quoted-if-required',
  }: ISerializeMimeTypeParameterValueOptions = {},
): string {
  return (
    /*(_quoting === 'none')
    || */(
      (_quoting === 'quoted-if-required')
      && (quoting !== 'yes')
    )
    || (
      (_quoting === 'default')
      && (quoting === 'no')
    )
  )
    ? value
    : quoteMimeTypeParameterValue(value);
  // if (_quoting === 'default') {
  //   if (quoting === 'no') {
  //     return value;
  //   } else {
  //     return quoteMimeTypeParameterValue(value);
  //   }
  // } else if (_quoting === 'quoted') {
  //   return quoteMimeTypeParameterValue(value);
  // } else { // 'quoted-if-required'
  //   if (quoting === 'yes') {
  //     return quoteMimeTypeParameterValue(value);
  //   } else {
  //     return value;
  //   }
  // }
}
