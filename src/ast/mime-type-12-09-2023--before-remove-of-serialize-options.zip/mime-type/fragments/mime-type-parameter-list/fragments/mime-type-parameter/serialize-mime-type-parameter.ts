import { IMimeTypeParameterAstNode } from './mime-type-parameter-ast-node.type';
import { serializeMimeTypeParameterKey } from './fragments/mime-type-parameter-key/serialize-mime-type-parameter-key';
import {
  serializeMimeTypeParameterValue,
  ISerializeMimeTypeParameterValueOptions,
} from './fragments/mime-type-parameter-value/serialize-mime-type-parameter-value';

/** TYPES **/

export interface ISerializeMimeTypeParameterOptions extends ISerializeMimeTypeParameterValueOptions {
}

/** FUNCTION **/

export function serializeMimeTypeParameter(
  {
    value,
    key,
  }: IMimeTypeParameterAstNode,
  options?: ISerializeMimeTypeParameterOptions,
): string {
  return (value.value === '')
    ? serializeMimeTypeParameterKey(key)
    : `${serializeMimeTypeParameterKey(key)}=${serializeMimeTypeParameterValue(value, options)}`;
}
