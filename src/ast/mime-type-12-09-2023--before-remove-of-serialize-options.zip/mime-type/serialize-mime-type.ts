import { serializeMimeTypeParameterList } from './fragments/mime-type-parameter-list/serialize-mime-type-parameter-list';
import { ISerializeMimeTypeParameterOptions } from './fragments/mime-type-parameter-list/fragments/mime-type-parameter/serialize-mime-type-parameter';
import { serializeMimeTypeType } from './fragments/mime-type-type/serialize-mime-type-type';
import { IMimeTypeAstNode } from './mime-type-ast-node.type';
import { serializeMimeTypeSubtype } from './fragments/mime-type-subtype/serialize-mime-type-subtype';

/** FUNCTION **/

export function serializeMimeType(
  {
    type,
    subtype,
    parameters,
  }: IMimeTypeAstNode,
  options?: ISerializeMimeTypeParameterOptions,
): string {
  const parametersString: string = (parameters.items.length === 0)
    ? ''
    : `; ${serializeMimeTypeParameterList(parameters, options)}`;
  return `${serializeMimeTypeType(type)}/${serializeMimeTypeSubtype(subtype)}${parametersString}`;
}
