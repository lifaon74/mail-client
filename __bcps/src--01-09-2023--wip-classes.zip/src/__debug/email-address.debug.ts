import { EmailAddress } from '../classes/email-address/implementations/classes/email-address.class';

export function emailAddressDebug(): void {
  // const emailAddress = EmailAddress.parse('a@b.com');
  // const emailAddress = EmailAddress.parse('"John.\\"Doe."@example.com');
  const emailAddress = EmailAddress.parse('valentin.richard@example.com');

  console.log(emailAddress);
}
