
import { IMimeType } from '../classes/mime-type/mime-type.type';
import {
  MimeTypeParameterKey
} from '../classes/mime-type/fragments/mime-type-parameter-list/fragments/mime-type-parameter/fragments/mime-type-parameter-key/implementations/classes/mime-type-parameter-key.class';
import {
  MimeTypeParameterValue
} from '../classes/mime-type/fragments/mime-type-parameter-list/fragments/mime-type-parameter/fragments/mime-type-parameter-value/implementations/classes/mime-type-parameter-value.class';
import {
  MimeTypeParameter
} from '../classes/mime-type/fragments/mime-type-parameter-list/fragments/mime-type-parameter/implementations/classes/mime-type-parameter.class';
import {
  MimeTypeParameterList
} from '../classes/mime-type/fragments/mime-type-parameter-list/implementations/classes/mime-type-parameter-list.class';
import { MimeTypeClass } from '../classes/mime-type/implementations/classes/create-mime-type';

export function mimeTypeDebug(): void {
  // const data = new MimeTypeParameter(
  //   MimeTypeParameterKey.fromString('abc'),
  //   new MimeTypeParameterValue.fromString('def'),
  // );

  // console.log(new MimeTypeParameterKey('def').get());

  // console.log(new MimeTypeParameterValue('def').getQuoted());
  // console.log(new MimeTypeParameterValue('"def"').getQuoted());
  // console.log(new MimeTypeParameterValue('"de\\"f"').getQuoted());
  // console.log(new MimeTypeParameterValue('"de\\\\f"').getQuoted());
  // console.log(new MimeTypeParameterValue('de"f').getQuoted());
  // console.log(new MimeTypeParameterValue('"de"f"').getQuoted());
  // console.log(new MimeTypeParameterValue('"de\\\\"f"').getQuoted());

  // console.log(MimeTypeParameter.parse('abc="def"').toString());
  // console.log(MimeTypeParameter.parse('abc="a\\"h"').toString());

  // console.log(MimeTypeParameterList.parse('name="test.bin"').toString());
  // console.log(MimeTypeParameterList.parse('name="test\\".bin"; abc="def"; bob ').toString());
  // console.log(MimeTypeParameterList.parse('abc="def"; ghi').toString());

  console.log(MimeTypeClass.parse('application/octet-stream; name="test.bin"'));

  // console.log(MIME_TYPE_TEXT_PLAIN_UTF8_CONSTANT.toString());

  // const data: IMimeType = createMimeTypeFromParts(
  //   'multipart',
  //   'mixed',
  //   createMimeTypeParameterListFromMimeTypeParameters([
  //     generateMimeTypeParameterBoundary(),
  //   ]),
  // );

  // console.log(data.toString());

  // const data = MimeTypeMultipartAlternative.generate();
  // const data = MimeType.fromString(`application/octet-stream; name="test.bin"`);
  // const data = MimeTypeParameterList.fromString(`name="test.bin"`);
  // const data = MimeTypeParameterList.fromString(`name="test\\".bin"; abc="def"; bob `);
  // const data = MimeTypeParameterList.fromString(`abc="def"`);
  // const data = MimeTypeParameterList.fromString(`abc="def"; ghi`);
  // const data = MimeTypeParameterList.fromString(`abc="def" ;`);
  // const data = MimeTypeParameterList.fromString(`abc="def`);
  // const data = MimeTypeParameterList.fromString(`abc="def"; a=`);
  // const data = MimeTypeParameterList.fromString(`name="test\\\\".bin"`);
  // const data = MimeTypeParameterList.fromString(`name="test\\".bin"`);

  // console.log(data);
  // console.log(data.toString());
}
