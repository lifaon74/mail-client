export const CRLF: string = '\r\n';
