import { IDomainGetFunction } from './domain.get.function-definition';

export interface IDomainGetTrait {
  get: IDomainGetFunction;
}
