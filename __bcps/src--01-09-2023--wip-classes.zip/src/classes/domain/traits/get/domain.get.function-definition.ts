export interface IDomainGetFunction {
  (): string;
}
