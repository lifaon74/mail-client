import { IDomainSetFunction } from './domain.set.function-definition';

export interface IDomainSetTrait {
  set: IDomainSetFunction;
}
