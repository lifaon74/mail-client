export interface IDomainSetFunction {
  (
    domain: string,
  ): void;
}
