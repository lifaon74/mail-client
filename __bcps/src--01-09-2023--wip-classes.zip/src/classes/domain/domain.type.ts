import { IToStringTrait } from '@lifaon/traits';
import { IDomainGetTrait } from './traits/get/domain.get.trait';
import { IDomainSetTrait } from './traits/set/domain.set.trait';

export interface IDomain extends //
  IDomainGetTrait,
  IDomainSetTrait,
  IToStringTrait
  //
{
}
