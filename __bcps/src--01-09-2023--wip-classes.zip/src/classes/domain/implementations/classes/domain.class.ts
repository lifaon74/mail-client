import { IDomain } from '../../domain.type';

export class Domain implements IDomain {
  #domain!: string;

  constructor(
    domain: string,
  ) {
    this.set(domain);
  }

  get(): string {
    return this.#domain;
  }

  set(
    domain: string,
  ): void {
    try {
      const url: URL = new URL(`https://${domain}`);
      if (domain === url.hostname) {
        this.#domain = domain;
      } else {
        throw null;
      }
    } catch {
      throw new Error(`Invalid domain`);
    }
  }

  toString(): string {
    return this.get();
  }
}
