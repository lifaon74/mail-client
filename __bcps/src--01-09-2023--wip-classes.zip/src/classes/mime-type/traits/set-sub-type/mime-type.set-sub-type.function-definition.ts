export interface IMimeTypeSetSubTypeFunction {
  (
    value: string,
  ): void;
}
