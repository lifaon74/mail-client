import { IMimeTypeSetSubTypeFunction } from './mime-type.set-sub-type.function-definition';

export interface IMimeTypeSetSubTypeTrait {
  setSubType: IMimeTypeSetSubTypeFunction;
}
