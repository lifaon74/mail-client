export interface IMimeTypeGetTypeAndSubTypeFunction {
  (): string;
}
