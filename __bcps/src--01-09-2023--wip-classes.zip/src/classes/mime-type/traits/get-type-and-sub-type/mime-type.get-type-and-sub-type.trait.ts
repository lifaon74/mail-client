import { IMimeTypeGetTypeAndSubTypeFunction } from './mime-type.get-type-and-sub-type.function-definition';

export interface IMimeTypeGetTypeAndSubTypeTrait {
  getTypeAndSubType: IMimeTypeGetTypeAndSubTypeFunction;
}
