export interface IMimeTypeGetSubTypeFunction {
  (): string;
}
