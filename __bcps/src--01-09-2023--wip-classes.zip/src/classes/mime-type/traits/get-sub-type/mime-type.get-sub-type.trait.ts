import { IMimeTypeGetSubTypeFunction } from './mime-type.get-sub-type.function-definition';

export interface IMimeTypeGetSubTypeTrait {
  getSubType: IMimeTypeGetSubTypeFunction;
}
