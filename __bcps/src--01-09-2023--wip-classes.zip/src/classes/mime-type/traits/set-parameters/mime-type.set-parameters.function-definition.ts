import { IMimeTypeParameterList } from '../../fragments/mime-type-parameter-list/mime-type-parameter-list.type';

export interface IMimeTypeSetParametersFunction {
  (
    parameters: IMimeTypeParameterList,
  ): void;
}
