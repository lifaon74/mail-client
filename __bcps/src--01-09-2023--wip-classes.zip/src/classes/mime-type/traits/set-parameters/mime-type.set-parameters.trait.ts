import { IMimeTypeSetParametersFunction } from './mime-type.set-parameters.function-definition';

export interface IMimeTypeSetParametersTrait {
  setParameters: IMimeTypeSetParametersFunction;
}
