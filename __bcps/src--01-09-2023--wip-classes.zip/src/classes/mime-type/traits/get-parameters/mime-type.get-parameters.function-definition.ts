import { IMimeTypeParameterList } from '../../fragments/mime-type-parameter-list/mime-type-parameter-list.type';

export interface IMimeTypeGetParametersFunction {
  (): IMimeTypeParameterList;
}
