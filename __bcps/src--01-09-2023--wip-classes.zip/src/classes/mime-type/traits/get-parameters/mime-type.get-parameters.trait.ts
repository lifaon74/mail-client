import { IMimeTypeGetParametersFunction } from './mime-type.get-parameters.function-definition';

export interface IMimeTypeGetParametersTrait {
  getParameters: IMimeTypeGetParametersFunction;
}
