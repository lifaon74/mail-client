import { IMimeTypeSetTypeFunction } from './mime-type.set-type.function-definition';

export interface IMimeTypeSetTypeTrait {
  setType: IMimeTypeSetTypeFunction;
}
