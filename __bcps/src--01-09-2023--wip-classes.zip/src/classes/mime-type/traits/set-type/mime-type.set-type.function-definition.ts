export interface IMimeTypeSetTypeFunction {
  (
    value: string,
  ): void;
}
