import { IMimeTypeGetTypeFunction } from './mime-type.get-type.function-definition';

export interface IMimeTypeGetTypeTrait {
  getType: IMimeTypeGetTypeFunction;
}
