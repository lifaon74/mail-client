export interface IMimeTypeGetTypeFunction {
  (): string;
}
