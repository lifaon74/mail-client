import { IToStringTrait } from '@lifaon/traits';
import { IMimeTypeParameterListGetTrait } from './traits/get/mime-type-parameter-list.get.trait';
import { IMimeTypeParameterListToMapTrait } from './traits/to-map/mime-type-parameter-list.to-map.trait';
import { IMimeTypeParameterListSetTrait } from './traits/set/mime-type-parameter-list.set.trait';

export interface IMimeTypeParameterList extends //
  IMimeTypeParameterListGetTrait,
  IMimeTypeParameterListSetTrait,
  IMimeTypeParameterListToMapTrait,
  IToStringTrait
  //
{
}
