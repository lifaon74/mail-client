import { IMimeTypeParameterSetKeyFunction } from './mime-type-parameter.set-key.function-definition';

export interface IMimeTypeParameterSetKeyTrait {
  setKey: IMimeTypeParameterSetKeyFunction;
}
