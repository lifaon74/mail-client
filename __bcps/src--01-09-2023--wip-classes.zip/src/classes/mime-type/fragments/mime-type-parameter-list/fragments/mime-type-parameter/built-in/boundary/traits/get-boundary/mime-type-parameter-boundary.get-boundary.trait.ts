import { IMimeTypeParameterBoundaryGetBoundaryFunction } from './mime-type-parameter-boundary.get-boundary.function-definition';

export interface IMimeTypeParameterBoundaryGetBoundaryTrait {
  getBoundary: IMimeTypeParameterBoundaryGetBoundaryFunction;
}
