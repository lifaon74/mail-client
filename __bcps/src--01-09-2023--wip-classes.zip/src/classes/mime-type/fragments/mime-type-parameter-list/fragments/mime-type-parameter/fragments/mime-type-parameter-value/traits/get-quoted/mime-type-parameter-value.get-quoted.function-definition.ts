export interface IMimeTypeParameterValueGetQuotedFunction {
  (): string;
}
