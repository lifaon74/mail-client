import { IMimeTypeParameterValueGetQuotedFunction } from './mime-type-parameter-value.get-quoted.function-definition';

export interface IMimeTypeParameterValueGetQuotedTrait {
  getQuoted: IMimeTypeParameterValueGetQuotedFunction;
}
