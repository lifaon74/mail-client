export interface IMimeTypeParameterKeyGetFunction {
  (): string;
}
