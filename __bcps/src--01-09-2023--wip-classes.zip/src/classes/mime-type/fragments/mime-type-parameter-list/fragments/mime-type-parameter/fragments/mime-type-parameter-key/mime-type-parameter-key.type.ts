import { IToStringTrait } from '@lifaon/traits';
import { IMimeTypeParameterKeyGetTrait } from './traits/get/mime-type-parameter-key.get.trait';
import { IMimeTypeParameterKeySetTrait } from './traits/set/mime-type-parameter-key.set.trait';

export interface IMimeTypeParameterKey extends //
  IMimeTypeParameterKeyGetTrait,
  IMimeTypeParameterKeySetTrait,
  IToStringTrait
  //
{
}
