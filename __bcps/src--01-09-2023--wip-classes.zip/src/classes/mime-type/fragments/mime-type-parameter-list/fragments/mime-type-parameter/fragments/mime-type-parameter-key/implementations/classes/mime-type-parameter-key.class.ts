import { HTTP_TOKEN_PATTERN } from '../../../../../../../../../../constants/http-token-pattern.constant';
import { IMimeTypeParameterKey } from '../../mime-type-parameter-key.type';

/** PATTERNS **/

export const MIME_TYPE_PARAMETER_KEY_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
export const MIME_TYPE_PARAMETER_KEY_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_KEY_PATTERN}$`);

/** CLASS **/

export class MimeTypeParameterKey implements IMimeTypeParameterKey {
  #key!: string;

  constructor(
    key: string,
  ) {
    this.set(key);
  }

  get(): string {
    return this.#key;
  }

  set(
    key: string,
  ): void {
    if (MIME_TYPE_PARAMETER_KEY_REGEXP.test(key)) {
      this.#key = key;
    } else {
      throw new Error(`Invalid key`);
    }
  }

  toString(): string {
    return this.get();
  }
}
