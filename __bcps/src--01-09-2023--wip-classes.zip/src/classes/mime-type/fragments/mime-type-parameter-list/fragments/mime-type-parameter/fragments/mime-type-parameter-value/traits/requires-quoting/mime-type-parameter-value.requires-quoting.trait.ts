import { IMimeTypeParameterValueRequiresQuotingFunction } from './mime-type-parameter-value.requires-quoting.function-definition';

export interface IMimeTypeParameterValueRequiresQuotingTrait {
  requiresQuoting: IMimeTypeParameterValueRequiresQuotingFunction;
}
