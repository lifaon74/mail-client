import { IMimeTypeParameterKeyGetFunction } from './mime-type-parameter-key.get.function-definition';

export interface IMimeTypeParameterKeyGetTrait {
  get: IMimeTypeParameterKeyGetFunction;
}
