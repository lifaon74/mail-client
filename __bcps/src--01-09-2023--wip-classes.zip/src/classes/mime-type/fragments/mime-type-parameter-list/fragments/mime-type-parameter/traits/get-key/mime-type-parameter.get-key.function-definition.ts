import { IMimeTypeParameterKey } from '../../fragments/mime-type-parameter-key/mime-type-parameter-key.type';

export interface IMimeTypeParameterGetKeyFunction {
  (): IMimeTypeParameterKey;
}
