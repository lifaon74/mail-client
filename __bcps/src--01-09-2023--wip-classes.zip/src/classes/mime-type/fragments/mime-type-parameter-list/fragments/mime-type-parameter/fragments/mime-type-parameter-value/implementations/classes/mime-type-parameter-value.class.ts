import { HTTP_QUOTED_STRING_TOKEN_PATTERN } from '../../../../../../../../../../constants/http-quoted-string-token-pattern.constant';
import { HTTP_TOKEN_PATTERN } from '../../../../../../../../../../constants/http-token-pattern.constant';
import { IMimeTypeParameterValue } from '../../mime-type-parameter-value.type';

/** PATTERNS **/

export const MIME_TYPE_PARAMETER_VALUE_NON_QUOTED_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const MIME_TYPE_PARAMETER_VALUE_NON_QUOTED_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_VALUE_NON_QUOTED_PATTERN}$`);

export const MIME_TYPE_PARAMETER_VALUE_QUOTED_PATTERN = `${HTTP_QUOTED_STRING_TOKEN_PATTERN}+`;
const MIME_TYPE_PARAMETER_VALUE_QUOTED_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_VALUE_QUOTED_PATTERN}$`);

export const MIME_TYPE_PARAMETER_VALUE_STRING_QUOTED_PATTERN = `"(?:[\\u0009\\u0020-\\u0021\\u0023-\\u005b\\u005d-\\u007e\\u0080-\\u00ff]|(?:\\\\")|(?:\\\\\\\\))+"`;
const MIME_TYPE_PARAMETER_VALUE_STRING_QUOTED_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_VALUE_STRING_QUOTED_PATTERN}$`);

export const MIME_TYPE_PARAMETER_VALUE_STRING_PATTERN = `(?:${MIME_TYPE_PARAMETER_VALUE_NON_QUOTED_PATTERN})|(?:${MIME_TYPE_PARAMETER_VALUE_STRING_QUOTED_PATTERN})`;

/** CLASS **/

export class MimeTypeParameterValue implements IMimeTypeParameterValue {
  #value!: string;
  #requiresQuoting!: boolean;

  constructor(
    value: string,
  ) {
    this.set(value);
  }

  get(): string {
    return this.#value;
  }

  requiresQuoting(): boolean {
    return this.#requiresQuoting;
  }

  getEscaped(): string {
    return this.get()
      .replace('\\', '\\\\')
      .replace('"', '\\"')
      ;
  }

  getQuoted(): string {
    return `"${this.getEscaped()}"`;
  }

  set(
    value: string,
  ): void {
    if (MIME_TYPE_PARAMETER_VALUE_NON_QUOTED_REGEXP.test(value)) {
      this.#value = value;
      this.#requiresQuoting = false;
    } else {
      if (MIME_TYPE_PARAMETER_VALUE_STRING_QUOTED_REGEXP.test(value)) {
        this.#value = value
          .slice(1, -1)
          .replace('\\', '');
        this.#requiresQuoting = !MIME_TYPE_PARAMETER_VALUE_NON_QUOTED_REGEXP.test(this.#value);
      } else if (MIME_TYPE_PARAMETER_VALUE_QUOTED_REGEXP.test(value)) {
        this.#value = value;
        this.#requiresQuoting = true;
      } else {
        throw new Error(`Invalid value`);
      }
    }
  }

  toString(): string {
    return this.requiresQuoting()
      ? this.getQuoted()
      : this.get();
  }
}
