export interface IMimeTypeParameterValueGetEscapedFunction {
  (): string;
}
