import { createMimeTypeParameterValueFromString } from '../../fragments/mime-type-parameter-value/implementations/classes/mime-type-parameter-value.class';
import { createMimeTypeParameter } from '../../implementations/classes/mime-type-parameter.class';
import { IMimeTypeParameter } from '../../mime-type-parameter.type';
import { MIME_TYPE_PARAMETER_BOUNDARY_KEY } from './mime-type-parameter-boundary-key.contant';
import { IMimeTypeParameterBoundary } from './mime-type-parameter-boundary.type';

/**
 * TODO
 * @deprecated
 */
export function createMimeTypeParameterBoundary(
  _boundary: string,
): IMimeTypeParameterBoundary {
  const parent: IMimeTypeParameter = createMimeTypeParameter({
    key: MIME_TYPE_PARAMETER_BOUNDARY_KEY,
    value: createMimeTypeParameterValueFromString(_boundary),
  });

  const getBoundary = (): string => {
    return _boundary;
  };

  return {
    ...parent,
    getBoundary,
  };
}


