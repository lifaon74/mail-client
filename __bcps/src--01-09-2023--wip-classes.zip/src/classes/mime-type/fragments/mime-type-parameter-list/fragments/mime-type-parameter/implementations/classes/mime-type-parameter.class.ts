import { IMimeTypeParameterKey } from '../../fragments/mime-type-parameter-key/mime-type-parameter-key.type';
import {
  MIME_TYPE_PARAMETER_VALUE_STRING_PATTERN,
  MimeTypeParameterValue,
} from '../../fragments/mime-type-parameter-value/implementations/classes/mime-type-parameter-value.class';
import { IMimeTypeParameterValue } from '../../fragments/mime-type-parameter-value/mime-type-parameter-value.type';
import { IMimeTypeParameter } from '../../mime-type-parameter.type';
import {
  MIME_TYPE_PARAMETER_KEY_PATTERN,
  MimeTypeParameterKey,
} from '../../fragments/mime-type-parameter-key/implementations/classes/mime-type-parameter-key.class';

/** PATTERNS **/

export const MIME_TYPE_PARAMETER_PATTERN = `(${MIME_TYPE_PARAMETER_KEY_PATTERN})(?:=(${MIME_TYPE_PARAMETER_VALUE_STRING_PATTERN}))?`;
const MIME_TYPE_PARAMETER_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_PATTERN}$`);

/** CLASS **/

export class MimeTypeParameter implements IMimeTypeParameter {
  static parse(
    input: string,
  ): MimeTypeParameter {
    const match: RegExpExecArray | null = MIME_TYPE_PARAMETER_REGEXP.exec(input);
    if (match === null) {
      throw new Error(`Invalid parameter`);
    } else {
      const [, keyString, valueString] = match;

      const key: IMimeTypeParameterKey = new MimeTypeParameterKey(keyString);

      const value: MimeTypeParameterValue | null = (valueString === void 0)
        ? null
        : new MimeTypeParameterValue(valueString);

      return new MimeTypeParameter(
        key,
        value,
      );
    }
  }

  #key: IMimeTypeParameterKey;
  #value: IMimeTypeParameterValue | null;

  constructor(
    key: IMimeTypeParameterKey,
    value: IMimeTypeParameterValue | null,
  ) {
    this.#key = key;
    this.#value = value;
  }

  getKey(): IMimeTypeParameterKey {
    return this.#key;
  }

  setKey(
    key: IMimeTypeParameterKey,
  ): void {
    this.#key = key;
  }

  getValue(): IMimeTypeParameterValue | null {
    return this.#value;
  }

  setValue(
    value: IMimeTypeParameterValue | null,
  ): void {
    this.#value = value;
  }

  hasEmptyValue(): boolean {
    const value: IMimeTypeParameterValue | null = this.getValue();
    return (value === null)
      || (value.get() === '');
  }

  toString(): string {
    return this.hasEmptyValue()
      ? this.getKey().toString()
      : `${this.getKey().toString()}=${(this.getValue() as IMimeTypeParameterValue).toString()}`;
  }
}
