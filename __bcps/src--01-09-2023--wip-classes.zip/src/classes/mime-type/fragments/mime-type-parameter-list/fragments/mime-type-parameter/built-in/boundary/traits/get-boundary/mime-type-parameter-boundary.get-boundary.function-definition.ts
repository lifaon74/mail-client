export interface IMimeTypeParameterBoundaryGetBoundaryFunction {
  (): string;
}
