import { IMimeTypeParameterGetKeyFunction } from './mime-type-parameter.get-key.function-definition';

export interface IMimeTypeParameterGetKeyTrait {
  getKey: IMimeTypeParameterGetKeyFunction;
}
