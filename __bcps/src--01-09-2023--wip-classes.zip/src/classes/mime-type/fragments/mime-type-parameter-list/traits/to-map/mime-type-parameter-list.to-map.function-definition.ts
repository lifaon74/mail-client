export interface IMimeTypeParameterListToMapFunction {
  (): Map<string, string>;
}
