import { IMimeTypeParameterListGetFunction } from './mime-type-parameter-list.get.function-definition';

export interface IMimeTypeParameterListGetTrait {
  get: IMimeTypeParameterListGetFunction;
}
