import { IMimeTypeParameterListSetFunction } from './mime-type-parameter-list.set.function-definition';

export interface IMimeTypeParameterListSetTrait {
  set: IMimeTypeParameterListSetFunction;
}
