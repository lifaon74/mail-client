import { IMimeTypeParameter } from '../../fragments/mime-type-parameter/mime-type-parameter.type';

export interface IMimeTypeParameterListGetFunction {
  (): readonly IMimeTypeParameter[];
}
