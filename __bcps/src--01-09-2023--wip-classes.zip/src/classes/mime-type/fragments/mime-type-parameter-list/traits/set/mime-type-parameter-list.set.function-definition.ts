import { IMimeTypeParameter } from '../../fragments/mime-type-parameter/mime-type-parameter.type';

export type IMimeTypeParameterListDedup =
  | 'none'
  | 'keep-last'
  | 'throw'
  ;

export type IMimeTypeParameterListSetEntry =
  | IMimeTypeParameter
  | [string, string]
  ;

export type IMimeTypeParameterListSetInput = Iterable<IMimeTypeParameterListSetEntry>;

export interface IMimeTypeParameterListSetFunction {
  (
    parameters: IMimeTypeParameterListSetInput,
    dedup?: IMimeTypeParameterListDedup,
  ): void;
}
