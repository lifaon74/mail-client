import { IMimeTypeParameterListToMapFunction } from './mime-type-parameter-list.to-map.function-definition';

export interface IMimeTypeParameterListToMapTrait {
  toMap: IMimeTypeParameterListToMapFunction;
}
