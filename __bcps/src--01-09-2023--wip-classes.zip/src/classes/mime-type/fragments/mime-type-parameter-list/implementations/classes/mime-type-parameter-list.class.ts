import {
  IMimeTypeParameterValue,
} from '../../fragments/mime-type-parameter/fragments/mime-type-parameter-value/mime-type-parameter-value.type';
import {
  MIME_TYPE_PARAMETER_PATTERN,
  MimeTypeParameter,
} from '../../fragments/mime-type-parameter/implementations/classes/mime-type-parameter.class';
import { IMimeTypeParameter } from '../../fragments/mime-type-parameter/mime-type-parameter.type';
import { IMimeTypeParameterList } from '../../mime-type-parameter-list.type';
import {
  IMimeTypeParameterListDedup,
  IMimeTypeParameterListSetInput, IMimeTypeParameterListSetEntry,
} from '../../traits/set/mime-type-parameter-list.set.function-definition';
import { IMimeTypeParameterKey } from '../../fragments/mime-type-parameter/fragments/mime-type-parameter-key/mime-type-parameter-key.type';
import {
  MimeTypeParameterKey,
} from '../../fragments/mime-type-parameter/fragments/mime-type-parameter-key/implementations/classes/mime-type-parameter-key.class';
import {
  MimeTypeParameterValue,
} from '../../fragments/mime-type-parameter/fragments/mime-type-parameter-value/implementations/classes/mime-type-parameter-value.class';
import { iterableToArray } from '../../../../../../misc/iterable-to-array';

/** PATTERNS **/

// const NAME_AND_VALUE_REGEXP: RegExp = new RegExp(`\\s*(${HTTP_TOKEN_PATTERN}+)(?:=(${HTTP_TOKEN_PATTERN}+|(?:"(?:${HTTP_TOKEN_PATTERN}|(?:\\\\")|(?:\\\\\\\\))+")))?\\s*(?:;|$)`, 'g');
const MIME_TYPE_PARAMETER_LIST_KEY_AND_VALUE_REGEXP: RegExp = new RegExp(`\\s*${MIME_TYPE_PARAMETER_PATTERN}\\s*(?:;|$)`, 'g');

/** CLASS **/

export class MimeTypeParameterList implements IMimeTypeParameterList {
  static parse(
    input: string,
    dedup?: IMimeTypeParameterListDedup,
  ): MimeTypeParameterList {
    let match: RegExpExecArray | null;
    let index: number = 0;
    const items: IMimeTypeParameter[] = [];

    while ((match = MIME_TYPE_PARAMETER_LIST_KEY_AND_VALUE_REGEXP.exec(input)) !== null) {
      if ((index === 0) && (match.index !== 0)) {
        throw new Error(`Invalid parameters`);
      }

      const [, keyString, valueString] = match;

      const key: IMimeTypeParameterKey = new MimeTypeParameterKey(keyString);

      const value: IMimeTypeParameterValue | null = (valueString === void 0)
        ? null
        : new MimeTypeParameterValue(
          valueString,
        );

      items.push(
        new MimeTypeParameter(
          key,
          value,
        ),
      );

      index = match.index + match[0].length;
    }

    if (index !== input.length) {
      throw new Error(`Invalid parameters`);
    }

    return new MimeTypeParameterList(
      items,
      dedup,
    );
  }

  // static fromIterable(
  //   parameters: Iterable<[string, string]>,
  //   dedup?: IMimeTypeParameterListDedup,
  // ): MimeTypeParameterList {
  //   return new MimeTypeParameterList(
  //     (Array.isArray(parameters) ? parameters : Array.from(parameters)).map(([key, value]): MimeTypeParameter => {
  //       return new MimeTypeParameter(key, value);
  //     }),
  //     dedup,
  //   );
  // }

  #parameters!: readonly IMimeTypeParameter[];

  constructor(
    parameters: Iterable<IMimeTypeParameter | [string, string]> = [],
    dedup?: IMimeTypeParameterListDedup,
  ) {
    this.set(parameters, dedup);
  }

  get(): readonly IMimeTypeParameter[] {
    return this.#parameters;
  }

  set(
    parameters: IMimeTypeParameterListSetInput,
    dedup: IMimeTypeParameterListDedup = 'none',
  ): void {
    if (dedup === 'none') {
      this.#parameters = iterableToArray(parameters).map((input: IMimeTypeParameterListSetEntry): IMimeTypeParameter => {
        return Array.isArray(input)
          ? new MimeTypeParameter(input[0], input[1])
          : input;
      });
    } else {
      const map: Map<string, IMimeTypeParameter> = new Map<string, IMimeTypeParameter>();

      for (let i = 0, l = parameters.length; i < l; i++) {
        const parameter: IMimeTypeParameter = parameters[i];
        const key: string = parameter.getKey().toString();

        if (map.has(key) && (dedup === 'throw')) {
          throw new Error(`Key already exists`);
        } else {
          map.set(key, parameter);
        }
      }

      this.#parameters = Array.from(map.values());
    }
  }

  toMap(): Map<string, string> {
    return new Map(
      this.get().map((parameter: IMimeTypeParameter): [string, string] => {
        const value: IMimeTypeParameterValue | null = parameter.getValue();
        return [
          parameter.getKey().toString(),
          (value === null)
            ? ''
            : value.toString(),
        ];
      }),
    );
  }

  toString(): string {
    let output: string = '';
    const parameters: readonly IMimeTypeParameter[] = this.get();

    for (let i = 0, l = parameters.length; i < l; i++) {
      const parameter: IMimeTypeParameter = parameters[i];
      if (i > 0) {
        output += '; ';
      }
      output += parameter.toString();
    }

    return output;
  }
}


/** FUNCTIONS **/

function normalizeMimeTypeParameterListSetEntry(
  input: IMimeTypeParameterListSetEntry,
): IMimeTypeParameter {
  return Array.isArray(input)
    ? new MimeTypeParameter(input[0], input[1])
    : input;
}

function normalizeMimeTypeParameterListSetInput(
  input: IMimeTypeParameterListSetInput,
): any {

}
