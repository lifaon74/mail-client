import { MimeTypeClass } from '../implementations/classes/create-mime-type';
import { IMimeType } from '../mime-type.type';

/**
 * @deprecated
 */
export const MIME_TYPE_TEXT_HTML_UTF8_CONSTANT: IMimeType = MimeTypeClass.parse('text/html; charset="utf8"');

