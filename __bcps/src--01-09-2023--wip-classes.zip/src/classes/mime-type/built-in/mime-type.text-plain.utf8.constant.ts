import { IMimeType } from '../mime-type.type';
import { MimeTypeClass } from '../implementations/classes/create-mime-type';

/**
 * @deprecated
 */
export const MIME_TYPE_TEXT_PLAIN_UTF8_CONSTANT: IMimeType = MimeTypeClass.parse('text/plain; charset="utf8"');

