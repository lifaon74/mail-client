import { HTTP_TOKEN_PATTERN } from '../../../../constants/http-token-pattern.constant';
import { MimeTypeParameterList } from '../../fragments/mime-type-parameter-list/implementations/classes/mime-type-parameter-list.class';
import { IMimeTypeParameterList } from '../../fragments/mime-type-parameter-list/mime-type-parameter-list.type';
import { IMimeType } from '../../mime-type.type';

/** PATTERNS **/

const TYPE_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const TYPE_REGEXP = new RegExp(`^${TYPE_PATTERN}$`);

const SUBTYPE_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const SUBTYPE_REGEXP = new RegExp(`^${TYPE_PATTERN}$`);

const TYPE_AND_SUBTYPE_REGEXP: RegExp = new RegExp(`^(${TYPE_PATTERN})/(${SUBTYPE_PATTERN})$`, 'g');

/*
https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types
 */

/** CLASS **/

export interface IMimeTypeOptions {
  type: string;
  subType: string;
  parameters?: IMimeTypeParameterList;
}

export class MimeTypeClass implements IMimeType {
  static parse(
    input: string,
  ): MimeTypeClass {
    const index: number = input.indexOf(';');
    let typeAndSubType: string;
    let parameters: string;

    if (index === -1) {
      typeAndSubType = input;
      parameters = '';
    } else {
      typeAndSubType = input.slice(0, index);
      parameters = input.slice(index + 1);
    }

    TYPE_AND_SUBTYPE_REGEXP.lastIndex = 0;
    const match: RegExpExecArray | null = TYPE_AND_SUBTYPE_REGEXP.exec(typeAndSubType);

    if (match === null) {
      throw new Error(`Invalid type or subtype`);
    } else {
      return new MimeTypeClass({
        type: match[1],
        subType: match[2],
        parameters: (parameters === '')
          ? new MimeTypeParameterList()
          : MimeTypeParameterList.parse(parameters),
      });
    }
  }

  #type!: string;
  #subType!: string;
  #parameters!: IMimeTypeParameterList;

  constructor(
    {
      type,
      subType,
      parameters = new MimeTypeParameterList(),
    }: IMimeTypeOptions,
  ) {
    this.setType(type);
    this.setSubType(subType);
    this.setParameters(parameters);
  }

  getType(): string {
    return this.#type;
  }

  setType(
    value: string,
  ): void {
    if (TYPE_REGEXP.test(value)) {
      this.#type = value;
    } else {
      throw new Error(`Invalid type`);
    }
  }

  getSubType(): string {
    return this.#subType;
  }

  setSubType(
    value: string,
  ): void {
    if (SUBTYPE_REGEXP.test(value)) {
      this.#subType = value;
    } else {
      throw new Error(`Invalid subtype`);
    }
  }

  getTypeAndSubType(): string {
    return `${this.getType()}/${this.getSubType()}`;
  }

  getParameters(): IMimeTypeParameterList {
    return this.#parameters;
  }

  setParameters(
    parameters: IMimeTypeParameterList,
  ): void {
    this.#parameters = parameters;
  }

  toString(): string {
    const parametersString: string = (this.getParameters().get().length === 0)
      ? ''
      : `; ${this.getParameters().toString()}`;
    return `${this.getTypeAndSubType()}${parametersString}`;
  }
}
