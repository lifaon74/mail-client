import { IEmailAddress } from '../../email-address.type';
import { IDomain } from '../../../domain/domain.type';
import { IEmailAddressLocalPart } from '../../fragments/email-address-local-part/email-address-local-part.type';
import { EmailAddressLocalPart } from '../../fragments/email-address-local-part/implementations/classes/email-address-local-part.class';
import { Domain } from '../../../domain/implementations/classes/domain.class';

export interface IEmailAddressOptions {
  localPart: IEmailAddressLocalPart;
  domain: IDomain;
}

export class EmailAddress implements IEmailAddress {

  static parse(
    input: string,
  ): EmailAddress {
    const index: number = input.lastIndexOf('@');

    if (index === -1) {
      throw new Error(`Invalid email address: missing @`);
    }

    return new EmailAddress({
      localPart: new EmailAddressLocalPart(input.slice(0, index)),
      domain: new Domain(input.slice(index + 1)),
    });
  }

  #localPart: IEmailAddressLocalPart;
  #domain: IDomain;

  constructor(
    {
      localPart,
      domain,
    }: IEmailAddressOptions,
  ) {
    this.#localPart = localPart;
    this.#domain = domain;
  }

  getLocalPart(): IEmailAddressLocalPart {
    return this.#localPart;
  }

  setLocalPart(
    localpart: IEmailAddressLocalPart,
  ): void {
    this.#localPart = localpart;
  }

  getDomain(): IDomain {
    return this.#domain;
  }

  setDomain(
    domain: IDomain,
  ): void {
    this.#domain = domain;
  }

  toString(): string {
    return `${this.getLocalPart().toString()}@${this.getDomain().toString()}`;
  }
}
