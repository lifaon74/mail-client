import { IEmailAddressLocalPart } from '../../fragments/email-address-local-part/email-address-local-part.type';

export interface IEmailAddressGetLocalPartFunction {
  (): IEmailAddressLocalPart;
}
