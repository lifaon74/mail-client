import { IEmailAddressGetLocalPartFunction } from './email-address.get-local-part.function-definition';

export interface IEmailAddressGetLocalPartTrait {
  getLocalPart: IEmailAddressGetLocalPartFunction;
}
