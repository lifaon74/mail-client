import { IEmailAddressSetLocalPartFunction } from './email-address.set-local-part.function-definition';

export interface IEmailAddressSetLocalPartTrait {
  setLocalPart: IEmailAddressSetLocalPartFunction;
}
