import { IEmailAddressLocalPart } from '../../fragments/email-address-local-part/email-address-local-part.type';

export interface IEmailAddressSetLocalPartFunction {
  (
    localpart: IEmailAddressLocalPart,
  ): void;
}
