import { IDomain } from '../../../domain/domain.type';

export interface IEmailAddressSetDomainFunction {
  (
    domain: IDomain,
  ): void;
}
