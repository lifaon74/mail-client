import { IEmailAddressSetDomainFunction } from './email-address.set-domain.function-definition';

export interface IEmailAddressSetDomainTrait {
  setDomain: IEmailAddressSetDomainFunction;
}
