import { IEmailAddressGetDomainFunction } from './email-address.get-domain.function-definition';

export interface IEmailAddressGetDomainTrait {
  getDomain: IEmailAddressGetDomainFunction;
}
