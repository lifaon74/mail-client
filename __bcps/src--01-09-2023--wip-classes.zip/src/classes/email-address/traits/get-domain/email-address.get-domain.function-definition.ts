import { IDomain } from '../../../domain/domain.type';

export interface IEmailAddressGetDomainFunction {
  (): IDomain;
}
