import { IEmailAddressLocalPartGetUnquotedFunction } from './email-address-local-part.get-unquoted.function-definition';

export interface IEmailAddressLocalPartGetUnquotedTrait {
  getUnquoted: IEmailAddressLocalPartGetUnquotedFunction;
}
