import { IEmailAddressLocalPartGetFunction } from './email-address-local-part.get.function-definition';

export interface IEmailAddressLocalPartGetTrait {
  get: IEmailAddressLocalPartGetFunction;
}
