export interface IEmailAddressLocalPartIsQuotedFunction {
  (): boolean;
}
