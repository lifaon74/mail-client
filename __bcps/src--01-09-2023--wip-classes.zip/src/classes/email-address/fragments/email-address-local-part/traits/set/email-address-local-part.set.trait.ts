import { IEmailAddressLocalPartSetFunction } from './email-address-local-part.set.function-definition';

export interface IEmailAddressLocalPartSetTrait {
  set: IEmailAddressLocalPartSetFunction;
}
