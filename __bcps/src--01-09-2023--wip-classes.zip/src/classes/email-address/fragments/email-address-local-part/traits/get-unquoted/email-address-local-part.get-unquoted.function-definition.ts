export interface IEmailAddressLocalPartGetUnquotedFunction {
  (): string;
}
