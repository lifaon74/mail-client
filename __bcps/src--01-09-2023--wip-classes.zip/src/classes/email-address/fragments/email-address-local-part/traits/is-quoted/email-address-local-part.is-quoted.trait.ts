import { IEmailAddressLocalPartIsQuotedFunction } from './email-address-local-part.is-quoted.function-definition';

export interface IEmailAddressLocalPartIsQuotedTrait {
  isQuoted: IEmailAddressLocalPartIsQuotedFunction;
}
