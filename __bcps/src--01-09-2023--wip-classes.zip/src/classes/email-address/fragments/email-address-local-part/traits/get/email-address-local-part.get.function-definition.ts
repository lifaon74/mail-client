export interface IEmailAddressLocalPartGetFunction {
  (): string;
}
