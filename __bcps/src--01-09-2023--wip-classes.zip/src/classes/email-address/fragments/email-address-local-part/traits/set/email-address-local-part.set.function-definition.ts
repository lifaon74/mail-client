export interface IEmailAddressLocalPartSetFunction {
  (
    localpart: string,
  ): void;
}
