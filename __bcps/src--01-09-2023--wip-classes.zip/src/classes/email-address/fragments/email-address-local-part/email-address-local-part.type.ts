import { IToStringTrait } from '@lifaon/traits';
import { IEmailAddressLocalPartGetTrait } from './traits/get/email-address-local-part.get.trait';
import { IEmailAddressLocalPartSetTrait } from './traits/set/email-address-local-part.set.trait';
import { IEmailAddressLocalPartGetUnquotedTrait } from './traits/get-unquoted/email-address-local-part.get-unquoted.trait';
import { IEmailAddressLocalPartIsQuotedTrait } from './traits/is-quoted/email-address-local-part.is-quoted.trait';

export interface IEmailAddressLocalPart extends //
  IEmailAddressLocalPartGetTrait,
  IEmailAddressLocalPartIsQuotedTrait,
  IEmailAddressLocalPartGetUnquotedTrait,
  IEmailAddressLocalPartSetTrait,
  IToStringTrait
  //
{
}
