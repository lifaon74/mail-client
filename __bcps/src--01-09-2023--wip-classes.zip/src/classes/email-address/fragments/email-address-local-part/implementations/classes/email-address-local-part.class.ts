import { IEmailAddressLocalPart } from '../../email-address-local-part.type';

const EMAIL_ADDRESS_LOCAL_PART_REGEXP: RegExp = new RegExp('^[A-Za-z0-9!#$%&\'*+\\-/=?^_`{|}~.]+$');

// [\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f] === [^\x09-\x0a\x0d\x20\x5c]
const EMAIL_ADDRESS_QUOTED_LOCAL_PART_REGEXP: RegExp = new RegExp('^"(?:[^\\x09-\\x0a\\x0d\\x20\\x5c]|\\\\[^\\x0a\\x0d])+"$');

export class EmailAddressLocalPart implements IEmailAddressLocalPart {
  #localpart!: string;

  constructor(
    localpart: string,
  ) {
    this.set(localpart);
  }

  get(): string {
    return this.#localpart;
  }

  isQuoted(): boolean {
    return this.get().startsWith('"') && this.get().endsWith('"');
  }

  getUnquoted(): string {
    return this.isQuoted()
      ? this.get()
        .replace(new RegExp('\\\\([^\\x0a\\x0d])', 'g'), '$1')
        .slice(1, -1)
      : this.get();
  }

  set(
    localpart: string,
  ): void {
    if (
      !(
        EMAIL_ADDRESS_LOCAL_PART_REGEXP.test(localpart)
        || EMAIL_ADDRESS_QUOTED_LOCAL_PART_REGEXP.test(localpart)
      )
      || (localpart.length > 64)
    ) {
      throw (`Invalid localpart`);
    } else {
      this.#localpart = localpart;
    }
  }

  toString(): string {
    return this.get();
  }
}
