import { IToStringTrait } from '@lifaon/traits';
import { IEmailAddressGetDomainTrait } from './traits/get-domain/email-address.get-domain.trait';
import { IEmailAddressGetLocalPartTrait } from './traits/get-local-part/email-address.get-local-part.trait';
import { IEmailAddressSetDomainTrait } from './traits/set-domain/email-address.set-domain.trait';
import { IEmailAddressSetLocalPartTrait } from './traits/set-local-part/email-address.set-local-part.trait';

export interface IEmailAddress extends //
  IEmailAddressGetLocalPartTrait,
  IEmailAddressSetLocalPartTrait,
  IEmailAddressGetDomainTrait,
  IEmailAddressSetDomainTrait,
  IToStringTrait
  //
{
}
