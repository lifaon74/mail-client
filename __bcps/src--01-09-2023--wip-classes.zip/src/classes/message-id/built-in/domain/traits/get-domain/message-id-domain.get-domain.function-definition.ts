import { IDomain } from '../../../../../domain/domain.type';

export interface IMessageIdDomainGetDomainFunction {
  (): IDomain;
}
