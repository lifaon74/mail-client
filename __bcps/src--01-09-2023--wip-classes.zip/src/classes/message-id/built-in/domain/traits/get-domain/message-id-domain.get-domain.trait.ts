import { IMessageIdDomainGetDomainFunction } from './message-id-domain.get-domain.function-definition';

export interface IMessageIdDomainGetDomainTrait {
  getDomain: IMessageIdDomainGetDomainFunction;
}
