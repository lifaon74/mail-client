import { IMessageIdGetLeftFunction } from './message-id.get-left.function-definition';

export interface IMessageIdGetLeftTrait {
  getLeft: IMessageIdGetLeftFunction;
}
