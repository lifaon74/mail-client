export interface IMessageIdGetLeftFunction {
  (): string;
}
