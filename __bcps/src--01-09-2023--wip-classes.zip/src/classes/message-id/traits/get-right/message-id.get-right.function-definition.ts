export interface IMessageIdGetRightFunction {
  (): string;
}
