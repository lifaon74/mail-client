import { IMessageIdGetRightFunction } from './message-id.get-right.function-definition';

export interface IMessageIdGetRightTrait {
  getRight: IMessageIdGetRightFunction;
}
