export interface ISMTPDataContentHeaderGetKeyFunction {
  (): string;
}
