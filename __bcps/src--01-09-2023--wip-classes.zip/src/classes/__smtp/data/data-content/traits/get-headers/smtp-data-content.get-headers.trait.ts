import { ISMTPDataContentGetHeadersFunction } from './smtp-data-content.get-headers.function-definition';

export interface ISMTPDataContentGetHeadersTrait {
  getHeaders: ISMTPDataContentGetHeadersFunction;
}
