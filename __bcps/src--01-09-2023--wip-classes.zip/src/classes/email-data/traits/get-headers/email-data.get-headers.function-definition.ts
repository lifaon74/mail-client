import { IEmailHeaderList } from '../../fragments/header-list/email-header-list.type';

export interface IEmailDataGetHeadersFunction {
  (): IEmailHeaderList;
}
