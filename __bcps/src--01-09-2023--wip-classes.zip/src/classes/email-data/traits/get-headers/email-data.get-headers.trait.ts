import { IEmailDataGetHeadersFunction } from './email-data.get-headers.function-definition';

export interface IEmailDataGetHeadersTrait {
  getHeaders: IEmailDataGetHeadersFunction;
}
