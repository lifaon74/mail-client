import { IEmailDataGetBodyFunction } from './email-data.get-body.function-definition';

export interface IEmailDataGetBodyTrait {
  getBody: IEmailDataGetBodyFunction;
}
