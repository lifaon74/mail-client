import { IEmailBody } from '../../fragments/body/email-body.type';

export interface IEmailDataGetBodyFunction {
  (): IEmailBody;
}
