import { IEmailData } from '../../email-data.type';
import { IEmailHeaderList } from '../../fragments/header-list/email-header-list.type';
import { IEmailBody } from '../../fragments/body/email-body.type';
import { CRLF } from '../../../../constants/crlf';
import { EmailHeaderList } from '../../fragments/header-list/implementations/classes/email-header-list.class';
import { EmailBody } from '../../fragments/body/implementations/classes/email-body.class';

export interface IEmailDataOptions {
  headers: IEmailHeaderList;
  body: IEmailBody;
}

export class EmailData implements IEmailData {

  static parse(
    input: string,
  ): EmailData {
    const index: number = input.indexOf(CRLF + CRLF);
    const headers: IEmailHeaderList = EmailHeaderList.parse(input.slice(0, index));

    // const contentType: IEmailHeaderContentType | undefined = headers.get().find<IEmailHeaderContentType>((_): _ is IEmailHeaderContentType => _.getKey() === EMAIL_HEADER_CONTENT_TYPE_KEY);
    // const contentTransferEncoding: IEmailHeaderContentTransferEncoding | undefined = headers.getItem(HEADER_CONTENT_TRANSFER_ENCODING_KEY_NAME) as (IEmailHeaderContentTransferEncoding | undefined);
    //
    // if (contentType !== void 0) {
    //   if (contentType.getMimeType().getTypeAndSubType() === 'text/plain') {
    //
    //     if (contentTransferEncoding !== void 0) {
    //       if (contentTransferEncoding.getContentTransferEncoding() === 'base64') {
    //         console.log('ok');
    //       }
    //     }
    //   }
    // }

    return new EmailData({
      headers,
      body: new EmailBody(input.slice(index + 4)),
    });
  }

  #headers: IEmailHeaderList;
  #body: IEmailBody;

  constructor(
    {
      headers,
      body,
    }: IEmailDataOptions,
  ) {
    this.#headers = headers;
    this.#body = body;
  }

  getHeaders(): IEmailHeaderList {
    return this.#headers;
  }

  setHeaders(
    headers: IEmailHeaderList,
  ): void {
    this.#headers = headers;
  }

  getBody(): IEmailBody {
    return this.#body;
  }

  setBody(
    body: IEmailBody,
  ): void {
    this.#body = body;
  }

  toString(): string {
    return this.getHeaders().toString() + CRLF
      + CRLF
      + this.getBody().toString();
  }
}
