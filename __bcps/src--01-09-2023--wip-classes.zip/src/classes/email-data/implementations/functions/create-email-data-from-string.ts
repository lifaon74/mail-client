import { CRLF } from '../../../../constants/crlf';
import { createEmailBodyFromString } from '../../fragments/body/built-in/create-email-body-from-string';
import {
  IEmailHeaderContentTransferEncoding
} from '../../fragments/header-list/fragments/header/built-in/content-transfer-encoding/email-header-content-transfer-encoding.type';
import {
  HEADER_CONTENT_TRANSFER_ENCODING_KEY_NAME
} from '../../fragments/header-list/fragments/header/built-in/content-transfer-encoding/header-content-transfer-encoding-key.contant';
import { IEmailHeaderContentType } from '../../fragments/header-list/fragments/header/built-in/content-type/email-header-content-type.type';
import {
  EMAIL_HEADER_CONTENT_TYPE_KEY
} from '../../fragments/header-list/fragments/header/built-in/content-type/email-header-content-type-key.contant';
import { IEmailHeader } from '../../fragments/header-list/fragments/header/email-header.type';
import { createEmailHeaderListFromString } from '../../fragments/header-list/implementations/functions/create-email-header-list-from-string';
import { IEmailHeaderList } from '../../fragments/header-list/email-header-list.type';
import { createEmailData } from './create-email-data';
import { IEmailData } from '../../email-data.type';

export function createEmailDataFromString(
  input: string,
): IEmailData {
  const index: number = input.indexOf(CRLF + CRLF);
  const headers: IEmailHeaderList = createEmailHeaderListFromString(input.slice(0, index));

  const contentType: IEmailHeaderContentType | undefined = headers.getItem(EMAIL_HEADER_CONTENT_TYPE_KEY) as (IEmailHeaderContentType | undefined);
  const contentTransferEncoding: IEmailHeaderContentTransferEncoding | undefined = headers.getItem(HEADER_CONTENT_TRANSFER_ENCODING_KEY_NAME) as (IEmailHeaderContentTransferEncoding | undefined);

  if (contentType !== void 0) {
    if (contentType.getMimeType().getTypeAndSubType() === 'text/plain') {

      if (contentTransferEncoding !== void 0) {
        if (contentTransferEncoding.getContentTransferEncoding() === 'base64') {
          console.log('ok');
        }
      }
    }
  }

  return createEmailData({
    headers,
    body: createEmailBodyFromString(input.slice(index + 4)),
  });
}
