import { IEmailHeader } from '../../email-header.type';
import { IEmailHeaderDateGetDateTrait } from './traits/get-date/email-header-date.get-date.trait';
import { IEmailHeaderDateSetDateTrait } from './traits/set-date/email-header-date.set-date.trait';

export interface IEmailHeaderDate extends IEmailHeader, //
  IEmailHeaderDateGetDateTrait,
  IEmailHeaderDateSetDateTrait
  //
{
}
