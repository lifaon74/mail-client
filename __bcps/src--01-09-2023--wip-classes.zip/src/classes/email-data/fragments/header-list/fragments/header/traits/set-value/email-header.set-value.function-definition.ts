export interface IEmailHeaderSetValueFunction {
  (
    value: string,
  ): void;
}
