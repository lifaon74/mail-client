import { IEmailHeaderContentType } from '../../email-header-content-type.type';
import { EmailHeaderSpecialized } from '../../../../implementations/classes/email-header-specialized.class';
import { IEmailHeaderContentTypeKey, EMAIL_HEADER_CONTENT_TYPE_KEY } from '../../email-header-content-type-key.contant';
import { IMimeType } from '../../../../../../../../../mime-type/mime-type.type';
import { MimeTypeClass } from '../../../../../../../../../mime-type/implementations/classes/create-mime-type';

export class EmailHeaderContentType extends EmailHeaderSpecialized<IEmailHeaderContentTypeKey> implements IEmailHeaderContentType {

  #mimeType!: IMimeType;

  constructor(
    mimeType: IMimeType | string,
  ) {
    super(EMAIL_HEADER_CONTENT_TYPE_KEY);
    if (typeof mimeType === 'string') {
      this.setValue(mimeType);
    } else {
      this.setMimeType(mimeType);
    }
  }

  override getValue(): string {
    return this.#mimeType.toString();
  }

  override setValue(
    value: string,
  ): void {
    this.#mimeType = MimeTypeClass.parse(value);
  }

  getMimeType(): IMimeType {
    return this.#mimeType;
  }

  setMimeType(
    mimeType: IMimeType,
  ): void {
    this.#mimeType = mimeType;
  }
}
