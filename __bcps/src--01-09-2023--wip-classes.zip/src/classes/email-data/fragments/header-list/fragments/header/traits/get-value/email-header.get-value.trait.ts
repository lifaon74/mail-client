import { IEmailHeaderGetValueFunction } from './email-header.get-value.function-definition';

export interface IEmailHeaderGetValueTrait {
  getValue: IEmailHeaderGetValueFunction;
}
