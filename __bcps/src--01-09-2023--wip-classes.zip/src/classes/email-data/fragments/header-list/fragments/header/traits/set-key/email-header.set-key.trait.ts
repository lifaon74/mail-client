import { IEmailHeaderSetKeyFunction } from './email-header.set-key.function-definition';

export interface IEmailHeaderSetKeyTrait {
  setKey: IEmailHeaderSetKeyFunction;
}
