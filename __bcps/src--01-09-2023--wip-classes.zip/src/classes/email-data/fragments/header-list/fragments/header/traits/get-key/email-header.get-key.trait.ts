import { IEmailHeaderGetKeyFunction } from './email-header.get-key.function-definition';

export interface IEmailHeaderGetKeyTrait {
  getKey: IEmailHeaderGetKeyFunction;
}
