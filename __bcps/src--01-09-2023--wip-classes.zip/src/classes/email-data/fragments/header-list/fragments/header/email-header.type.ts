import { IToStringTrait } from '@lifaon/traits';
import { IEmailHeaderGetKeyTrait } from './traits/get-key/email-header.get-key.trait';
import { IEmailHeaderGetValueTrait } from './traits/get-value/email-header.get-value.trait';
import { IEmailHeaderSetValueTrait } from './traits/set-value/email-header.set-value.trait';
import { IEmailHeaderSetKeyTrait } from './traits/set-key/email-header.set-key.trait';

export interface IEmailHeader extends //
  IEmailHeaderGetKeyTrait,
  IEmailHeaderSetKeyTrait,
  IEmailHeaderGetValueTrait,
  IEmailHeaderSetValueTrait,
  IToStringTrait
  //
{
}
