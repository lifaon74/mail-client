import { IEmailHeaderSetValueFunction } from './email-header.set-value.function-definition';

export interface IEmailHeaderSetValueTrait {
  setValue: IEmailHeaderSetValueFunction;
}
