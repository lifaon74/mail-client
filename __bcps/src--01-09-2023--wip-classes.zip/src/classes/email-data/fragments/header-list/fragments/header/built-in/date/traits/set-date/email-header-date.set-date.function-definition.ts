export interface IEmailHeaderDateSetDateFunction {
  (
    date: Date,
  ): void;
}
