import { IMimeType } from '../../../../../../../../../mime-type/mime-type.type';

export interface IEmailHeaderContentTypeGetMimeTypeFunction {
  (): IMimeType;
}
