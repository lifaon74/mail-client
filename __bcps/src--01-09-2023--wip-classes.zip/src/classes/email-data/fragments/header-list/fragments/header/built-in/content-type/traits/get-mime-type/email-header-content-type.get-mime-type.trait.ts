import { IEmailHeaderContentTypeGetMimeTypeFunction } from './email-header-content-type.get-mime-type.function-definition';

export interface IEmailHeaderContentTypeGetMimeTypeTrait {
  getMimeType: IEmailHeaderContentTypeGetMimeTypeFunction;
}
