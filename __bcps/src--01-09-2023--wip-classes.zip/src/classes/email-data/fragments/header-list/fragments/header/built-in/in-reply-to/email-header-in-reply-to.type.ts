import { IEmailHeaderMessageIdList } from '../shared/message-id/email-header-message-id-list/email-header-message-id-list.type';

export interface IEmailHeaderInReplyTo extends IEmailHeaderMessageIdList {
}
