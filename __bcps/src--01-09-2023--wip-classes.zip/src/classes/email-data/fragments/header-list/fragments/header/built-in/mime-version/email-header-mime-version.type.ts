import { IEmailHeader } from '../../email-header.type';

export interface IEmailHeaderMimeVersion extends IEmailHeader //
  //
{
}
