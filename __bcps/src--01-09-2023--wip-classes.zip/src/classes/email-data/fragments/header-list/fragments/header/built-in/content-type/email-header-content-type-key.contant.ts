export const EMAIL_HEADER_CONTENT_TYPE_KEY = 'Content-Type';

export type IEmailHeaderContentTypeKey = typeof EMAIL_HEADER_CONTENT_TYPE_KEY;

