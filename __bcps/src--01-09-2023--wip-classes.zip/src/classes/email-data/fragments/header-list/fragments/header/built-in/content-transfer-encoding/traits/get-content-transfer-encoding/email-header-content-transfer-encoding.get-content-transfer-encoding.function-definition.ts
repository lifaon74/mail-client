import { IContentTransferEncoding } from '../../content-transfer-encoding.type';

export interface IEmailHeaderContentTransferEncodingGetMimeTypeFunction {
  (): IContentTransferEncoding;
}
