import { IEmailHeaderDateSetDateFunction } from './email-header-date.set-date.function-definition';

export interface IEmailHeaderDateSetDateTrait {
  setDate: IEmailHeaderDateSetDateFunction;
}
