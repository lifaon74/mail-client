export interface IEmailHeaderGetValueFunction {
  (): string;
}
