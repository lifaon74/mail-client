export const HEADER_CC_KEY_NAME = 'Cc';
