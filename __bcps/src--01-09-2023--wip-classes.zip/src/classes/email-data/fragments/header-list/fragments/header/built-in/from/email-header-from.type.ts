import { IEmailHeaderContactList } from '../shared/email-concat/email-header-contact-list/email-header-contact-list.type';

export interface IEmailHeaderFrom extends IEmailHeaderContactList {
}
