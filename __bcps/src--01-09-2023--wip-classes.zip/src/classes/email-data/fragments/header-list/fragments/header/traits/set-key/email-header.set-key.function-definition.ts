export interface IEmailHeaderSetKeyFunction {
  (
    key: string,
  ): void;
}
