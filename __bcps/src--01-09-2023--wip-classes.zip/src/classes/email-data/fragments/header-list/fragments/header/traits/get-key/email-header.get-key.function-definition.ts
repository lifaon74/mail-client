export interface IEmailHeaderGetKeyFunction {
  (): string;
}
