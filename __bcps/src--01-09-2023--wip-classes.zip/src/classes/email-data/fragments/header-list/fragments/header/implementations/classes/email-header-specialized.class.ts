import { IEmailHeader } from '../../email-header.type';
import { HEADER_BCC_KEY_NAME } from '../../built-in/bcc/header-bcc-key.contant';
import { createEmailHeaderBccFromValueString } from '../../built-in/bcc/create-email-header-bcc-from-value-string';
import { HEADER_CC_KEY_NAME } from '../../built-in/cc/header-cc-key.contant';
import { createEmailHeaderCcFromValueString } from '../../built-in/cc/create-email-header-cc-from-value-string';
import {
  HEADER_CONTENT_TRANSFER_ENCODING_KEY_NAME,
} from '../../built-in/content-transfer-encoding/header-content-transfer-encoding-key.contant';
import {
  createEmailHeaderContentTransferEncodingFromValueString,
} from '../../built-in/content-transfer-encoding/create-email-header-content-transfer-encoding-from-value-string';
import { EMAIL_HEADER_CONTENT_TYPE_KEY } from '../../built-in/content-type/email-header-content-type-key.contant';
import { EMAIL_HEADER_DATE_KEY } from '../../built-in/date/email-header-date-key.contant';
import { HEADER_FROM_KEY_NAME } from '../../built-in/from/header-from-key.contant';
import { createEmailHeaderFromFromValueString } from '../../built-in/from/create-email-header-from-from-value-string';
import { HEADER_IN_REPLY_TO_KEY_NAME } from '../../built-in/in-reply-to/header-in-reply-to-key.contant';
import { createEmailHeaderInReplyToFromValueString } from '../../built-in/in-reply-to/create-email-header-in-reply-to-from-value-string';
import { HEADER_MESSAGE_ID_KEY_NAME } from '../../built-in/message-id/header-message-id-key.contant';
import { createEmailHeaderMessageIdFromValueString } from '../../built-in/message-id/create-email-header-message-id-from-value-string';
import { HEADER_MIME_VERSION_KEY_NAME } from '../../built-in/mime-version/header-mime-version-key.contant';
import {
  createEmailHeaderMimeVersionFromValueString,
} from '../../built-in/mime-version/create-email-header-mime-version-from-value-string';
import { HEADER_REFERENCES_KEY_NAME } from '../../built-in/references/header-references-key.contant';
import { createEmailHeaderReferencesFromValueString } from '../../built-in/references/create-email-header-references-from-value-string';
import { HEADER_REPLY_TO_KEY_NAME } from '../../built-in/reply-to/header-reply-to-key.contant';
import { createEmailHeaderReplyToFromValueString } from '../../built-in/reply-to/create-email-header-reply-to-from-value-string';
import { HEADER_SENDER_KEY_NAME } from '../../built-in/sender/header-sender-key.contant';
import { createEmailHeaderSenderFromValueString } from '../../built-in/sender/create-email-header-sender-from-value-string';
import { HEADER_SUBJECT_KEY_NAME } from '../../built-in/subject/header-subject-key.contant';
import { createEmailHeaderSubjectFromValueString } from '../../built-in/subject/create-email-header-subject-from-value-string';
import { HEADER_TO_KEY_NAME } from '../../built-in/to/header-to-key.contant';
import { createEmailHeaderToFromValueString } from '../../built-in/to/create-email-header-to-from-value-string';
import { EmailHeader } from './email-header.class';
import { EmailHeaderDate } from '../../built-in/date/implementations/classes/email-header-date.class';
import { EmailHeaderContentType } from '../../built-in/content-type/implementations/classes/email-header-content-type.class';

export abstract class EmailHeaderSpecialized<GKey extends string> implements IEmailHeader {
  static parse(
    input: string,
  ): IEmailHeader {
    const index: number = input.indexOf(': ');

    // TODO improve parsing
    // TODO handle index === -1

    return this.create(
      input.slice(0, index),
      input.slice(index + 2),
    );
  }

  static create(
    key: string,
    value: string,
  ): IEmailHeader {
    if (key === HEADER_BCC_KEY_NAME) {
      return createEmailHeaderBccFromValueString(value);
    } else if (key === HEADER_CC_KEY_NAME) {
      return createEmailHeaderCcFromValueString(value);
    } else if (key === HEADER_CONTENT_TRANSFER_ENCODING_KEY_NAME) {
      return createEmailHeaderContentTransferEncodingFromValueString(value);
    } else if (key === EMAIL_HEADER_CONTENT_TYPE_KEY) {
      return new EmailHeaderContentType(value);
    } else if (key === EMAIL_HEADER_DATE_KEY) {
      return new EmailHeaderDate(value);
    } else if (key === HEADER_FROM_KEY_NAME) {
      return createEmailHeaderFromFromValueString(value);
    } else if (key === HEADER_IN_REPLY_TO_KEY_NAME) {
      return createEmailHeaderInReplyToFromValueString(value);
    } else if (key === HEADER_MESSAGE_ID_KEY_NAME) {
      return createEmailHeaderMessageIdFromValueString(value);
    } else if (key === HEADER_MIME_VERSION_KEY_NAME) {
      return createEmailHeaderMimeVersionFromValueString(value);
    } else if (key === HEADER_REFERENCES_KEY_NAME) {
      return createEmailHeaderReferencesFromValueString(value);
    } else if (key === HEADER_REPLY_TO_KEY_NAME) {
      return createEmailHeaderReplyToFromValueString(value);
    } else if (key === HEADER_SENDER_KEY_NAME) {
      return createEmailHeaderSenderFromValueString(value);
    } else if (key === HEADER_SUBJECT_KEY_NAME) {
      return createEmailHeaderSubjectFromValueString(value);
    } else if (key === HEADER_TO_KEY_NAME) {
      return createEmailHeaderToFromValueString(value);
    } else {
      return new EmailHeader(
        key,
        value,
      );
    }
  }

  readonly #key: GKey;

  protected constructor(
    key: GKey,
  ) {
    this.#key = key;
  }

  getKey(): GKey {
    return this.#key;
  }

  setKey(): void {
    throw new Error(`Key is readonly`);
  }

  abstract getValue(): string;

  abstract setValue(
    value: string,
  ): void;

  toString(): string {
    return `${this.getKey()}: ${this.getValue()}`;
  }
}

