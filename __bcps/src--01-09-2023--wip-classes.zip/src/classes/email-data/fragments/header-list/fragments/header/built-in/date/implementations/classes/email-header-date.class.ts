import { IEmailHeaderDate } from '../../email-header-date.type';
import { formatDateToEmailDataDateHeader } from '../../functions/format-date-to-email-data-date-header';
import { EMAIL_HEADER_DATE_KEY, IEmailHeaderDateKey } from '../../email-header-date-key.contant';
import { convertEmailDataDateHeaderToDate } from '../../functions/convert-email-data-date-header-to-date';
import { EmailHeaderSpecialized } from '../../../../implementations/classes/email-header-specialized.class';

export class EmailHeaderDate extends EmailHeaderSpecialized<IEmailHeaderDateKey> implements IEmailHeaderDate {
  static now(): EmailHeaderDate {
    return new EmailHeaderDate(new Date());
  }

  #date!: Date;

  constructor(
    date: Date | string,
  ) {
    super(EMAIL_HEADER_DATE_KEY);
    if (typeof date === 'string') {
      this.setValue(date);
    } else {
      this.setDate(date);
    }
  }

  override getValue(): string {
    return formatDateToEmailDataDateHeader(this.#date);
  }

  override setValue(
    value: string,
  ): void {
    this.#date = convertEmailDataDateHeaderToDate(value);
  }

  getDate(): Date {
    return this.#date;
  }

  setDate(
    date: Date,
  ): void {
    this.#date = date;
  }
}
