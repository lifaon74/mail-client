export const HEADER_MIME_VERSION_KEY_NAME = 'MIME-Version';
