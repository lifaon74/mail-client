export interface IEmailHeaderDateGetDateFunction {
  (): Date;
}
