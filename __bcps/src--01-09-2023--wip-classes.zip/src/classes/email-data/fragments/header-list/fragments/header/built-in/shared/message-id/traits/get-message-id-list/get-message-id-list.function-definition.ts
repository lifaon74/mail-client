import { IMessageIdList } from '../../message-id-list/message-id-list.type';

export interface IGetMessageIdListFunction {
  (): IMessageIdList;
}
