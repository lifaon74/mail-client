import { IEmailHeader } from '../../email-header.type';

export class EmailHeader implements IEmailHeader {
  static parse(
    input: string,
  ): EmailHeader {
    const index: number = input.indexOf(': ');

    return new EmailHeader(
      input.slice(0, index),
      input.slice(index + 2),
    );
  }

  #key!: string;
  #value!: string;

  constructor(
    key: string,
    value: string,
  ) {
    this.setKey(key);
    this.setValue(value);
  }

  getKey(): string {
    return this.#key;
  }

  setKey(
    key: string,
  ): void {
    this.#key = key;
  }

  getValue(): string {
    return this.#value;
  }

  setValue(
    value: string,
  ): void {
    this.#value = value;
  }

  toString(): string {
    return `${this.getKey()}: ${this.getValue()}`;
  }
}

