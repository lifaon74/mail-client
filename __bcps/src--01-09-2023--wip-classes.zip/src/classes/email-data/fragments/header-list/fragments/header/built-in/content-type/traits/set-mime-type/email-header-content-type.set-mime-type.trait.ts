import { IEmailHeaderContentTypeSetMimeTypeFunction } from './email-header-content-type.set-mime-type.function-definition';

export interface IEmailHeaderContentTypeSetMimeTypeTrait {
  setMimeType: IEmailHeaderContentTypeSetMimeTypeFunction;
}
