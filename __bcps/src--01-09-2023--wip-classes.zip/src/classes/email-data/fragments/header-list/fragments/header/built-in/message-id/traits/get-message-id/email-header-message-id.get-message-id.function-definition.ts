import { IMessageId } from '../../../../../../../../../message-id/message-id.type';

export interface IEmailHeaderMessageIdGetMessageIdFunction {
  (): IMessageId;
}
