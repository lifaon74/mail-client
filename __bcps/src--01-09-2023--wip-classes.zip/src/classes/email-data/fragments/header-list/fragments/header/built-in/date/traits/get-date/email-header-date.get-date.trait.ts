import { IEmailHeaderDateGetDateFunction } from './email-header-date.get-date.function-definition';

export interface IEmailHeaderDateGetDateTrait {
  getDate: IEmailHeaderDateGetDateFunction;
}
