import { IMimeType } from '../../../../../../../../../mime-type/mime-type.type';

export interface IEmailHeaderContentTypeSetMimeTypeFunction {
  (
    mimeType: IMimeType,
  ): void;
}
