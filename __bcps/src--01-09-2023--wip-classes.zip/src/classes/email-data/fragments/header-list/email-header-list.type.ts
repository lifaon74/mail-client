import { IToStringTrait } from '@lifaon/traits';
import { IEmailHeaderListGetTrait } from './traits/get/email-header-list.get.trait';
import { IEmailHeaderListSetTrait } from './traits/set/email-header-list.set.trait';
import { IEmailHeaderListToMapTrait } from './traits/to-map/email-header-list.to-map.trait';

export interface IEmailHeaderList extends //
  IEmailHeaderListGetTrait,
  IEmailHeaderListSetTrait,
  IEmailHeaderListToMapTrait,
  IToStringTrait
  //
{
}
