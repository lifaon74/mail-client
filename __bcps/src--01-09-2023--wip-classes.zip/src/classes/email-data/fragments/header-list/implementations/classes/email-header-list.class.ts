import { IEmailHeaderList } from '../../email-header-list.type';
import { IEmailHeader } from '../../fragments/header/email-header.type';
import { CRLF } from '../../../../../../constants/crlf';
import { IEmailHeaderListDedup } from '../../traits/set/email-header-list.set.function-definition';
import { EmailHeader } from '../../fragments/header/implementations/classes/email-header.class';

/** CLASS **/

export class EmailHeaderList implements IEmailHeaderList {
  static parse(
    input: string,
    dedup?: IEmailHeaderListDedup,
  ): EmailHeaderList {
    const headers: string[] = [];

    const appendLine = (
      line: string,
    ): void => {
      if (
        line.startsWith(' ')
        || line.startsWith('\t')
      ) {
        if (headers.length === 0) {
          throw new Error(`Not an header list`);
        } else {
          headers[headers.length - 1] += line;
        }
      } else {
        headers.push(line);
      }
    };

    let position: number = 0;

    while (true) {
      const index: number = input.indexOf(CRLF, position);
      if (index === -1) {
        appendLine(input.slice(position));
        break;
      } else {
        appendLine(input.slice(position, index));
        position = index + 2;
      }
    }

    return new EmailHeaderList(
      headers.map(EmailHeader.parse),
      dedup,
    );
  }

  static fromIterable(
    headers: Iterable<[string, string]>,
    dedup?: IEmailHeaderListDedup,
  ): EmailHeaderList {
    return new EmailHeaderList(
      (Array.isArray(headers) ? headers : Array.from(headers)).map(([key, value]): EmailHeader => {
        return new EmailHeader(key, value);
      }),
      dedup,
    );
  }

  #headers!: readonly IEmailHeader[];

  constructor(
    parameters: readonly IEmailHeader[] = [],
    dedup?: IEmailHeaderListDedup,
  ) {
    this.set(parameters, dedup);
  }

  get(): readonly IEmailHeader[] {
    return this.#headers;
  }

  set(
    parameters: readonly IEmailHeader[],
    dedup: IEmailHeaderListDedup = 'none',
  ): void {
    if (dedup === 'none') {
      this.#headers = parameters;
    } else {
      const map: Map<string, IEmailHeader> = new Map<string, IEmailHeader>();

      for (let i = 0, l = parameters.length; i < l; i++) {
        const parameter: IEmailHeader = parameters[i];
        const key: string = parameter.getKey().toString();

        if (map.has(key) && (dedup === 'throw')) {
          throw new Error(`Key already exists`);
        } else {
          map.set(key, parameter);
        }
      }

      this.#headers = Array.from(map.values());
    }
  }

  toMap(): Map<string, string> {
    return new Map(
      this.get().map((header: IEmailHeader): [string, string] => {
        return [
          header.getKey().toString(),
          header.getValue().toString(),
        ];
      }),
    );
  }

  toString(): string {
    let output: string = '';
    const parameters: readonly IEmailHeader[] = this.get();

    for (let i = 0, l = parameters.length; i < l; i++) {
      const header: IEmailHeader = parameters[i];
      if (i > 0) {
        output += CRLF;
      }
      output += header.toString();
    }

    return output;
  }
}
