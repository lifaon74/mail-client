import { IEmailHeaderListSetFunction } from './email-header-list.set.function-definition';

export interface IEmailHeaderListSetTrait {
  set: IEmailHeaderListSetFunction;
}
