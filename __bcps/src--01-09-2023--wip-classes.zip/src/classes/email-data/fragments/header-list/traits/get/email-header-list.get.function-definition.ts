import { IEmailHeader } from '../../fragments/header/email-header.type';

export interface IEmailHeaderListGetFunction {
  (): readonly IEmailHeader[];
}
