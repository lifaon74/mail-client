import { IEmailHeaderListGetFunction } from './email-header-list.get.function-definition';

export interface IEmailHeaderListGetTrait {
  get: IEmailHeaderListGetFunction;
}
