import { IEmailHeaderListToMapFunction } from './email-header-list.to-map.function-definition';

export interface IEmailHeaderListToMapTrait {
  toMap: IEmailHeaderListToMapFunction;
}
