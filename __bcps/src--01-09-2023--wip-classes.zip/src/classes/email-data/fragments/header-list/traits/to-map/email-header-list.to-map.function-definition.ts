export interface IEmailHeaderListToMapFunction {
  (): Map<string, string>;
}
