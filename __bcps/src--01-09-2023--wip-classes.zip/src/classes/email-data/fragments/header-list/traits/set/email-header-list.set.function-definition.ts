import { IEmailHeader } from '../../fragments/header/email-header.type';

export type IEmailHeaderListDedup =
  | 'none'
  | 'keep-last'
  | 'throw'
  ;

export interface IEmailHeaderListSetFunction {
  (
    parameters: readonly IEmailHeader[],
    dedup?: IEmailHeaderListDedup,
  ): void;
}
