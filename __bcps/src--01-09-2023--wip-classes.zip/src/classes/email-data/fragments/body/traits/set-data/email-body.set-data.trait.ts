import { IEmailBodySetDataFunction } from './email-body.set-data.function-definition';

export interface IEmailBodySetDataTrait {
  setData: IEmailBodySetDataFunction;
}
