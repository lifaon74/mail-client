import { IEmailBodyGetDataFunction } from './email-body.get-data.function-definition';

export interface IEmailBodyGetDataTrait {
  getData: IEmailBodyGetDataFunction;
}
