export type IEmailBodySetDataType =
  | 'raw'
  | 'binary-string-as-base64'
  | 'text-as-base64'
;

export interface IEmailBodySetDataFunction {
  (
    data: string,
    type?: IEmailBodySetDataType,
  ): void;
}
