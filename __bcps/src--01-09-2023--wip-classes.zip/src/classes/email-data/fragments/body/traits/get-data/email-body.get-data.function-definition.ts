export interface IEmailBodyGetDataFunction {
  (): string;
}
