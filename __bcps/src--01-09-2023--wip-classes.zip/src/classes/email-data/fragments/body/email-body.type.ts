import { IToStringTrait } from '@lifaon/traits';
import { IEmailBodyGetDataTrait } from './traits/get-data/email-body.get-data.trait';
import { IEmailBodySetDataTrait } from './traits/set-data/email-body.set-data.trait';

export interface IEmailBody extends //
  IEmailBodyGetDataTrait,
  IEmailBodySetDataTrait,
  IToStringTrait
  //
{
}
