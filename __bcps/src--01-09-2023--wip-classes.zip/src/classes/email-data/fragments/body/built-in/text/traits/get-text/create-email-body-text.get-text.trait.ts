import { IEmailBodyTextGetTextFunction } from './create-email-body-text.get-text.function-definition';

export interface IEmailBodyTextGetTextTrait {
  getText: IEmailBodyTextGetTextFunction;
}
