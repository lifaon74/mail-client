export interface IEmailBodyTextGetTextFunction {
  (): string;
}
