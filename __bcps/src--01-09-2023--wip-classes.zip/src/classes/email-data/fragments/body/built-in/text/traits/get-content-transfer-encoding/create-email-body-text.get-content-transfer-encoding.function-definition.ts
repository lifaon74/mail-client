import {
  IContentTransferEncoding
} from '../../../../../header-list/fragments/header/built-in/content-transfer-encoding/content-transfer-encoding.type';

export interface IEmailBodyTextGetContentTransferEncodingFunction {
  (): IContentTransferEncoding;
}
