import { IEmailBodyTextGetContentTransferEncodingFunction } from './create-email-body-text.get-content-transfer-encoding.function-definition';

export interface IEmailBodyTextGetContentTransferEncodingTrait {
  getContentTransferEncoding: IEmailBodyTextGetContentTransferEncodingFunction;
}
