import { IEmailBody } from '../../email-body.type';
import { EMAIL_DATA_MAX_LINE_LENGTH } from '../../../../misc/line-length-limits';
import { CRLF } from '../../../../../../constants/crlf';
import { IEmailBodySetDataType } from '../../traits/set-data/email-body.set-data.function-definition';

export class EmailBody implements IEmailBody {
  #data!: string;

  constructor(
    data: string,
    type?: IEmailBodySetDataType,
  ) {
    this.setData(data, type);
  }

  getData(): string {
    return this.#data;
  }

  setData(
    data: string,
    type: IEmailBodySetDataType = 'raw',
  ): void {
    if (type === 'raw') {
      this.#data = data;
    } else if (type === 'binary-string-as-base64') {
      this.#data = btoa(data)
        .replace(
          new RegExp(`(.{${EMAIL_DATA_MAX_LINE_LENGTH}})`, 'g'),
          (_, chunk: string) => `${chunk}${CRLF}`,
        );
    } else {
      this.setData(
        String.fromCodePoint.apply(null, new TextEncoder().encode(data)),
        'binary-string-as-base64',
      );
    }
  }

  toString(): string {
    return this.getData();
  }
}
