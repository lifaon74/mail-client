export interface IEmailDataTextHTMLGetHTMLFunction {
  (): string;
}
