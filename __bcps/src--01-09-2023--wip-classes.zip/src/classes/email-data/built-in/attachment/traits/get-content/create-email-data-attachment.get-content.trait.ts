import { IEmailDataAttachmentGetContentFunction } from './create-email-data-attachment.get-content.function-definition';

export interface IEmailDataAttachmentGetContentTrait {
  getContent: IEmailDataAttachmentGetContentFunction;
}
