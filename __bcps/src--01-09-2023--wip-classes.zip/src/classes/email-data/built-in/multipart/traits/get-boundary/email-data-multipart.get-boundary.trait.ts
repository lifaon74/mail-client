import { IEmailDataMultipartGetBoundaryFunction } from './email-data-multipart.get-boundary.function-definition';

export interface IEmailDataMultipartGetBoundaryTrait {
  getBoundary: IEmailDataMultipartGetBoundaryFunction;
}
