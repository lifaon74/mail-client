export interface IEmailDataMultipartGetBoundaryFunction {
  (): string;
}
