import { IEmailContactSetNameFunction } from './email-contact.set-name.function-definition';

export interface IEmailContactSetNameTrait {
  setName: IEmailContactSetNameFunction;
}
