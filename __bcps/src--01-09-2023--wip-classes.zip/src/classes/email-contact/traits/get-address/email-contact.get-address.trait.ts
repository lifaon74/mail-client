import { IEmailContactGetAddressFunction } from './email-contact.get-address.function-definition';

export interface IEmailContactGetAddressTrait {
  getAddress: IEmailContactGetAddressFunction;
}
