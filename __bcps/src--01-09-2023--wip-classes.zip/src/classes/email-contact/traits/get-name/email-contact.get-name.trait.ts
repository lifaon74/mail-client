import { IEmailContactGetNameFunction } from './email-contact.get-name.function-definition';

export interface IEmailContactGetNameTrait {
  getName: IEmailContactGetNameFunction;
}
