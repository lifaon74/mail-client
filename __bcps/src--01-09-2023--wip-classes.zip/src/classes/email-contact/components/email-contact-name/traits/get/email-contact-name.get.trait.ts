import { IEmailContactNameGetFunction } from './email-contact-name.get.function-definition';

export interface IEmailContactNameGetTrait {
  get: IEmailContactNameGetFunction;
}
