export interface IEmailContactNameRequiresQuotingFunction {
  (): boolean;
}
