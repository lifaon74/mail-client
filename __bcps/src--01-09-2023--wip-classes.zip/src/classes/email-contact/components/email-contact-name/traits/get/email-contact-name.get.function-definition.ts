export interface IEmailContactNameGetFunction {
  (): string;
}
