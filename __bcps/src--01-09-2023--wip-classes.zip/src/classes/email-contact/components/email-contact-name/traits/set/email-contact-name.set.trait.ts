import { IEmailContactNameSetFunction } from './email-contact-name.set.function-definition';

export interface IEmailContactNameSetTrait {
  set: IEmailContactNameSetFunction;
}
