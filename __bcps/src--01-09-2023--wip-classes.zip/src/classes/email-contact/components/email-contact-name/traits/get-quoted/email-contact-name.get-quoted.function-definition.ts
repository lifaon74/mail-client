export interface IEmailContactNameGetQuotedFunction {
  (): string;
}
