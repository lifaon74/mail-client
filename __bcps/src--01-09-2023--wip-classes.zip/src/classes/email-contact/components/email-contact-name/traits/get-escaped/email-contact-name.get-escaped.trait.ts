import { IEmailContactNameGetEscapedFunction } from './email-contact-name.get-escaped.function-definition';

export interface IEmailContactNameGetEscapedTrait {
  getEscaped: IEmailContactNameGetEscapedFunction;
}
