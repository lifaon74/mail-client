import { IEmailContactNameGetQuotedFunction } from './email-contact-name.get-quoted.function-definition';

export interface IEmailContactNameGetQuotedTrait {
  getQuoted: IEmailContactNameGetQuotedFunction;
}
