export interface IEmailContactNameSetFunction {
  (
    value: string,
  ): void;
}
