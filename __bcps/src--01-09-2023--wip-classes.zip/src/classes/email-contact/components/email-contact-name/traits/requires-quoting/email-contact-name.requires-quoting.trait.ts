import { IEmailContactNameRequiresQuotingFunction } from './email-contact-name.requires-quoting.function-definition';

export interface IEmailContactNameRequiresQuotingTrait {
  requiresQuoting: IEmailContactNameRequiresQuotingFunction;
}
