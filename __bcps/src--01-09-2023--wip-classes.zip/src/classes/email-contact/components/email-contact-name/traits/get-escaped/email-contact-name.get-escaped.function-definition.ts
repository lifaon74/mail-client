export interface IEmailContactNameGetEscapedFunction {
  (): string;
}
