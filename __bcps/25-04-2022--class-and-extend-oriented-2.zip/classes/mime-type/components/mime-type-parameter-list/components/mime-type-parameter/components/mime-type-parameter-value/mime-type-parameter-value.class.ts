import { HTTP_QUOTED_STRING_TOKEN_PATTERN } from '../../../../../../../../constants/http-quoted-string-token-pattern.constant';
import { HTTP_TOKEN_PATTERN } from '../../../../../../../../constants/http-token-pattern.constant';

export const MIME_TYPE_PARAMETER_VALUE_NON_QUOTED_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const MIME_TYPE_PARAMETER_VALUE_NON_QUOTED_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_VALUE_NON_QUOTED_PATTERN}$`);

export const MIME_TYPE_PARAMETER_VALUE_QUOTED_PATTERN = `${HTTP_QUOTED_STRING_TOKEN_PATTERN}+`;
const MIME_TYPE_PARAMETER_VALUE_QUOTED_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_VALUE_QUOTED_PATTERN}$`);

export const MIME_TYPE_PARAMETER_VALUE_STRING_QUOTED_PATTERN = `"(?:[\\u0009\\u0020-\\u0021\\u0023-\\u005b\\u005d-\\u007e\\u0080-\\u00ff]|(?:\\\\")|(?:\\\\\\\\))+"`;
const MIME_TYPE_PARAMETER_VALUE_STRING_QUOTED_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_VALUE_STRING_QUOTED_PATTERN}$`);

export const MIME_TYPE_PARAMETER_VALUE_STRING_PATTERN = `(?:${MIME_TYPE_PARAMETER_VALUE_NON_QUOTED_PATTERN})|(?:${MIME_TYPE_PARAMETER_VALUE_STRING_QUOTED_PATTERN})`;

// const NAME_AND_VALUE_REGEXP: RegExp = new RegExp(`\\s*(${HTTP_TOKEN_PATTERN}+)(?:=(${HTTP_TOKEN_PATTERN}+|(?:"(?:${HTTP_TOKEN_PATTERN}|(?:\\\\")|(?:\\\\\\\\))+")))?\\s*(?:;|$)`, 'g');

export class MimeTypeParameterValue {
  static fromString(
    input: string,
  ): MimeTypeParameterValue {
    if (MIME_TYPE_PARAMETER_VALUE_NON_QUOTED_REGEXP.test(input)) {
      return newMimeTypeParameterValue(input, true);
    } else if (MIME_TYPE_PARAMETER_VALUE_STRING_QUOTED_REGEXP.test(input)) {
      return newMimeTypeParameterValue(unquoteMimeTypeParameterValueStringQuoted(input));
    } else {
      throw new Error(`Invalid value`);
    }
  }

  protected _value!: string;
  protected _requiresQuoting!: boolean; // computed

  protected constructor() {
  }

  get(): string {
    return this._value;
  }

  set(value: string): void {
    if (MIME_TYPE_PARAMETER_VALUE_NON_QUOTED_REGEXP.test(value)) {
      this._value = value;
      this._requiresQuoting = false;
    } else if (MIME_TYPE_PARAMETER_VALUE_QUOTED_REGEXP.test(value)) {
      this._value = value;
      this._requiresQuoting = true;
    } else {
      throw new Error(`Invalid value`);
    }
  }

  requiresQuoting(): boolean {
    return this._requiresQuoting;
  }

  getEscaped(): string {
    return this._value
      .replace('\\', '\\\\')
      .replace('"', '\\"')
      ;
  }

  getQuoted(): string {
    return `"${this.getEscaped()}"`;
  }

  toString(): string {
    return this.requiresQuoting()
      ? this.getQuoted()
      : this.get();
  }
}

/** FUNCTIONS **/

export function unquoteMimeTypeParameterValueStringQuoted(
  input: string,
): string {
  return input
    .slice(1, -1)
    .replace('\\', '');
}

/*--------------*/

export function newMimeTypeParameterValue(
  value: string,
  requiresQuoting: boolean = !MIME_TYPE_PARAMETER_VALUE_NON_QUOTED_REGEXP.test(value),
): MimeTypeParameterValue {
  type GMimeTypeParameterValue = any;
  const instance: GMimeTypeParameterValue = new (MimeTypeParameterValue as any)();
  instance._value = value;
  instance._requiresQuoting = requiresQuoting;
  return instance;
}

