import { HTTP_TOKEN_PATTERN } from '../../constants/http-token-pattern.constant';
import { MimeTypeParameterList, newMimeTypeParameterList } from './components/mime-type-parameter-list/mime-type-parameter-list.class';

const TYPE_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const TYPE_REGEXP = new RegExp(`^${TYPE_PATTERN}$`, 'g');

const SUBTYPE_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const SUBTYPE_REGEXP = new RegExp(`^${TYPE_PATTERN}$`, 'g');

const TYPE_AND_SUBTYPE_REGEXP: RegExp = new RegExp(`^(${TYPE_PATTERN})/(${SUBTYPE_PATTERN})$`);

/*
https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types
 */

export class MimeType {
  static fromString(
    input: string,
  ): MimeType {
    const index: number = input.indexOf(';');
    let typeAndSubtype: string;
    let parameters: string;

    if (index === -1) {
      typeAndSubtype = input;
      parameters = '';
    } else {
      typeAndSubtype = input.slice(0, index);
      parameters = input.slice(index + 1);
    }

    const match: RegExpExecArray | null = TYPE_AND_SUBTYPE_REGEXP.exec(typeAndSubtype);

    if (match === null) {
      throw new Error(`Invalid type or subtype`);
    } else {
      return newMimeType(
        match[1],
        match[2],
        (parameters === '')
          ? newMimeTypeParameterList()
          : MimeTypeParameterList.fromString(parameters),
      );
    }
  }

  protected _type!: string;
  protected _subtype!: string;
  protected _parameters!: MimeTypeParameterList;

  protected constructor() {
  }

  get type(): string {
    return this._type;
  }

  set type(value: string) {
    if (TYPE_REGEXP.test(value)) {
      this._type = value;
    } else {
      throw new Error(`Invalid type`);
    }
  }

  get subtype(): string {
    return this._subtype;
  }

  set subtype(value: string) {
    if (SUBTYPE_REGEXP.test(value)) {
      this._type = value;
    } else {
      throw new Error(`Invalid subtype`);
    }
  }

  get parameters(): MimeTypeParameterList {
    return this._parameters;
  }

  toString(): string {
    const parametersString: string = (this._parameters.size === 0)
      ? ''
      : `; ${this._parameters.toString()}`;
    return `${this.type}/${this.subtype}${parametersString}`;
  }
}

/*--------------*/

export function newMimeType(
  type: string,
  subtype: string,
  parameters: MimeTypeParameterList,
): MimeType {
  type GMimeType = any;
  const instance: GMimeType = new (MimeType as any)();
  instance._type = type;
  instance._subtype = subtype;
  instance._parameters = parameters;
  return instance;
}
