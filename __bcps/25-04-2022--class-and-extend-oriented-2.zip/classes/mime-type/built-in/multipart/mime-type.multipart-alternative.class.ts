import {
  MimeTypeParameterListWithBoundary,
} from '../../components/mime-type-parameter-list/built-in/mime-type-parameter-list.with-boundary.class';
import {
  IGenerateBoundaryOptions,
} from '../../components/mime-type-parameter-list/components/mime-type-parameter/built-in/boundary/generate-boundary';
import { MimeTypeParameterList } from '../../components/mime-type-parameter-list/mime-type-parameter-list.class';
import { MimeTypeMultipart } from './mime-type.multipart.class';

export class MimeTypeMultipartAlternative extends MimeTypeMultipart {

  static override generate(
    options?: IGenerateBoundaryOptions,
  ): MimeTypeMultipartAlternative {
    return newMimeTypeMultipartAlternative(
      MimeTypeParameterListWithBoundary.generate(options),
    );
  }

  override get subtype(): 'alternative' {
    return 'alternative';
  }
}

/*--------------*/

export function newMimeTypeMultipartAlternative(
  parameters: MimeTypeParameterList,
): MimeTypeMultipartAlternative {
  type GMimeTypeMultipartAlternative = any;
  const instance: GMimeTypeMultipartAlternative = new (MimeTypeMultipartAlternative as any)();
  instance._parameters = parameters;
  return instance;
}
