import { CRLF } from '../../../../constants/crlf';

export class EmailBody {

  static fromTextAsBase64(
    text: string,
  ): EmailBody {
    return this.fromBinaryStringAsBase64(
      String.fromCodePoint.apply(null, new TextEncoder().encode(text)),
    );
  }

  static fromBinaryStringAsBase64(
    data: string,
  ): EmailBody {
    return new EmailBody(
      btoa(data).replace(/(.{76})/g, (_, chunk: string) => `${chunk}${CRLF}`),
    );
  }

  constructor(
    public readonly data: string,
  ) {
  }

  toString(): string {
    return this.data;
  }
}


