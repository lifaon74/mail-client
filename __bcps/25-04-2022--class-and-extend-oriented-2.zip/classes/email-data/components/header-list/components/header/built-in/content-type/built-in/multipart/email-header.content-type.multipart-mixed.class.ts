import { MimeTypeMultipartMixed } from '../../../../../../../../../mime-type/built-in/multipart/mime-type.multipart-mixed.class';
import {
  IGenerateBoundaryOptions,
} from '../../../../../../../../../mime-type/components/mime-type-parameter-list/components/mime-type-parameter/built-in/boundary/generate-boundary';
import { EmailHeaderContentTypeMultipart } from './email-header.content-type.multipart.class';

export class EmailHeaderContentTypeMultipartMixed extends EmailHeaderContentTypeMultipart {
  static override generate(
    options?: IGenerateBoundaryOptions,
  ): EmailHeaderContentTypeMultipartMixed {
    return new EmailHeaderContentTypeMultipartMixed(
      MimeTypeMultipartMixed.generate(options),
    );
  }

  constructor(
    mimeType: MimeTypeMultipartMixed,
  ) {
    super(mimeType);
  }
}

