import { EmailBodyText } from './email-body-text.class';
import { EmailBodyMultipart } from './email-body-multipart.class';


export type IEmailBody =
  | EmailBodyText
  | EmailBodyMultipart
;
