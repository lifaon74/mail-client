import { IEmailBody } from '../email-body/email-body.type';
import { EmailHeaders, IContentTransferEncoding } from '../email-headers/email-headers.class';
import { EmailBodyText } from '../email-body/email-body-text.class';
import { MIMEType } from '../../mime-type/mime-type.class';
import { CONTENT_TYPE_HEADER_NAME } from '../email-headers/well-known/content-type/content-type-header-name.constant';
import {
  CONTENT_TRANSFER_ENCODING_HEADER_NAME,
} from '../email-headers/well-known/content-transfer-encoding-header-name/content-transfer-encoding-header-name.constant';
import { CRLF, CRLF_LENGTH } from '../../../constants/crlf';
import { EmailBodyMultipart } from '../email-body/email-body-multipart.class';

/** CLASS **/

export class EmailData {
  static parse(
    input: string,
  ): EmailData {
    const index: number = input.indexOf(CRLF + CRLF);

    if ((index === -1) || !input.endsWith(CRLF)) {
      throw new Error(`Invalid EmailData`);
    } else {
      const headers: EmailHeaders = EmailHeaders.parse(input.slice(0, index));
      return new EmailData(
        headers,
        this.#parseBody(
          input.slice(index + CRLF_LENGTH + CRLF_LENGTH, -CRLF_LENGTH),
          headers,
        ),
      );
    }
  }

  static #parseBody(
    input: string,
    headers: EmailHeaders,
  ): IEmailBody {
    const contentType: MIMEType | undefined = headers.getContentType();

    if (contentType === void 0) {
      throw new Error(`Missing ${CONTENT_TYPE_HEADER_NAME} header.`);
    } else {
      const type: string = contentType!.type;

      if (type === 'text') {
        const contentTransferEncoding: IContentTransferEncoding | undefined = headers.getContentTransferEncoding();

        if (contentTransferEncoding === void 0) {
          throw new Error(`Missing ${CONTENT_TRANSFER_ENCODING_HEADER_NAME} header.`);
        } else {
          return EmailBodyText.parse(input, {
            contentTransferEncoding,
            // TODO charset
          });
        }
      } else if (type === 'multipart') {
        const boundary: string | undefined = contentType!.parameters.get('boundary');
        if (boundary === void 0) {
          throw new Error(`Found EmailBodyMultipart - expected ${CONTENT_TYPE_HEADER_NAME} with parameter "boundary".`);
        } else {
          return EmailBodyMultipart.parse(input, {
            boundary,
          });
        }
      } else {
        throw new Error(`Unknown type: ${type}`); // TODO generic
      }
    }
  }

  headers: EmailHeaders;
  body: IEmailBody;

  constructor(
    headers: EmailHeaders,
    body: IEmailBody,
  ) {
    this.headers = headers;
    this.body = body;
  }

  #bodyToString(): string {
    const contentType: MIMEType | undefined = this.headers.getContentType();

    if (contentType === void 0) {
      throw new Error(`Missing ${CONTENT_TYPE_HEADER_NAME} header.`);
    } else {
      const type: string = contentType!.type;

      if (this.body instanceof EmailBodyText) {
        if (type === 'text') {
          const contentTransferEncoding: IContentTransferEncoding | undefined = this.headers.getContentTransferEncoding();

          if (contentTransferEncoding === void 0) {
            throw new Error(`Missing ${CONTENT_TRANSFER_ENCODING_HEADER_NAME} header.`);
          } else {
            return this.body.toString({
              contentTransferEncoding,
            });
          }
        } else {
          throw new Error(`Found EmailBodyText - expected ${CONTENT_TYPE_HEADER_NAME} with type "text".`);
        }
      } else if (this.body instanceof EmailBodyMultipart) {
        if (type === 'multipart') {
          const boundary: string | undefined = contentType!.parameters.get('boundary');
          if (boundary === void 0) {
            throw new Error(`Found EmailBodyMultipart - expected ${CONTENT_TYPE_HEADER_NAME} with parameter "boundary".`);
          } else {
            return this.body.toString({
              boundary,
            });
          }
        } else {
          throw new Error(`Found EmailBodyMultipart - expected ${CONTENT_TYPE_HEADER_NAME} with type "multipart".`);
        }
      } else {
        throw new Error(`Unknown body type.`);
      }
    }
  }

  toString(): string {
    return this.headers.toString() + CRLF
      + CRLF
      + this.#bodyToString()
      + CRLF
      ;
  }
}


