export class Domain {
  static fromString(
    input: string,
  ): Domain {
    try {
      const url: URL = new URL(`https://${input}`);
      if (input === url.hostname) {
        return new Domain(input);
      } else {
        throw null;
      }
    } catch {
      throw new Error(`Invalid domain`);
    }
  }

  protected constructor(
    public readonly value: string,
  ) {
  }

  toString(): string {
    return this.value;
  }
}


