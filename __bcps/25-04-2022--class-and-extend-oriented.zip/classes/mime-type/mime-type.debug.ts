import { MimeTypeMultipartAlternative } from './built-in/multipart/mime-type.multipart-alternative.class';
import {
  MimeTypeParameterBoundary,
} from './components/mime-type-parameter-list/components/mime-type-parameter/built-in/boundary/mime-type-parameter.boundary.type';
import {
  MimeTypeParameterKey
} from './components/mime-type-parameter-list/components/mime-type-parameter/components/mime-type-parameter-key/mime-type-parameter-key.class';
import {
  MimeTypeParameterValue
} from './components/mime-type-parameter-list/components/mime-type-parameter/components/mime-type-parameter-value/mime-type-parameter-value.class';
import { MimeTypeParameter } from './components/mime-type-parameter-list/components/mime-type-parameter/mime-type-parameter.class';
import { MimeTypeParameterList } from './components/mime-type-parameter-list/mime-type-parameter-list.class';
import { MimeType } from './mime-type.class';

export function mimeTypeDebug(): void {
  // const data = new MimeTypeParameter(
  //   MimeTypeParameterKey.fromString('abc'),
  //   MimeTypeParameterValue.fromString('def'),
  // );

  // console.log(MimeTypeParameterValue.fromString('def').getQuoted());
  // console.log(MimeTypeParameterValue.fromString('"def"').getQuoted());
  // console.log(MimeTypeParameterValue.fromString('"de\\"f"').getQuoted());
  // console.log(MimeTypeParameterValue.fromString('"de\\\\f"').getQuoted());
  // console.log(MimeTypeParameterValue.fromString('de"f').getQuoted());
  // console.log(MimeTypeParameterValue.fromString('"de"f"').getQuoted());
  // console.log(MimeTypeParameterValue.fromString('"de\\\\"f"').getQuoted());

  // console.log(MimeTypeParameter.fromString('abc="def"').toString());
  // console.log(MimeTypeParameter.fromString('abc="a\\"h"').toString());


  // const data: MimeType = new MimeType(
  //   'multipart',
  //   'mixed',
  //   new MimeTypeParameterList([
  //     MimeTypeParameterBoundary.generate(),
  //   ]),
  // );

  // const data = MimeTypeMultipartAlternative.generate();
  // const data = MimeType.fromString(`application/octet-stream; name="test.bin"`);
  // const data = MimeTypeParameterList.fromString(`name="test.bin"`);
  // const data = MimeTypeParameterList.fromString(`name="test\\".bin"; abc="def"; bob `);
  // const data = MimeTypeParameterList.fromString(`abc="def"`);
  // const data = MimeTypeParameterList.fromString(`abc="def"; ghi`);
  // const data = MimeTypeParameterList.fromString(`abc="def" ;`);
  // const data = MimeTypeParameterList.fromString(`abc="def`);
  // const data = MimeTypeParameterList.fromString(`abc="def"; a=`);
  // const data = MimeTypeParameterList.fromString(`name="test\\\\".bin"`);
  const data = MimeTypeParameterList.fromString(`name="test\\".bin"`);

  console.log(data);
  console.log(data.toString());
}
