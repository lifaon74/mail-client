import { NEW } from '../../../../../constants/new.constant';
import { MimeTypeParameterList } from '../mime-type-parameter-list.class';

export const MIME_TYPE_PARAMETER_LIST_NONE_CONSTANT: MimeTypeParameterList = MimeTypeParameterList[NEW]();
