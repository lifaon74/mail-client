import { IGenerateBoundaryOptions } from '../components/mime-type-parameter/built-in/boundary/generate-boundary';
import { MimeTypeParameterBoundary } from '../components/mime-type-parameter/built-in/boundary/mime-type-parameter.boundary.type';
import { MimeTypeParameterList } from '../mime-type-parameter-list.class';

export type IMimeTypeParameterListWithBoundaryParameters = readonly [MimeTypeParameterBoundary];


export class MimeTypeParameterListWithBoundary extends MimeTypeParameterList {
  static generate(
    options?: IGenerateBoundaryOptions,
  ): MimeTypeParameterListWithBoundary {
    return new MimeTypeParameterListWithBoundary([
      MimeTypeParameterBoundary.generate(options),
    ]);
  }

  declare public readonly items: IMimeTypeParameterListWithBoundaryParameters;

  constructor(
    parameters: IMimeTypeParameterListWithBoundaryParameters,
  ) {
    super(
      parameters,
    );
  }
}
