import { NEW } from '../../../../../../constants/new.constant';
import { MIME_TYPE_PARAMETER_KEY_PATTERN, MimeTypeParameterKey } from './components/mime-type-parameter-key/mime-type-parameter-key.class';
import {
  MIME_TYPE_PARAMETER_VALUE_STRING_PATTERN,
  MimeTypeParameterValue,
  unquoteMimeTypeParameterValueStringQuoted,
} from './components/mime-type-parameter-value/mime-type-parameter-value.class';

export const MIME_TYPE_PARAMETER_PATTERN = `(${MIME_TYPE_PARAMETER_KEY_PATTERN})(?:=(${MIME_TYPE_PARAMETER_VALUE_STRING_PATTERN}))?`;
const MIME_TYPE_PARAMETER_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_PATTERN}$`);

// // const NAME_AND_VALUE_REGEXP: RegExp = new RegExp(`\\s*(${HTTP_TOKEN_PATTERN}+)(?:=(${HTTP_TOKEN_PATTERN}+|(?:"(?:${HTTP_TOKEN_PATTERN}|(?:\\\\")|(?:\\\\\\\\))+")))?\\s*(?:;|$)`, 'g');

export class MimeTypeParameter {
  static fromString(
    input: string,
  ): MimeTypeParameter {
    const match: RegExpExecArray | null = MIME_TYPE_PARAMETER_REGEXP.exec(input);
    if (match === null) {
      throw new Error(`Invalid parameter`);
    } else {
      const [, keyString, valueString] = match;

      const key: MimeTypeParameterKey = MimeTypeParameterKey[NEW](keyString);

      const value: MimeTypeParameterValue | null = (valueString === void 0)
        ? null
        : MimeTypeParameterValue[NEW](
          valueString.startsWith('"')
            ? unquoteMimeTypeParameterValueStringQuoted(valueString)
            : valueString,
        );

      return new MimeTypeParameter(
        key,
        value,
      );
    }
  }

  constructor(
    public key: MimeTypeParameterKey,
    public value: MimeTypeParameterValue | null,
  ) {
  }

  hasEmptyValue(): boolean {
    return (this.value === null)
      || (this.value.get() === '');
  }

  toString(): string {
    return this.hasEmptyValue()
      ? this.key.toString()
      : `${this.key.toString()}=${(this.value as MimeTypeParameterValue).toString()}`;
  }
}
