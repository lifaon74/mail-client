import { EmailBody } from '../../components/body/email-body.class';
import {
  EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_BASE64_CONSTANT,
} from '../../components/header-list/components/header/built-in/content-transfer-encoding/built-in/email-header.content-transfer-encoding.base64.constant';
import {
  EMAIL_HEADER_CONTENT_TYPE_TEXT_PLAIN_UTF8_CONSTANT,
} from '../../components/header-list/components/header/built-in/content-type/built-in/email-header.content-type.text-plain.utf8.constant';
import { EmailHeaderList } from '../../components/header-list/email-header-list.class';
import { EmailData } from '../../email-data.class';

export class EmailDataTextPlain extends EmailData {
  constructor(
    public readonly text: string,
  ) {
    super(
      new EmailHeaderList([
        EMAIL_HEADER_CONTENT_TYPE_TEXT_PLAIN_UTF8_CONSTANT,
        EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_BASE64_CONSTANT,
      ]),
      EmailBody.fromTextAsBase64(text),
    );
  }
}

