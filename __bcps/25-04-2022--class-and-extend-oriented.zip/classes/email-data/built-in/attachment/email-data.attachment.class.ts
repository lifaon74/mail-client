import { MimeType } from '../../../mime-type/mime-type.class';
import { EmailBody } from '../../components/body/email-body.class';
import {
  EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_BASE64_CONSTANT,
} from '../../components/header-list/components/header/built-in/content-transfer-encoding/built-in/email-header.content-transfer-encoding.base64.constant';
import {
  EmailHeaderContentType,
} from '../../components/header-list/components/header/built-in/content-type/email-header.content-type.type';
import { EmailHeader } from '../../components/header-list/components/header/email-header.class';
import { EmailHeaderList } from '../../components/header-list/email-header-list.class';
import { EmailData } from '../../email-data.class';

export class EmailDataAttachment extends EmailData {
  static fromFile(
    file: File,
  ): Promise<EmailDataAttachment> {
    return file.text()
      .then((content: string): EmailDataAttachment => {
        return new EmailDataAttachment(
          MimeType.fromString(file.type),
          file.name,
          content,
        );
      });
  }

  protected constructor(
    public readonly mimeType: MimeType,
    public readonly fileName: string,
    public readonly content: string,
  ) {
    if (!mimeType.parameters.hasParameterValue('name')) {
      mimeType.parameters.setParameterValue('name', fileName);
    }

    super(
      new EmailHeaderList([
        new EmailHeaderContentType(mimeType),
        new EmailHeader(
          'Content-Disposition',
          'attachment; filename="test.bin"',
        ),
        EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_BASE64_CONSTANT,
      ]),
      EmailBody.fromTextAsBase64(content),
    );
  }
}

