import { MimeTypeMultipart } from '../../../../../../../../../mime-type/built-in/multipart/mime-type.multipart.class';
import {
  IGenerateBoundaryOptions,
} from '../../../../../../../../../mime-type/components/mime-type-parameter-list/components/mime-type-parameter/built-in/boundary/generate-boundary';
import { EmailHeaderContentType } from '../../email-header.content-type.type';

export class EmailHeaderContentTypeMultipart extends EmailHeaderContentType {
  static generate(
    subtype: string,
    options?: IGenerateBoundaryOptions
  ): EmailHeaderContentTypeMultipart {
    return new EmailHeaderContentTypeMultipart(
      MimeTypeMultipart.generate(subtype, options),
    );
  }

  declare public readonly mimeType: MimeTypeMultipart;

  constructor(
    mimeType: MimeTypeMultipart,
  ) {
    super(mimeType);
  }
}

