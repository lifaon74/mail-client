import { EmailHeader } from '../../email-header.class';

export type IClassicContentTransferEncoding =
  | '7bit'
  | '8bit'
  | 'binary'
  | 'quoted-printable'
  | 'base64'
  ;

export type IContentTransferEncoding =
  | IClassicContentTransferEncoding
  | string
  ;

export class EmailHeaderContentTransferEncoding extends EmailHeader {
  constructor(
    public readonly contentTransferEncoding: IContentTransferEncoding,
  ) {
    super(
      'Content-Transfer-Encoding',
      contentTransferEncoding,
    );
  }
}
