import { EmailAddress } from './email-address.type';

export function emailAddressDebug(): void {
  // const emailAddress = emailAddressFromString('a@b.com');
  // const emailAddress = emailAddressFromString('"John.\\"Doe."@example.com');
  const emailAddress = EmailAddress.fromString('valentin.richard@example.com');

  console.log(emailAddress);
}
