import { emailAddressDebug } from './classes/email-address/email-address.debug';
import { emailDataDebug } from './classes/email-data/email-data.debug';
import { mimeTypeDebug } from './classes/mime-type/mime-type.debug';

function main(): void {
  // emailAddressDebug();
  // mimeTypeDebug();
  emailDataDebug();
}

main();
