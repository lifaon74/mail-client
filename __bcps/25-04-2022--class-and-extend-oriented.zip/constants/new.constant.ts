export const NEW = Symbol();
