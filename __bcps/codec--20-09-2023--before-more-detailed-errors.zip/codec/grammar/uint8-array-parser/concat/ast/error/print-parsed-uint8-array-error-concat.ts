import {
  IParsedUint8ArrayErrorConcatAstNode,
} from './parsed-uint8-array-error-concat-ast-node.type';

import { printGenericParsedUint8ArrayError } from '../../../__shared__/ast/error/print-generic-parsed-uint8-array-error';

export function printParsedUint8ArrayErrorConcat(
  buffer: Uint8Array,
  node: IParsedUint8ArrayErrorConcatAstNode,
): void {
  printGenericParsedUint8ArrayError(buffer, node.error);
}
