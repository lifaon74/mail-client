import {
  IParsedUint8ArrayErrorRepeatAstNode,
} from './parsed-uint8-array-error-repeat-ast-node.type';

import { printGenericParsedUint8ArrayError } from '../../../__shared__/ast/error/print-generic-parsed-uint8-array-error';

export function printParsedUint8ArrayErrorRepeat(
  buffer: Uint8Array,
  node: IParsedUint8ArrayErrorRepeatAstNode,
): void {
  console.groupCollapsed(`in repeat:`);
  printGenericParsedUint8ArrayError(buffer, node.error);
  console.groupEnd();
}
