import {
  IGrammarByteComparisonEqualsAstNode
} from '../../../grammar-byte-sequence-comparison/comparisons/equals/grammar-byte-comparison-equals-ast-node.type';

export function optimizeGrammarByteComparisonEquals(
  node: IGrammarByteComparisonEqualsAstNode,
): IGrammarByteComparisonEqualsAstNode {
  return node;
}
