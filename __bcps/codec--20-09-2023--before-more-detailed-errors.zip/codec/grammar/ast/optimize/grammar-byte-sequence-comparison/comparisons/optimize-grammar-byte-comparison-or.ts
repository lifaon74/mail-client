import {
  IGrammarByteComparisonOrAstNode
} from '../../../grammar-byte-sequence-comparison/comparisons/or/grammar-byte-comparison-or-ast-node.type';
import {
  IGrammarByteComparisonExpressionAstNode
} from '../../../grammar-byte-sequence-comparison/comparisons/grammar-byte-comparison-expression-ast-node.type';

export function optimizeGrammarByteComparisonOr(
  node: IGrammarByteComparisonOrAstNode,
): IGrammarByteComparisonExpressionAstNode {
  // TODO
  return node;
}
