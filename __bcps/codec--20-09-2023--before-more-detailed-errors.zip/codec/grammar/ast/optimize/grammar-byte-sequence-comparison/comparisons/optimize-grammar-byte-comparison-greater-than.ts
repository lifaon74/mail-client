import {
  IGrammarByteComparisonGreaterThanAstNode
} from '../../../grammar-byte-sequence-comparison/comparisons/greater-than/grammar-byte-comparison-greater-than-ast-node.type';

export function optimizeGrammarByteComparisonGreaterThan(
  node: IGrammarByteComparisonGreaterThanAstNode,
): IGrammarByteComparisonGreaterThanAstNode {
  return node;
}
