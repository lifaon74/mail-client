import {
  IGrammarByteComparisonLowerThanAstNode
} from '../../../grammar-byte-sequence-comparison/comparisons/lower-than/grammar-byte-comparison-lower-than-ast-node.type';

export function optimizeGrammarByteComparisonLowerThan(
  node: IGrammarByteComparisonLowerThanAstNode,
): IGrammarByteComparisonLowerThanAstNode {
  return node;
}
