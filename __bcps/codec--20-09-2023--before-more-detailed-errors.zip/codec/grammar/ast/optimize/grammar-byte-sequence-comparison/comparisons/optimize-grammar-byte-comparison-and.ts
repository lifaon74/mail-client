import {
  IGrammarByteComparisonAndAstNode
} from '../../../grammar-byte-sequence-comparison/comparisons/and/grammar-byte-comparison-and-ast-node.type';
import {
  IGrammarByteComparisonExpressionAstNode
} from '../../../grammar-byte-sequence-comparison/comparisons/grammar-byte-comparison-expression-ast-node.type';

export function optimizeGrammarByteComparisonAnd(
  node: IGrammarByteComparisonAndAstNode,
): IGrammarByteComparisonExpressionAstNode {
  // TODO
  return node;
}
