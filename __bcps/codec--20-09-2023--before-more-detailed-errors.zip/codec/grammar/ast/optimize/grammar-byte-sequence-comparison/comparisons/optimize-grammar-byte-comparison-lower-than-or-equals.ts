import {
  IGrammarByteComparisonLowerThanOrEqualsAstNode
} from '../../../grammar-byte-sequence-comparison/comparisons/lower-than-or-equals/grammar-byte-comparison-lower-than-or-equals-ast-node.type';

export function optimizeGrammarByteComparisonLowerThanOrEquals(
  node: IGrammarByteComparisonLowerThanOrEqualsAstNode,
): IGrammarByteComparisonLowerThanOrEqualsAstNode {
  return node;
}
