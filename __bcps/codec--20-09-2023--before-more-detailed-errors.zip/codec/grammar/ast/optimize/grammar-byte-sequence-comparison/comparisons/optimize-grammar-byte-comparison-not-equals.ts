import {
  IGrammarByteComparisonNotEqualsAstNode,
} from '../../../grammar-byte-sequence-comparison/comparisons/not-equals/grammar-byte-comparison-not-equals-ast-node.type';

export function optimizeGrammarByteComparisonNotEquals(
  node: IGrammarByteComparisonNotEqualsAstNode,
): IGrammarByteComparisonNotEqualsAstNode {
  return node;
}
