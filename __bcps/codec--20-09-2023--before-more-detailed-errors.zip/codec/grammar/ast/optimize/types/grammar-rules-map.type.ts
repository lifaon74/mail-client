import { IGrammarRuleAstNode } from '../../grammar-rule/grammar-rule-ast-node.type';

export type IGrammarRulesMap = Map<string, IGrammarRuleAstNode>;
