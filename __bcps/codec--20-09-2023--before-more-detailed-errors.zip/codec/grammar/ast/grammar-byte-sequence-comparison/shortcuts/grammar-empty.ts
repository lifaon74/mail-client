import { GrammarByteSequenceComparison } from '../grammar-byte-sequence-comparison';

export const GrammarEmpty = GrammarByteSequenceComparison();
