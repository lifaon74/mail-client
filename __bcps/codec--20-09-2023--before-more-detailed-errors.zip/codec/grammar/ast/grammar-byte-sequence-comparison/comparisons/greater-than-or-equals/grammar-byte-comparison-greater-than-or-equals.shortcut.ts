import { GrammarByteComparisonGreaterThanOrEquals } from './grammar-byte-comparison-greater-than-or-equals';

export const gte = GrammarByteComparisonGreaterThanOrEquals;

