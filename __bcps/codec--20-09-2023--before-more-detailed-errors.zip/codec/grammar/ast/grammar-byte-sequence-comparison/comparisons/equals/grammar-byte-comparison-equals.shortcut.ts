import { GrammarByteComparisonEquals } from './grammar-byte-comparison-equals';

export const eq = GrammarByteComparisonEquals;

