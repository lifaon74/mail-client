import { GrammarByteComparisonNotEquals } from './grammar-byte-comparison-not-equals';

export const neq = GrammarByteComparisonNotEquals;

