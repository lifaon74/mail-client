import { GrammarByteComparisonGreaterThan } from './grammar-byte-comparison-greater-than';

export const gt = GrammarByteComparisonGreaterThan;

