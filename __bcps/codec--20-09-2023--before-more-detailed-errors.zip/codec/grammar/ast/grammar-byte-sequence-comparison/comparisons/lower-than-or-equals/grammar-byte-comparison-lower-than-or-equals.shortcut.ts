import { GrammarByteComparisonLowerThanOrEquals } from './grammar-byte-comparison-lower-than-or-equals';

export const lte = GrammarByteComparisonLowerThanOrEquals;

