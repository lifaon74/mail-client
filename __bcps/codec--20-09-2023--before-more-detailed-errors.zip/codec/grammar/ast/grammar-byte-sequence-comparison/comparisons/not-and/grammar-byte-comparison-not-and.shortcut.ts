import { GrammarByteComparisonNotAnd } from './grammar-byte-comparison-not-and';

export const nand = GrammarByteComparisonNotAnd;

