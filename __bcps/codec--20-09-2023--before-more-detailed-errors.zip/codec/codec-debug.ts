import { GrammarRule } from './grammar/ast/grammar-rule/grammar-rule';
import { GrammarConcat } from './grammar/ast/grammar-concat/grammar-concat';
import {
  CHAR_0,
  CHAR_A_LOWER_CASE,
  CHAR_B_LOWER_CASE,
  CHAR_1,
  CHAR_2,
  CHAR_9,
  CHAR_Z_LOWER_CASE,
  CHAR_Z_UPPER_CASE,
  CHAR_A_UPPER_CASE,
  CHAR_F_LOWER_CASE,
  CHAR_F_UPPER_CASE,
  CHAR_DOUBLE_QUOTE,
  CHAR_EQUALS,
  CHAR_BACKSLASH,
  CHAR_SLASH,
  CHAR_SEMI_COLON,
  CHAR_SP,
  CHAR_LEFT_PARENTHESIS,
  CHAR_RIGHT_PARENTHESIS,
  CHAR_LEFT_ANGLE_BRACKET,
  CHAR_RIGHT_ANGLE_BRACKET,
  CHAR_AT_SIGN,
  CHAR_COMMA,
  CHAR_LEFT_SQUARE_BRACKET,
  CHAR_RIGHT_SQUARE_BRACKET,
  CHAR_QUESTION_MARK,
  CHAR_COLON,
  CHAR_HT,
  CHAR_CR,
  CHAR_LF,
} from '../../constants/chars/chars.constant';
import { IGrammarAstNode } from './grammar/ast/grammar/grammar-ast-node.type';
import { Grammar } from './grammar/ast/grammar/grammar';
import { ILines } from '../../misc/lines/lines.type';
import { linesToString } from '../../misc/lines/functions/lines-to-string';
import { GrammarAlternative } from './grammar/ast/grammar-alternative/grammar-alternative';
import { indentLines } from '../../misc/lines/functions/indent-lines';
import { GrammarRuleIdentifier } from './grammar/ast/grammar-rule-identifier/grammar-rule-identifier';
import { optimizeGrammar } from './grammar/ast/optimize/optimize-grammar';
import { GrammarByteRange } from './grammar/ast/grammar-byte-sequence-comparison/shortcuts/grammar-byte-range';
import { GrammarByteComparison } from './grammar/ast/grammar-byte-sequence-comparison/shortcuts/grammar-byte-comparison';
import { range } from './grammar/ast/grammar-byte-sequence-comparison/comparisons/range/grammar-byte-comparison-range.shortcut';
import { or } from './grammar/ast/grammar-byte-sequence-comparison/comparisons/or/grammar-byte-comparison-or.shortcut';
import { GrammarByte } from './grammar/ast/grammar-byte-sequence-comparison/shortcuts/grammar-byte';
import { eq } from './grammar/ast/grammar-byte-sequence-comparison/comparisons/equals/grammar-byte-comparison-equals.shortcut';
import { nor } from './grammar/ast/grammar-byte-sequence-comparison/comparisons/not-or/grammar-byte-comparison-not-or.shortcut';
import { GrammarByteSequence } from './grammar/ast/grammar-byte-sequence-comparison/shortcuts/grammar-byte-sequence';
import { GrammarRepeatOneOrMore } from './grammar/ast/grammar-repeat/shortcuts/grammar-repeat-one-or-more';
import { GrammarRepeatZeroOrMore } from './grammar/ast/grammar-repeat/shortcuts/grammar-repeat-zero-or-more';
import { GrammarString } from './grammar/ast/grammar-byte-sequence-comparison/shortcuts/grammar-string';
import { GrammarOptional } from './grammar/ast/grammar-repeat/shortcuts/grammar-optional';
import { alternativeUint8ArrayParser } from './grammar/uint8-array-parser/alternative/transpile/alternative-uint8-array-parser';
import { concatUint8ArrayParser } from './grammar/uint8-array-parser/concat/transpile/concat-uint8-array-parser';
import { repeatUint8ArrayParser } from './grammar/uint8-array-parser/repeat/transpile/repeat-uint8-array-parser';
import { ruleUint8ArrayParser } from './grammar/uint8-array-parser/rule/transpile/rule-uint8-array-parser';
import { transpileGrammarToUint8ArrayParser } from './grammar/uint8-array-parser/grammar/transpile/transpile-grammar-to-uint8-array-parser';
import { IUint8ArrayParserRules } from './grammar/uint8-array-parser/types/uint8-array-parser-rules.type';
import { IGrammarForUint8ArrayParser } from './grammar/uint8-array-parser/types/grammar-for-uint8-array-parser.type';
import {
  byteSequenceComparisonUint8ArrayParser,
} from './grammar/uint8-array-parser/byte-sequence-comparison/transpile/byte-sequence-comparison-uint8-array-parser';
import { printGenericParsedUint8ArrayError } from './grammar/uint8-array-parser/__shared__/ast/error/print-generic-parsed-uint8-array-error';
import {
  isGenericParsedUint8ArrayErrorAstNode
} from './grammar/uint8-array-parser/__shared__/ast/error/parsed-uint8-array-error-ast-node.type';
import { GrammarEmpty } from './grammar/ast/grammar-byte-sequence-comparison/shortcuts/grammar-empty';
import { optimizeGrammarExpression } from './grammar/ast/optimize/optimize-grammar-expression';
import { optimizeGrammarRule } from './grammar/ast/optimize/optimize-grammar-rule';
import { stringToLines } from '../../misc/lines/functions/string-to-lines';
import { printErroredUint8ArrayBuffer } from './grammar/uint8-array-parser/__shared__/ast/error/print-errored-uint8-array-buffer';
import { GrammarEnd } from './grammar/ast/grammar-end/grammar-end';
import { endUint8ArrayParser } from './grammar/uint8-array-parser/end/transpile/end-uint8-array-parser';

/*---------*/
export type byte_t = number;

export type IDecoderResult<GValue> = IteratorResult<void, GValue>;

export type IDecoder<GValue> = Iterator<void, GValue, byte_t>;

export interface IDecoderFactory<GValue> {
  (): IDecoder<GValue>;
}

export type IDecoderGenerator<GValue> = Generator<void, GValue, byte_t>;

export interface IDecoderIterable<GValue> {
  [Symbol.iterator]: IDecoderFactory<GValue>;
}

export type IEncoder = Iterator<byte_t, void, void>;

/*---------*/

// export function textEncoder(
//   input: string,
// ): IEncoder {
//   new TextEncoder().encode(input);
// }

/*---------*/

/*
tutorial: https://tomassetti.me/guide-parsing-algorithms-terminology/

https://en.wikipedia.org/wiki/Backus%E2%80%93Naur_form
https://en.wikipedia.org/wiki/Extended_Backus%E2%80%93Naur_form

https://github.com/dhconnelly/prettybnf
from bnf to abnf: https://softwareengineering.stackexchange.com/questions/356419/is-repetition-expressed-in-backus-naur-form-by-recursive-production-definitions

 */



export function compileAndOptimizeGrammarToUint8ArrayParser(
  grammar: IGrammarAstNode,
): IGrammarForUint8ArrayParser {
  return compileGrammarToUint8ArrayParser(
    optimizeGrammar(grammar),
  );
}

export function compileGrammarToUint8ArrayParser(
  grammar: IGrammarAstNode,
): IGrammarForUint8ArrayParser {
  const code: string = linesToString(
    transpileGrammarToUint8ArrayParser(
      grammar,
    ),
  );

  // console.log(code);

  const VARIABLES = {
    alternativeUint8ArrayParser,
    byteSequenceComparisonUint8ArrayParser,
    concatUint8ArrayParser,
    endUint8ArrayParser,
    repeatUint8ArrayParser,
    ruleUint8ArrayParser,
  };

  const fnc = new Function('VARIABLES', 'rules', linesToString([
    `const {`,
    ...indentLines([
      ...Object.keys(VARIABLES).flatMap((variable: string): ILines => {
        return [
          `${variable},`
        ]
      }),
    ]),
    `} = VARIABLES;`,
    `return (${code})(rules);`
  ])) as any;

  return (
    rules?: IUint8ArrayParserRules,
  ): IUint8ArrayParserRules => {
    return fnc(VARIABLES, rules);
  };
}

/*---------*/

/*---------*/

function grammarDebug1(): void {
  const digit = GrammarRule('digit', GrammarByteRange(CHAR_0, CHAR_9));
  const alpha_lowercase = GrammarRule('alpha_lowercase', GrammarAlternative(
    GrammarByte(CHAR_A_LOWER_CASE),
    GrammarByte(CHAR_B_LOWER_CASE),
    GrammarRuleIdentifier('digit'),
  ));

  const grammar = Grammar([
    digit,
    alpha_lowercase,
  ]);
  // console.log(grammar);

  const optimizedGrammar = optimizeGrammar(grammar);

  console.log(optimizedGrammar);

  // console.log(optimizeGrammarConcat(GrammarConcat([GrammarByte(CHAR_0), GrammarByte(CHAR_1), GrammarByte(CHAR_2)])));
  // console.log(optimizeGrammarAlternative(GrammarAlternative([GrammarByte(CHAR_0), GrammarByte(CHAR_1), GrammarByte(CHAR_2)])));
  // console.log(optimizeGrammarRule(alpha_lowercase));
  // console.log(optimizeGrammar(grammar));

  // // const lines: ILines = transpileGrammarByteToUint8ArrayParser(GrammarByte(CHAR_0));
  // // const lines: ILines = transpileGrammarConcatToUint8ArrayParser(GrammarConcat([GrammarByte(CHAR_0), GrammarByte(CHAR_1)]));
  // // const lines: ILines = transpileGrammarAlternativeToUint8ArrayParser(GrammarAlternative([GrammarByte(CHAR_0), GrammarByte(CHAR_1)]));
  // const lines: ILines = transpileGrammarRuleToUint8ArrayParser(digit);
  // // const lines: ILines = transpileGrammarRuleToUint8ArrayParser(alpha_lowercase);
  // // const lines: ILines = transpileGrammarToUint8ArrayParser(grammar);
  //
  // const code: string = linesToString(lines);
  //
  // console.log(code);
  //
  // const fnc = new Function('buffer', 'index', `return (${code})(buffer, index);`);
  //
  // console.log(fnc([CHAR_0, CHAR_1], 0));
  // // console.log(fnc([CHAR_A_LOWER_CASE, CHAR_1], 0));
}

// email rfc: https://datatracker.ietf.org/doc/html/rfc2045
// email rfc: https://datatracker.ietf.org/doc/html/rfc2046
// MIME type rfc: https://datatracker.ietf.org/doc/html/rfc2425#section-15

function grammarDebug2(): void {
  const digit = GrammarRule('digit', GrammarByteRange(CHAR_0, CHAR_9));
  const hex_digit = GrammarRule(
    'hex_digit',
    GrammarAlternative(
      GrammarRuleIdentifier('digit'),
      // GrammarByteComparison(
      //   or(
      //     range(CHAR_A_LOWER_CASE, CHAR_F_LOWER_CASE),
      //     range(CHAR_A_UPPER_CASE, CHAR_F_UPPER_CASE),
      //   )
      // ),
      GrammarByteRange(CHAR_A_LOWER_CASE, CHAR_F_LOWER_CASE),
      GrammarByteRange(CHAR_A_UPPER_CASE, CHAR_F_UPPER_CASE),
    ),
  );

  const alpha_lower_case = GrammarRule('alpha_lower_case', GrammarByteRange(CHAR_A_LOWER_CASE, CHAR_Z_LOWER_CASE));
  const alpha_upper_case = GrammarRule('alpha_upper_case', GrammarByteRange(CHAR_A_UPPER_CASE, CHAR_Z_UPPER_CASE));
  const alpha = GrammarRule('alpha',
    GrammarAlternative(
      GrammarRuleIdentifier('alpha_lower_case'),
      GrammarRuleIdentifier('alpha_upper_case'),
    ),
  );

  const grammar = Grammar([
    digit,
    hex_digit,
    alpha_lower_case,
    alpha_upper_case,
    alpha,
  ]);

  const compiledGrammar = compileAndOptimizeGrammarToUint8ArrayParser(grammar);
  const rules = compiledGrammar();

  const buffer = new Uint8Array([CHAR_0, CHAR_1, CHAR_2]);

  const tree = rules.get('alpha')!(buffer, 0);

  console.log(tree);

  printGenericParsedUint8ArrayError(buffer, tree as any);
}

function grammarDebug3(): void {
  // mime-type: https://datatracker.ietf.org/doc/html/rfc2045#section-5.1
  // list of iana mime-types: https://www.iana.org/assignments/media-types/media-types.xhtml#multipart

  /*
  // http://bibnum.bnf.fr/WARC/WARC_ISO_28500_version1_latestdraft.pdf

  named-field = field-name ":" [ field-value ]
 field-name = token
 field-value = *( field-content | LWS ) ; further qualified
 ; by field
 ; definitions
 field-content = <the OCTETs making up the field-value
 and consisting of either *TEXT or combinations
 of token, separators, and quoted-string>
 OCTET = <any 8-bit sequence of data>
 token = 1*<any US-ASCII character
 except CTLs or separators>
 separators = "(" | ")" | "<" | ">" | "@"
 | "," | ";" | ":" | "\" | <">
 | "/" | "[" | "]" | "?" | "="
 | "{" | "}" | SP | HT
 TEXT = <any OCTET except CTLs,
 but including LWS>
 CHAR = <UTF-8 characters; RFC3629> ; (0-191, 194-244)
 DIGIT = <any US-ASCII digit "0".."9">
 CTL = <any US-ASCII control character
 (octets 0 - 31) and DEL (127)>
 CR = <ASCII CR, carriage return> ; (13)
ISO 28500
© ISO 2006 — All rights reserved 5
 LF = <ASCII LF, linefeed> ; (10)
 SP = <ASCII SP, space> ; (32)
 HT = <ASCII HT, horizontal-tab> ; (9)
 CRLF = CR LF
 LWS = [CRLF] 1*( SP | HT ) ; semantics same as
 ; single SP
 quoted-string = ( <"> *(qdtext | quoted-pair ) <"> )
 qdtext = <any TEXT except <">>
 quoted-pair = "\" CHAR ; single-character quoting
 uri = "<" <'URI' per RFC3986> ">"

   */

  const CTL = or(
    range(0x00, 0x1f),
    eq(0x7f),
  );

  const mime_type = GrammarRule('mime-type', GrammarConcat(
    GrammarRuleIdentifier('type'),
    GrammarByte(CHAR_SLASH),
    GrammarRuleIdentifier('subtype'),
    GrammarRepeatZeroOrMore(
      GrammarConcat(
        GrammarByte(CHAR_SEMI_COLON),
        GrammarRuleIdentifier('parameter'),
      ),
    ),
  ));

  const type = GrammarRule('type', GrammarRuleIdentifier('token'));

  const subtype = GrammarRule('subtype', GrammarRuleIdentifier('token'));

  const parameter = GrammarRule('parameter', GrammarConcat(
    GrammarRuleIdentifier('attribute'),
    GrammarByte(CHAR_EQUALS),
    GrammarRuleIdentifier('value'),
  ));

  const attribute = GrammarRule('attribute', GrammarRuleIdentifier('token'));

  const value = GrammarRule('value', GrammarAlternative(
    GrammarRuleIdentifier('token'),
    GrammarRuleIdentifier('quoted-string'),
  ));

  const tspecials = or(
    eq(CHAR_LEFT_PARENTHESIS),
    eq(CHAR_RIGHT_PARENTHESIS),
    eq(CHAR_LEFT_ANGLE_BRACKET),
    eq(CHAR_RIGHT_ANGLE_BRACKET),
    eq(CHAR_AT_SIGN),
    eq(CHAR_COMMA),
    eq(CHAR_SEMI_COLON),
    eq(CHAR_COLON),
    eq(CHAR_BACKSLASH),
    eq(CHAR_DOUBLE_QUOTE),
    eq(CHAR_SLASH),
    eq(CHAR_LEFT_SQUARE_BRACKET),
    eq(CHAR_RIGHT_SQUARE_BRACKET),
    eq(CHAR_QUESTION_MARK),
    eq(CHAR_EQUALS),
  );

  const token = GrammarRule('token', GrammarRepeatOneOrMore(
    GrammarByteComparison(
      nor(
        eq(CHAR_SP),
        CTL,
        tspecials,
      ),
    ),
  ));

  const quoted_string = GrammarRule('quoted-string', GrammarConcat(
    GrammarByte(CHAR_DOUBLE_QUOTE),
    GrammarRepeatZeroOrMore(
      GrammarAlternative(
        GrammarRuleIdentifier('quoted-string-token'),
        GrammarRuleIdentifier('quoted-pair'),
      ),
    ),
    GrammarByte(CHAR_DOUBLE_QUOTE),
  ));

  const quoted_pair = GrammarRule('quoted-pair', GrammarByteSequence([
    CHAR_BACKSLASH,
    CHAR_DOUBLE_QUOTE,
  ]));

  const quoted_string_token = GrammarRule('quoted-string-token', GrammarByteComparison(
    or(
      eq(0x09),
      range(0x20 /* SP */, 0x21 /* ! */),
      // exclude "
      range(0x23 /* # */, 0x7e /* ~ */),
    ),
  ));

  const grammar = Grammar([
    mime_type,
    type,
    subtype,
    parameter,
    attribute,
    value,
    token,
    quoted_string,
    quoted_pair,
    quoted_string_token,
  ]);

  const optimizedGrammar = optimizeGrammar(grammar);

  console.log(optimizedGrammar);
  console.log(optimizedGrammar === grammar);

  const compiledGrammar = compileAndOptimizeGrammarToUint8ArrayParser(grammar);
  const rules = compiledGrammar();

  // const buffer = new Uint8Array([CHAR_0, CHAR_1, CHAR_2]);
  const buffer = new TextEncoder().encode('image/png; asefesf="i7888888888888888\\"888888888888888888888888888888888"');
  console.log(buffer);

  const tree = rules.get('mime-type')!(buffer, 0);

  console.log(tree);

  printGenericParsedUint8ArrayError(buffer, tree as any);

  // console.log(optimizeGrammarExpression(
  //   GrammarAlternative([
  //     GrammarByte(CHAR_BACKSLASH),
  //     GrammarByte(CHAR_DOUBLE_QUOTE),
  //   ]),
  //   // GrammarConcat([
  //   //   GrammarByte(CHAR_BACKSLASH),
  //   //   GrammarByte(CHAR_DOUBLE_QUOTE),
  //   // ]),
  // ));
}

// export const ABNF_ALPHA_LOWER_CASE = range(CHAR_A_LOWER_CASE, CHAR_Z_LOWER_CASE);
// export const ABNF_ALPHA_UPPER_CASE = range(CHAR_A_UPPER_CASE, CHAR_Z_UPPER_CASE);
// export const ABNF_ALPHA = or(
//   ABNF_ALPHA_LOWER_CASE,
//   ABNF_ALPHA_UPPER_CASE,
// );
//
// export const ABNF_DIGIT = range(CHAR_0, CHAR_9);
// export const ABNF_HEXDIG = or(
//   ABNF_DIGIT,
//   range(CHAR_A_LOWER_CASE, CHAR_F_LOWER_CASE),
//   range(CHAR_A_UPPER_CASE, CHAR_F_UPPER_CASE),
// );
//
// const ABNF_DQUOTE = eq(CHAR_DOUBLE_QUOTE);
// const ABNF_SP = eq(CHAR_SP);
// const ABNF_HTAB = eq(CHAR_HT);
// const ABNF_WSP = or(
//   ABNF_SP,
//   ABNF_HTAB,
// );
// export const ABNF_LWSP_RULE = GrammarRule('LWSP', GrammarRepeatZeroOrMore(
//   GrammarAlternative(
//     GrammarByteSequenceComparison(ABNF_WSP),
//     GrammarConcat(
//       GrammarRuleIdentifier('CRLF'),
//       GrammarByteSequenceComparison(ABNF_WSP),
//     ),
//   ),
// ));
// export const ABNF_VCHAR = range(0x21, 0x7e);
// export const ABNF_CHAR = range(0x01, 0x7f);
// export const ABNF_OCTET = range(0x00, 0xff);
// export const ABNF_CTL = or(
//   range(0x00, 0x1f),
//   eq(0x7f),
// );
// export const ABNF_CR = eq(CHAR_CR);
// export const ABNF_LF = eq(CHAR_LF);
// export const ABNF_CRLF_RULE = GrammarRule('CRLF', GrammarByteSequenceComparison(
//   ABNF_CR,
//   ABNF_LF,
// ));
// const ABNF_BIT = or(
//   eq(CHAR_0),
//   eq(CHAR_1),
// );

function grammarDebugABNF(): void {
  // https://www.rfc-editor.org/rfc/rfc5234

  const ALPHA_LOWER_CASE = GrammarRule('ALPHA_LOWER_CASE', GrammarByteRange(CHAR_A_LOWER_CASE, CHAR_Z_LOWER_CASE));
  const ALPHA_UPPER_CASE = GrammarRule('ALPHA_UPPER_CASE', GrammarByteRange(CHAR_A_UPPER_CASE, CHAR_Z_UPPER_CASE));
  const ALPHA = GrammarRule('ALPHA', GrammarAlternative(
    GrammarRuleIdentifier('ALPHA_LOWER_CASE'),
    GrammarRuleIdentifier('ALPHA_UPPER_CASE'),
  ));
  const DIGIT = GrammarRule('DIGIT', GrammarByteRange(CHAR_0, CHAR_1));
  const HEXDIG = GrammarRule('HEXDIG', GrammarAlternative(
    GrammarRuleIdentifier('DIGIT'),
    GrammarByteRange(CHAR_A_LOWER_CASE, CHAR_F_LOWER_CASE),
    GrammarByteRange(CHAR_F_UPPER_CASE, CHAR_F_UPPER_CASE),
  ));
  const DQUOTE = GrammarRule('DQUOTE', GrammarByte(CHAR_DOUBLE_QUOTE));
  const SP = GrammarRule('SP', GrammarByte(CHAR_SP));
  const HTAB = GrammarRule('HTAB', GrammarByte(CHAR_HT));
  const WSP = GrammarRule('WSP', GrammarAlternative(
    GrammarRuleIdentifier('SP'),
    GrammarRuleIdentifier('HTAB'),
  ));
  const LWSP = GrammarRule('LWSP', GrammarRepeatZeroOrMore(
    GrammarAlternative(
      GrammarRuleIdentifier('WSP'),
      GrammarConcat(
        GrammarRuleIdentifier('CRLF'),
        GrammarRuleIdentifier('WSP'),
      ),
    ),
  ));
  const VCHAR = GrammarRule('VCHAR', GrammarByteRange(0x21, 0x7e));
  const CHAR = GrammarRule('CHAR', GrammarByteRange(0x01, 0x7f));
  const OCTET = GrammarRule('OCTET', GrammarByteRange(0x00, 0xff));
  const CTL = GrammarRule('CTL', GrammarByteComparison(
    or(
      range(0x00, 0x1f),
      eq(0x7f),
    ),
  ));
  const CR = GrammarRule('CR', GrammarByte(CHAR_CR));
  const LF = GrammarRule('LF', GrammarByte(CHAR_LF));
  const CRLF = GrammarRule('CRLF', GrammarConcat(
    GrammarRuleIdentifier('CR'),
    GrammarRuleIdentifier('LF'),
  ));
  const BIT = GrammarRule('BIT', GrammarByteComparison(
    or(
      eq(CHAR_0),
      eq(CHAR_1),
    ),
  ));

  const CRLF_OR_END = GrammarRule('CRLF_OR_END', GrammarAlternative(
    GrammarRuleIdentifier('CRLF'),
    GrammarEnd,
  ));

  const ABNF_RULES = [
    ALPHA_LOWER_CASE,
    ALPHA_UPPER_CASE,
    ALPHA,
    DIGIT,
    HEXDIG,
    DQUOTE,
    SP,
    HTAB,
    WSP,
    LWSP,
    VCHAR,
    CHAR,
    OCTET,
    CTL,
    CR,
    LF,
    CRLF,
    BIT,
    CRLF_OR_END,
  ];

  const main = GrammarRule('main', GrammarConcat(
    GrammarRuleIdentifier('rulelist'),
    GrammarEnd,
  ));

  const rulelist = GrammarRule('rulelist', GrammarRepeatOneOrMore(
    GrammarAlternative(
      GrammarRuleIdentifier('rule'),
      GrammarConcat(
        GrammarRepeatZeroOrMore(
          GrammarRuleIdentifier('c-wsp'),
        ),
        GrammarRuleIdentifier('c-nl'),
      ),
    ),
  ));

  const rule = GrammarRule('rule', GrammarConcat(
    GrammarRuleIdentifier('rulename'),
    GrammarRuleIdentifier('defined-as'),
    GrammarRuleIdentifier('elements'),
    GrammarRuleIdentifier('c-nl'),
  ));

  const rulename = GrammarRule('rulename', GrammarConcat(
    GrammarRuleIdentifier('ALPHA'),
    GrammarRepeatZeroOrMore(
      GrammarAlternative(
        GrammarRuleIdentifier('ALPHA'),
        GrammarRuleIdentifier('DIGIT'),
        GrammarString('-'),
      ),
    ),
  ));

  const defined_as = GrammarRule('defined-as', GrammarConcat(
    GrammarRepeatZeroOrMore(
      GrammarRuleIdentifier('c-wsp'),
    ),
    GrammarAlternative(
      GrammarString('='),
      GrammarString('=/'),
    ),
    GrammarRepeatZeroOrMore(
      GrammarRuleIdentifier('c-wsp'),
    ),
  ));

  const elements = GrammarRule('elements', GrammarConcat(
    GrammarRuleIdentifier('alternation'),
    GrammarRepeatZeroOrMore(
      GrammarRuleIdentifier('c-wsp'),
    ),
  ));

  const c_wsp = GrammarRule('c-wsp', GrammarAlternative(
    GrammarRuleIdentifier('WSP'),
    GrammarConcat(
      GrammarRuleIdentifier('c-nl'),
      GrammarRuleIdentifier('WSP'),
    ),
  ));

  const c_nl = GrammarRule('c-nl', GrammarAlternative(
    GrammarRuleIdentifier('comment'),
    GrammarRuleIdentifier('CRLF_OR_END'),
  ));

  const comment = GrammarRule('comment', GrammarConcat(
    GrammarString(';'),
    GrammarRepeatZeroOrMore(
      GrammarAlternative(
        GrammarRuleIdentifier('WSP'),
        GrammarRuleIdentifier('VCHAR'),
      ),
    ),
    GrammarRuleIdentifier('CRLF_OR_END'),
  ));

  const alternation = GrammarRule('alternation', GrammarConcat(
    GrammarRuleIdentifier('concatenation'),
    GrammarRepeatZeroOrMore(
      GrammarConcat(
        GrammarRepeatZeroOrMore(
          GrammarRuleIdentifier('c-wsp'),
        ),
        GrammarString('/'),
        GrammarRepeatZeroOrMore(
          GrammarRuleIdentifier('c-wsp'),
        ),
        GrammarRuleIdentifier('concatenation'),
      ),
    ),
  ));

  const concatenation = GrammarRule('concatenation', GrammarConcat(
    GrammarRuleIdentifier('repetition'),
    GrammarRepeatZeroOrMore(
      GrammarConcat(
        GrammarRepeatOneOrMore(
          GrammarRuleIdentifier('c-wsp'),
        ),
        GrammarRuleIdentifier('repetition'),
      ),
    ),
  ));

  const repetition = GrammarRule('repetition', GrammarConcat(
    GrammarOptional(
      GrammarRuleIdentifier('repeat'),
    ),
    GrammarRuleIdentifier('element'),
  ));

  const repeat = GrammarRule('repeat', GrammarAlternative(
    GrammarRepeatOneOrMore(
      GrammarRuleIdentifier('DIGIT'),
    ),
    GrammarConcat(
      GrammarRepeatZeroOrMore(
        GrammarRuleIdentifier('DIGIT'),
      ),
      GrammarString('*'),
      GrammarRepeatZeroOrMore(
        GrammarRuleIdentifier('DIGIT'),
      ),
    ),
  ));

  const element = GrammarRule('element', GrammarAlternative(
    GrammarRuleIdentifier('rulename'),
    GrammarRuleIdentifier('group'),
    GrammarRuleIdentifier('option'),
    GrammarRuleIdentifier('char-val'),
    GrammarRuleIdentifier('num-val'),
    GrammarRuleIdentifier('prose-val'),
  ));

  const group = GrammarRule('group', GrammarConcat(
    GrammarString('('),
    GrammarRepeatZeroOrMore(
      GrammarRuleIdentifier('c-wsp'),
    ),
    GrammarRuleIdentifier('alternation'),
    GrammarRepeatZeroOrMore(
      GrammarRuleIdentifier('c-wsp'),
    ),
    GrammarString(')'),
  ));

  const option = GrammarRule('option', GrammarConcat(
    GrammarString('['),
    GrammarRepeatZeroOrMore(
      GrammarRuleIdentifier('c-wsp'),
    ),
    GrammarRuleIdentifier('alternation'),
    GrammarRepeatZeroOrMore(
      GrammarRuleIdentifier('c-wsp'),
    ),
    GrammarString(']'),
  ));

  const char_val = GrammarRule('char-val', GrammarConcat(
    GrammarRuleIdentifier('DQUOTE'),
    GrammarRepeatZeroOrMore(
      GrammarAlternative(
        GrammarByteRange(0x20, 0x21),
        GrammarByteRange(0x23, 0xee7),
      ),
    ),
    GrammarRuleIdentifier('DQUOTE'),
  ));

  const num_val = GrammarRule('num-val', GrammarConcat(
    GrammarString('%'),
    GrammarAlternative(
      GrammarRuleIdentifier('bin-val'),
      GrammarRuleIdentifier('dec-val'),
      GrammarRuleIdentifier('hex-val'),
    ),
  ));

  const bin_val = GrammarRule('bin-val', GrammarConcat(
    GrammarString('b'),
    GrammarRepeatOneOrMore(
      GrammarRuleIdentifier('BIT'),
    ),
    GrammarOptional(
      GrammarAlternative(
        GrammarRepeatOneOrMore(
          GrammarConcat(
            GrammarString('.'),
            GrammarRepeatOneOrMore(
              GrammarRuleIdentifier('BIT'),
            ),
          )
        ),
        GrammarConcat(
          GrammarString('-'),
          GrammarRepeatOneOrMore(
            GrammarRuleIdentifier('BIT'),
          ),
        )
      )
    ),
  ));

  const dec_val = GrammarRule('dec-val', GrammarConcat(
    GrammarString('d'),
    GrammarRepeatOneOrMore(
      GrammarRuleIdentifier('DIGIT'),
    ),
    GrammarOptional(
      GrammarAlternative(
        GrammarRepeatOneOrMore(
          GrammarConcat(
            GrammarString('.'),
            GrammarRepeatOneOrMore(
              GrammarRuleIdentifier('DIGIT'),
            ),
          )
        ),
        GrammarConcat(
          GrammarString('-'),
          GrammarRepeatOneOrMore(
            GrammarRuleIdentifier('DIGIT'),
          ),
        )
      )
    ),
  ));

  const hex_val = GrammarRule('hex-val', GrammarConcat(
    GrammarString('x'),
    GrammarRepeatOneOrMore(
      GrammarRuleIdentifier('HEXDIG'),
    ),
    GrammarOptional(
      GrammarAlternative(
        GrammarRepeatOneOrMore(
          GrammarConcat(
            GrammarString('.'),
            GrammarRepeatOneOrMore(
              GrammarRuleIdentifier('HEXDIG'),
            ),
          )
        ),
        GrammarConcat(
          GrammarString('-'),
          GrammarRepeatOneOrMore(
            GrammarRuleIdentifier('HEXDIG'),
          ),
        )
      )
    ),
  ));

  const prose_val = GrammarRule('prose-val', GrammarConcat(
    GrammarString('<'),
    GrammarAlternative(
      GrammarByteRange(0x20, 0x3d),
      GrammarByteRange(0x3f, 0x7e),
    ),
    GrammarString('>'),
  ));

  const grammar = Grammar([
    ...ABNF_RULES,
    main,
    rulelist,
    rule,
    rulename,
    defined_as,
    elements,
    c_wsp,
    c_nl,
    comment,
    alternation,
    concatenation,
    repetition,
    repeat,
    element,
    group,
    option,
    char_val,
    num_val,
    bin_val,
    dec_val,
    hex_val,
    prose_val,
  ]);

  // console.log(optimizeGrammar(grammar));

  const compiledGrammar = compileGrammarToUint8ArrayParser(grammar);
  // const compiledGrammar = compileAndOptimizeGrammarToUint8ArrayParser(grammar);
  const rules = compiledGrammar();


  // const raw = `
  //   postal-address   = name-part street zip-part
  // `;

  const raw = `
    postal-address   = name-part street zip-part
    
    name-part        = *(personal-part SP) last-name [SP suffix] CRLF
    name-part        =/ personal-part CRLF
  `;

  // const raw = `
  //   postal-address   = name-part street zip-part
  //
  //   name-part        = *(personal-part SP) last-name [SP suffix] CRLF
  //   ; name-part        =/ personal-part CRLF
  //
  //   personal-part    = first-name / (initial ".")
  //   first-name       = *ALPHA
  //   initial          = ALPHA
  //   last-name        = *ALPHA
  //   ; suffix           = ("Jr." / "Sr." / 1*("I" / "V" / "X"))
  //
  //   street           = [apt SP] house-num SP street-name CRLF
  //   apt              = 1*4DIGIT
  //   house-num        = 1*8(DIGIT / ALPHA)
  //   street-name      = 1*VCHAR
  //
  //   zip-part         = town-name "," SP state 1*2SP zip-code CRLF
  //   town-name        = 1*(ALPHA / SP)
  //   state            = 2ALPHA
  //   zip-code         = 5DIGIT ["-" 4DIGIT]
  // `;

  const lines: ILines = stringToLines(raw);
  const str: string = lines.join('\r\n');
  console.log(str);
  const buffer = new TextEncoder().encode(str);

  console.log(buffer);

  const tree = rules.get('main')!(buffer, 0);
  // const tree = rules.get('rulelist')!(buffer, 0);

  console.log(tree);

  if (isGenericParsedUint8ArrayErrorAstNode(tree)) {
    printGenericParsedUint8ArrayError(buffer, tree);
  } else if (tree.end < buffer.length) {
    printErroredUint8ArrayBuffer(buffer, tree.end, tree.end);
  }
}

/*---------*/

export async function codecDebug(): Promise<void> {
  // grammarDebug1();
  // grammarDebug2();
  // grammarDebug3();
  grammarDebugABNF();
}
