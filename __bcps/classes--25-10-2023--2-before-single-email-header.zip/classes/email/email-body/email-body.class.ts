import { EmailHeaders } from '../email-headers/email-headers.class';

export abstract class EmailBody {
  abstract toString(
    headers: EmailHeaders,
  ): string;
}
