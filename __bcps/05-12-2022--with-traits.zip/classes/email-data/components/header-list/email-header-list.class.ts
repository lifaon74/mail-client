import { CRLF } from '../../../../constants/crlf';
import { EmailHeader } from './components/header/email-header.class';

export class EmailHeaderList {
  public readonly map: ReadonlyMap<string, string>;

  constructor(
    public readonly items: readonly EmailHeader[],
  ) {
    this.map = new Map<string, string>(
      this.items.map(({ key, value }): [string, string] => {
        return [key, value];
      }),
    );
  }

  get size(): number {
    return this.items.length;
  }

  toString(): string {
    return this.items.map((parameter: EmailHeader) => parameter.toString())
      .join(CRLF);
  }
}
