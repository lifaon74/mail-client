export class EmailHeader {
  constructor(
    public readonly key: string,
    public readonly value: string,
  ) {
  }

  toString(): string {
    return `${this.key}: ${this.value}`;
  }
}

