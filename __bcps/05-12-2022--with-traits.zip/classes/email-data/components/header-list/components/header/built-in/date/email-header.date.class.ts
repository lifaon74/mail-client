import { EmailHeader } from '../../email-header.class';

export class EmailHeaderDate extends EmailHeader {
  static now(): EmailHeaderDate {
    return new EmailHeaderDate(new Date());
  }

  constructor(
    public readonly date: Date,
  ) {
    super(
      'Date',
      date.toISOString(),
    );
  }
}

