import { MIME_TYPE_TEXT_HTML_UTF8_CONSTANT } from '../../../../../../../../mime-type/__built-in/mime-type.text-html.utf8.constant';
import { EmailHeaderContentType } from '../email-header.content-type.type';

export const EMAIL_HEADER_CONTENT_TYPE_TEXT_HTML_UTF8_CONSTANT: EmailHeaderContentType = new EmailHeaderContentType(MIME_TYPE_TEXT_HTML_UTF8_CONSTANT);
