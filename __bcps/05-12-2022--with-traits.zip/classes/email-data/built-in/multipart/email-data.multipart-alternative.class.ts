import {
  EmailHeaderContentTypeMultipartAlternative,
} from '../../components/header-list/components/header/built-in/content-type/built-in/multipart/email-header.content-type.multipart-alternative.class';
import { EmailDataTextHTML } from '../text-html/email-data.text-html.class';
import { EmailDataTextPlain } from '../text-plain/email-data.text-plain.class';
import { EmailDataMultipart, IEmailDataMultipartContent } from './email-data.multipart.class';

export class EmailDataMultipartAlternative extends EmailDataMultipart {

  static fromTextAndHTML(
    text: string,
    html: string,
  ): EmailDataMultipartAlternative {
    return new EmailDataMultipartAlternative([
      new EmailDataTextPlain(text),
      new EmailDataTextHTML(html),
    ]);
  }

  constructor(
    content: IEmailDataMultipartContent,
  ) {
    super(
      EmailHeaderContentTypeMultipartAlternative.generate(),
      content,
    );
  }
}

