import { CRLF } from '../../constants/crlf';
import { EmailBody } from './components/body/email-body.class';
import { EmailHeaderList } from './components/header-list/email-header-list.class';

export class EmailData {
  constructor(
    public readonly headers: EmailHeaderList,
    public readonly body: EmailBody,
  ) {
  }

  toString(): string {
    return this.headers.toString() + CRLF
      + CRLF
      + this.body.toString();
  }
}


