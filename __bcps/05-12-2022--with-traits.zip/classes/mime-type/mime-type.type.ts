import { IToStringTrait } from '@lifaon/traits';

export interface IMimeType extends //
  IToStringTrait
  //
{
}
