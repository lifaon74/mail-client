import { NEW } from '../../../../constants/new.constant';
import {
  MimeTypeParameterKey,
  newMimeTypeParameterKey,
} from './components/mime-type-parameter/components/mime-type-parameter-key/mime-type-parameter-key.class';
import {
  MimeTypeParameterValue,
  newMimeTypeParameterValue,
  unquoteMimeTypeParameterValueStringQuoted,
} from './components/mime-type-parameter/components/mime-type-parameter-value/mime-type-parameter-value.class';
import { MIME_TYPE_PARAMETER_PATTERN, MimeTypeParameter } from './components/mime-type-parameter/mime-type-parameter.class';

// const NAME_AND_VALUE_REGEXP: RegExp = new RegExp(`\\s*(${HTTP_TOKEN_PATTERN}+)(?:=(${HTTP_TOKEN_PATTERN}+|(?:"(?:${HTTP_TOKEN_PATTERN}|(?:\\\\")|(?:\\\\\\\\))+")))?\\s*(?:;|$)`, 'g');
const MIME_TYPE_PARAMETER_LIST_KEY_AND_VALUE_REGEXP: RegExp = new RegExp(`\\s*${MIME_TYPE_PARAMETER_PATTERN}\\s*(?:;|$)`, 'g');

export class MimeTypeParameterList {
  static fromString(
    input: string,
  ): MimeTypeParameterList {
    let match: RegExpExecArray | null;
    let index: number = 0;
    const items: MimeTypeParameter[] = [];

    while ((match = MIME_TYPE_PARAMETER_LIST_KEY_AND_VALUE_REGEXP.exec(input)) !== null) {
      if ((index === 0) && (match.index !== 0)) {
        throw new Error(`Invalid parameters`);
      }

      const [, keyString, valueString] = match;

      const key: MimeTypeParameterKey = newMimeTypeParameterKey(keyString);

      const value: MimeTypeParameterValue | null = (valueString === void 0)
        ? null
        : newMimeTypeParameterValue(
          valueString.startsWith('"')
            ? unquoteMimeTypeParameterValueStringQuoted(valueString)
            : valueString,
        );

      items.push(
        new MimeTypeParameter(
          key,
          value,
        ),
      );

      index = match.index + match[0].length;
    }

    if (index !== input.length) {
      throw new Error(`Invalid parameters`);
    }

    return this.fromItems(items);
  }

  static fromItems(
    items: Iterable<MimeTypeParameter>,
  ): MimeTypeParameterList {
    const instance = newMimeTypeParameterList();
    instance.addMany(items);
    return instance;
  }

  protected _map!: Map<string, MimeTypeParameter>;

  protected constructor() {
  }

  get size(): number {
    return this._map.size;
  }

  get map(): ReadonlyMap<string, MimeTypeParameter> {
    return this._map;
  }

  add(
    parameter: MimeTypeParameter,
  ): void {
    const key: string = parameter.key.toString();
    if (this._map.has(key)) {
      throw new Error(`Key already exists`);
    } else {
      this._map.set(key, parameter);
    }
  }

  addMany(
    items: Iterable<MimeTypeParameter>,
  ): void {
    const iterator: Iterator<MimeTypeParameter> = items[Symbol.iterator]();
    let result: IteratorResult<MimeTypeParameter>;
    while (!(result = iterator.next()).done) {
      this.add(result.value);
    }
  }

  remove(
    parameter: MimeTypeParameter,
  ): void {
    const key: string = parameter.key.toString();
    if (this._map.has(key)) {
      throw new Error(`Key does not exist`);
    } else {
      this._map.set(key, parameter);
    }
  }

  hasParameterValue(
    key: string,
  ): boolean {
    return this._map.has(key);
  }

  getParameterValue(
    key: string,
  ): string | undefined {
    if (this._map.has(key)) {
      const value: MimeTypeParameterValue | null = this._map.get(key)!.value;
      return (value === null)
        ? ''
        : value.get();
    } else {
      return void 0;
    }
  }

  setParameterValue(
    key: string,
    value: string,
  ): void {
    this.add(
      new MimeTypeParameter(
        MimeTypeParameterKey.fromString(key),
        MimeTypeParameterValue.fromString(value),
      ),
    );
  }

  toString(): string {
    let output: string = '';
    const iterator: Iterator<MimeTypeParameter> = this._map.values();
    let result: IteratorResult<MimeTypeParameter>;

    if (!(result = iterator.next()).done) {
      output += result.value.toString();
    }

    while (!(result = iterator.next()).done) {
      output += `; ${result.value.toString()}`;
    }

    return output;
  }
}

/*--------------*/

export function newMimeTypeParameterList(
  map: Map<string, MimeTypeParameter> = new Map<string, MimeTypeParameter>(),
): MimeTypeParameterList {
  type GMimeTypeParameterList = any;
  const instance: GMimeTypeParameterList = new (MimeTypeParameterList as any)();
  instance._map = map;
  return instance;
}
