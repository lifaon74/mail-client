import { MimeTypeParameter } from '../../mime-type-parameter.class';
import { generateBoundary, IGenerateBoundaryOptions } from './generate-boundary';

export class MimeTypeParameterBoundary extends MimeTypeParameter {
  static generate(
    options?: IGenerateBoundaryOptions,
  ): MimeTypeParameterBoundary {
    return new MimeTypeParameterBoundary(
      generateBoundary(options),
    );
  }

  protected constructor(
    public readonly boundary: string,
  ) {
    super(
      'boundary',
      `"${boundary}"`,
    );
  }
}

export function generateBoundaryMimeTypeParameter(

) {

}
