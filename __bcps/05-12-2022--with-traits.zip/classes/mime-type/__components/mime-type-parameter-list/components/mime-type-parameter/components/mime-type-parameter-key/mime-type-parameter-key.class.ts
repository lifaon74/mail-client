import { HTTP_TOKEN_PATTERN } from '../../../../../../../../constants/http-token-pattern.constant';

export const MIME_TYPE_PARAMETER_KEY_PATTERN = `${HTTP_TOKEN_PATTERN}+`;

const MIME_TYPE_PARAMETER_KEY_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_KEY_PATTERN}$`, 'g');

export class MimeTypeParameterKey {
  static fromString(
    input: string,
  ): MimeTypeParameterKey {
    const instance: MimeTypeParameterKey = new MimeTypeParameterKey();
    instance.set(input);
    return instance;
  }

  protected _value!: string;

  protected constructor() {
  }

  get(): string {
    return this._value;
  }

  set(value: string): void {
    if (MIME_TYPE_PARAMETER_KEY_REGEXP.test(value)) {
      this._value = value;
    } else {
      throw new Error(`Invalid key`);
    }
  }

  toString(): string {
    return this.get();
  }
}

/*--------------*/

export function newMimeTypeParameterKey(
  value: string,
): MimeTypeParameterKey {
  type GMimeTypeParameterKey = any;
  const instance: GMimeTypeParameterKey = new (MimeTypeParameterKey as any)();
  instance._value = value;
  return instance;
}


