import {
  MimeTypeParameterListWithBoundary,
} from '../../__components/mime-type-parameter-list/built-in/mime-type-parameter-list.with-boundary.class';
import {
  IGenerateBoundaryOptions,
} from '../../__components/mime-type-parameter-list/components/mime-type-parameter/built-in/boundary/generate-boundary';
import { MimeTypeParameterList } from '../../__components/mime-type-parameter-list/mime-type-parameter-list.class';
import { MimeType } from '../../mime-type.class';

export class MimeTypeMultipart extends MimeType {
  static generate(
    subtype: string,
    options?: IGenerateBoundaryOptions,
  ): MimeTypeMultipart {
    return newMimeTypeMultipart(
      subtype,
      MimeTypeParameterListWithBoundary.generate(options),
    );
  }

  declare protected _parameters: MimeTypeParameterListWithBoundary;

  override get type(): 'multipart' {
    return 'multipart';
  }

  override get parameters(): MimeTypeParameterListWithBoundary {
    return this._parameters;
  }
}

/*--------------*/

export function newMimeTypeMultipart(
  subtype: string,
  parameters: MimeTypeParameterList,
): MimeTypeMultipart {
  type GMimeTypeMultipart = any;
  const instance: GMimeTypeMultipart = new (MimeTypeMultipart as any)();
  instance._subtype = subtype;
  instance._parameters = parameters;
  return instance;
}
