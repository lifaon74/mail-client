import { MimeTypeParameter } from '../__components/mime-type-parameter-list/components/mime-type-parameter/mime-type-parameter.class';
import { MimeTypeParameterList } from '../__components/mime-type-parameter-list/mime-type-parameter-list.class';
import { MimeType } from '../mime-type.class';

export const MIME_TYPE_TEXT_HTML_UTF8_CONSTANT: MimeType = new MimeType(
  'text',
  'html',
  new MimeTypeParameterList([
    new MimeTypeParameter('charset', 'utf8'),
  ]),
);

