import { IMapTraitCollection, IToStringTrait } from '@lifaon/traits';

export interface IMimeTypeParameterList extends //
  IMapTraitCollection<string, string>,
  IToStringTrait
  //
{
}
