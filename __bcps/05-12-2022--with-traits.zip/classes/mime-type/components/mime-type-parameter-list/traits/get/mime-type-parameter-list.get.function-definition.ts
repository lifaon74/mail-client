export interface IMimeTypeParameterListGetFunction {
  (
    key: string,
  ): string | undefined;
}
