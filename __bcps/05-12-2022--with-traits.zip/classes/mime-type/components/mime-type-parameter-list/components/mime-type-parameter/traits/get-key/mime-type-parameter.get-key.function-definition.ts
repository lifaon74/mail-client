import { IMimeTypeParameterKey } from '../../components/mime-type-parameter-key/mime-type-parameter-key.type';

export interface IMimeTypeParameterGetKeyFunction {
  (): IMimeTypeParameterKey;
}
