export interface IMimeTypeParameterValueSetFunction {
  (
    value: string,
  ): void;
}
