import { IMimeTypeParameterGetValueFunction } from './mime-type-parameter.get-value.function-definition';

export interface IMimeTypeParameterGetValueTrait {
  getValue: IMimeTypeParameterGetValueFunction;
}
