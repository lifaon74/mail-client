export interface IMimeTypeParameterKeySetFunction {
  (
    value: string,
  ): void;
}
