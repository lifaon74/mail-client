export interface IMimeTypeParameterValueRequiresQuotingFunction {
  (): boolean;
}
