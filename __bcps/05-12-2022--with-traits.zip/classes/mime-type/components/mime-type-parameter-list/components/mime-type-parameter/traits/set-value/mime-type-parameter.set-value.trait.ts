import { IMimeTypeParameterSetValueFunction } from './mime-type-parameter.set-value.function-definition';

export interface IMimeTypeParameterSetValueTrait {
  setValue: IMimeTypeParameterSetValueFunction;
}
