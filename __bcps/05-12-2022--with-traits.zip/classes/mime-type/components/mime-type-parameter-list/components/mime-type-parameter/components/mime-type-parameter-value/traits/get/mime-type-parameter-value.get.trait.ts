import { IMimeTypeParameterValueGetFunction } from './mime-type-parameter-value.get.function-definition';

export interface IMimeTypeParameterValueGetTrait {
  get: IMimeTypeParameterValueGetFunction;
}
