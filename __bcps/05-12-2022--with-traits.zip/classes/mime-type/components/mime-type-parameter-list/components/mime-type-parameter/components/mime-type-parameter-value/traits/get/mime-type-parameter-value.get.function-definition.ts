export interface IMimeTypeParameterValueGetFunction {
  (): string;
}
