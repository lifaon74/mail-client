import { IMimeTypeParameterKeySetFunction } from './mime-type-parameter-key.set.function-definition';

export interface IMimeTypeParameterKeySetTrait {
  set: IMimeTypeParameterKeySetFunction;
}
