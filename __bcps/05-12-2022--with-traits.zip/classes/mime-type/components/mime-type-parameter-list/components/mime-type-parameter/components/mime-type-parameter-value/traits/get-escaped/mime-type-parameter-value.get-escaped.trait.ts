import { IMimeTypeParameterValueGetEscapedFunction } from './mime-type-parameter-value.get-escaped.function-definition';

export interface IMimeTypeParameterValueGetEscapedTrait {
  getEscaped: IMimeTypeParameterValueGetEscapedFunction;
}
