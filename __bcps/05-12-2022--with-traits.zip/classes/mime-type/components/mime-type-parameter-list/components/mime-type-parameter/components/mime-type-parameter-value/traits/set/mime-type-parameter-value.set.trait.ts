import { IMimeTypeParameterValueSetFunction } from './mime-type-parameter-value.set.function-definition';

export interface IMimeTypeParameterValueSetTrait {
  set: IMimeTypeParameterValueSetFunction;
}
