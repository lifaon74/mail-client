import { INewTrait } from '@lifaon/traits';
import { IMimeTypeParameterKeyNewArguments } from './mime-type-parameter-key.new.arguments';

export type IMimeTypeParameterKeyNewTrait<GReturn> = INewTrait<IMimeTypeParameterKeyNewArguments, GReturn>;
