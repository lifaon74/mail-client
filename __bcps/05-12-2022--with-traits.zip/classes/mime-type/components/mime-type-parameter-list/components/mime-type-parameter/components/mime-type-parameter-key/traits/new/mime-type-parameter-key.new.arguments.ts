export type IMimeTypeParameterKeyNewArguments = [
  value: string,
];
