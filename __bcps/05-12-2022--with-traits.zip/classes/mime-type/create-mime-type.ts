import { HTTP_TOKEN_PATTERN } from '../../constants/http-token-pattern.constant';
import {
  createMimeTypeParameterList,
  createMimeTypeParameterListFromString,
} from './components/mime-type-parameter-list/create-mime-type-parameter-list';
import { IMimeTypeParameterList } from './components/mime-type-parameter-list/mime-type-parameter-list.type';
import { IMimeType } from './mime-type.type';

const TYPE_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const TYPE_REGEXP = new RegExp(`^${TYPE_PATTERN}$`, 'g');

const SUBTYPE_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const SUBTYPE_REGEXP = new RegExp(`^${TYPE_PATTERN}$`, 'g');

const TYPE_AND_SUBTYPE_REGEXP: RegExp = new RegExp(`^(${TYPE_PATTERN})/(${SUBTYPE_PATTERN})$`);

/*
https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types
 */

export function createMimeType(
  _type: string,
  _subtype: string,
  _parameters: IMimeTypeParameterList,
): IMimeType {

  const getType = (): string => {
    return _type;
  };

  const setType = (
    value: string,
  ): void => {
    if (TYPE_REGEXP.test(value)) {
      _type = value;
    } else {
      throw new Error(`Invalid type`);
    }
  };

  const getSubType = (): string => {
    return _subtype;
  };

  const setSubType = (
    value: string,
  ): void => {
    if (SUBTYPE_REGEXP.test(value)) {
      _type = value;
    } else {
      throw new Error(`Invalid subtype`);
    }
  };

  const getParameters = (): IMimeTypeParameterList => {
    return _parameters;
  };

  const toString = (): string => {
    const parametersString: string = (_parameters.getSize() === 0)
      ? ''
      : `; ${_parameters.toString()}`;
    return `${_type}/${_subtype}${parametersString}`;
  };

  return {
    getType,
    setType,
    getSubType,
    setSubType,
    getParameters,
    toString,
  };
}

/*-----*/

export function createMimeTypeFromString(
  input: string,
): IMimeType {
  const index: number = input.indexOf(';');
  let typeAndSubtype: string;
  let parameters: string;

  if (index === -1) {
    typeAndSubtype = input;
    parameters = '';
  } else {
    typeAndSubtype = input.slice(0, index);
    parameters = input.slice(index + 1);
  }

  const match: RegExpExecArray | null = TYPE_AND_SUBTYPE_REGEXP.exec(typeAndSubtype);

  if (match === null) {
    throw new Error(`Invalid type or subtype`);
  } else {
    return createMimeType(
      match[1],
      match[2],
      (parameters === '')
        ? createMimeTypeParameterList()
        : createMimeTypeParameterListFromString(parameters),
    );
  }
}
