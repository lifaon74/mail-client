import { createMimeTypeParameterListFromString } from './components/mime-type-parameter-list/create-mime-type-parameter-list';
import { createMimeTypeFromString } from './create-mime-type';

export function mimeTypeDebug(): void {
  // const data = new MimeTypeParameter(
  //   MimeTypeParameterKey.fromString('abc'),
  //   MimeTypeParameterValue.fromString('def'),
  // );

  // console.log(createMimeTypeParameterKeyFromString('def').get());

  // console.log(createMimeTypeParameterValueFromString('def').getQuoted());
  // console.log(createMimeTypeParameterValueFromString('"def"').getQuoted());
  // console.log(createMimeTypeParameterValueFromString('"de\\"f"').getQuoted());
  // console.log(createMimeTypeParameterValueFromString('"de\\\\f"').getQuoted());
  // console.log(createMimeTypeParameterValueFromString('de"f').getQuoted());
  // console.log(createMimeTypeParameterValueFromString('"de"f"').getQuoted());
  // console.log(createMimeTypeParameterValueFromString('"de\\\\"f"').getQuoted());

  // console.log(createMimeTypeParameterFromString('abc="def"').toString());
  // console.log(createMimeTypeParameterFromString('abc="a\\"h"').toString());

  // console.log(createMimeTypeParameterListFromString('name="test.bin"').toString());
  // console.log(createMimeTypeParameterListFromString('name="test\\".bin"; abc="def"; bob ').toString());
  // console.log(createMimeTypeParameterListFromString('abc="def"; ghi').toString());

  console.log(createMimeTypeFromString('application/octet-stream; name="test.bin"').toString());

  // const data: MimeType = new MimeType(
  //   'multipart',
  //   'mixed',
  //   new MimeTypeParameterList([
  //     MimeTypeParameterBoundary.generate(),
  //   ]),
  // );

  // const data = MimeTypeMultipartAlternative.generate();
  // const data = MimeType.fromString(`application/octet-stream; name="test.bin"`);
  // const data = MimeTypeParameterList.fromString(`name="test.bin"`);
  // const data = MimeTypeParameterList.fromString(`name="test\\".bin"; abc="def"; bob `);
  // const data = MimeTypeParameterList.fromString(`abc="def"`);
  // const data = MimeTypeParameterList.fromString(`abc="def"; ghi`);
  // const data = MimeTypeParameterList.fromString(`abc="def" ;`);
  // const data = MimeTypeParameterList.fromString(`abc="def`);
  // const data = MimeTypeParameterList.fromString(`abc="def"; a=`);
  // const data = MimeTypeParameterList.fromString(`name="test\\\\".bin"`);
  // const data = MimeTypeParameterList.fromString(`name="test\\".bin"`);

  // console.log(data);
  // console.log(data.toString());
}
