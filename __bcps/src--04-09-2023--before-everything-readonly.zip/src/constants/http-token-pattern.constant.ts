export const HTTP_TOKEN_PATTERN = '[0-9a-zA-Z\\!\\#\\$\\%\\&\'\\*\\+\\-\\.\\^_\\`\\|\\~]';
