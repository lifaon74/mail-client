import { MimeTypeClass } from '../classes/mime-type/mime-type.class';
import { MimeTypeParameterKey } from '../classes/mime-type/mime-type-parameter/mime-type-parameter-key.class';
import { MimeTypeParameterValue } from '../classes/mime-type/mime-type-parameter/mime-type-parameter-value.class';
import { MimeTypeParameter } from '../classes/mime-type/mime-type-parameter/mime-type-parameter.class';
import { MimeTypeParameterList } from '../classes/mime-type/mime-type-parameter/mime-type-parameter-list.class';

export function mimeTypeDebug(): void {
  // const data = new MimeTypeParameter(
  //   MimeTypeParameterKey.parse('abc'),
  //   new MimeTypeParameterValue.parse('def'),
  // );

  // application/vnd.api+json
  // console.log(new MimeTypeParameterKey('def').value);
  //
  // console.log(new MimeTypeParameterValue('def').quoted);
  // console.log(new MimeTypeParameterValue('"def"').quoted);
  // console.log(new MimeTypeParameterValue('"de\\"f"').quoted);
  // console.log(new MimeTypeParameterValue('"de\\\\f"').quoted);
  // console.log(new MimeTypeParameterValue('de"f').quoted);
  // console.log(new MimeTypeParameterValue('"de"f"').quoted);
  // console.log(new MimeTypeParameterValue('"de\\\\"f"').quoted);

  // console.log(MimeTypeParameter.parse('abc="def"').toString());
  // console.log(MimeTypeParameter.parse('abc="a\\"h"').toString());

  // console.log(MimeTypeParameters.parse('name="test.bin"').toString());
  // console.log(MimeTypeParameters.parse('name="test\\".bin"; abc="def"; bob ').toString());
  // console.log(MimeTypeParameters.parse('abc="def"; ghi').toString());

  console.log(MimeTypeClass.parse('application/octet-stream; name="test.bin"'));
  // console.log(MimeTypeClass.parse('application/vnd.api+json'));

  // console.log(MIME_TYPE_TEXT_PLAIN_UTF8_CONSTANT.toString());

  // const data: IMimeType = createMimeTypeFromParts(
  //   'multipart',
  //   'mixed',
  //   createMimeTypeParametersFromMimeTypeParameters([
  //     generateMimeTypeParameterBoundary(),
  //   ]),
  // );

  // console.log(data.toString());

  // const data = MimeTypeMultipartAlternative.generate();
  // const data = MimeTypeClass.parse(`application/octet-stream; name="test.bin"`);
  // const data = MimeTypeParameters.parse(`name="test.bin"`);
  // const data = MimeTypeParameters.parse(`name="test\\".bin"; abc="def"; bob `);
  // const data = MimeTypeParameters.parse(`abc="def"`);
  // const data = MimeTypeParameters.parse(`abc="def"; ghi`);
  // const data = MimeTypeParameters.parse(`abc="def" ;`);
  // const data = MimeTypeParameters.parse(`abc="def`);
  // const data = MimeTypeParameters.parse(`abc="def"; a=`);
  // const data = MimeTypeParameters.parse(`name="test\\\\".bin"`);
  // const data = MimeTypeParameters.parse(`name="test\\".bin"`);

  // console.log(data);
  // console.log(data.toString());
}
