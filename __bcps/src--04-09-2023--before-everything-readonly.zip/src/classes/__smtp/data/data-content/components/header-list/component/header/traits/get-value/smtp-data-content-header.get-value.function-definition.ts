export interface ISMTPDataContentHeaderGetValueFunction {
  (): string;
}
