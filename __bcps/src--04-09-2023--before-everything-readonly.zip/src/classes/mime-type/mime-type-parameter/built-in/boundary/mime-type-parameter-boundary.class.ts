import { MimeTypeParameterWithReadonlyKey } from '../../mime-type-parameter.class';
import { MIME_TYPE_PARAMETER_BOUNDARY_KEY, IMimeTypeParameterBoundaryKeyName } from './mime-type-parameter-boundary-key.contant';

export class MimeTypeParameterBoundary extends MimeTypeParameterWithReadonlyKey<IMimeTypeParameterBoundaryKeyName> {
  constructor(
    boundary: string,
  ) {
    super(
      MIME_TYPE_PARAMETER_BOUNDARY_KEY,
      boundary,
    );
  }
}
