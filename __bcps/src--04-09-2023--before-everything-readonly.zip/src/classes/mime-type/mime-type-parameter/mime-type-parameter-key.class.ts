import { HTTP_TOKEN_PATTERN } from '../../../constants/http-token-pattern.constant';

/** PATTERNS **/

export const MIME_TYPE_PARAMETER_KEY_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const MIME_TYPE_PARAMETER_KEY_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_KEY_PATTERN}$`);

/** CLASS **/

export class MimeTypeParameterKey {
  #value!: string;

  constructor(
    value: string,
  ) {
    this.value = value;
  }

  get value(): string {
    return this.#value;
  }

  set value(
    input: string,
  ) {
    if (MIME_TYPE_PARAMETER_KEY_REGEXP.test(input)) {
      this.#value = input;
    } else {
      throw new Error(`Invalid key`);
    }
  }

  toString(): string {
    return this.#value;
  }
}


/* READONLY */

export class MimeTypeParameterKeyWithReadonlyValue<GValue extends string> extends MimeTypeParameterKey {
  constructor(
    value: GValue,
  ) {
    super(value);
  }

  override get value(): GValue {
    return super.value as GValue;
  }

  override set value(
    input: GValue,
  ) {
    if (this.value === void 0) {
      super.value = input;
    } else {
      throw new Error(`Readonly`);
    }
  }
}



