import {
  MimeTypeParameterValue,
  MIME_TYPE_PARAMETER_VALUE_PATTERN,
  IMimeTypeParameterValueToStringMode,
} from './mime-type-parameter-value.class';
import {
  MimeTypeParameterKey,
  MIME_TYPE_PARAMETER_KEY_PATTERN,
  MimeTypeParameterKeyWithReadonlyValue,
} from './mime-type-parameter-key.class';

/** PATTERNS **/

export const MIME_TYPE_PARAMETER_PATTERN = `(${MIME_TYPE_PARAMETER_KEY_PATTERN})(?:=(${MIME_TYPE_PARAMETER_VALUE_PATTERN}))?`;
const MIME_TYPE_PARAMETER_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_PATTERN}$`);

/** TYPES **/

export type IMimeTypeParameterKeyLike =
  | MimeTypeParameterKey
  | string
  ;

export type IMimeTypeParameterValueLike =
  | MimeTypeParameterValue
  | string
  ;

export type IMimeTypeParameterToStringMode = Omit<IMimeTypeParameterValueToStringMode, 'unquoted'>;

/** CLASS **/

export class MimeTypeParameter {
  static parse(
    input: string,
  ): MimeTypeParameter {
    const match: RegExpExecArray | null = MIME_TYPE_PARAMETER_REGEXP.exec(input);
    if (match === null) {
      throw new Error(`Invalid parameter`);
    } else {
      const [, keyString, valueString] = match;

      const key: MimeTypeParameterKey = new MimeTypeParameterKey(keyString);

      const value: MimeTypeParameterValue | null = (valueString === void 0)
        ? null
        : new MimeTypeParameterValue(valueString);

      return new MimeTypeParameter(
        key,
        value,
      );
    }
  }

  #key!: MimeTypeParameterKey;
  #value!: MimeTypeParameterValue | null;

  constructor(
    key: IMimeTypeParameterKeyLike,
    value: IMimeTypeParameterValueLike | null = null,
  ) {
    this.key = key;
    this.value = value;
  }

  get key(): MimeTypeParameterKey {
    return this.#key;
  }

  set key(
    input: IMimeTypeParameterKeyLike,
  ) {
    this.#key = (typeof input === 'string')
      ? new MimeTypeParameterKey(input)
      : input;
  }

  get value(): MimeTypeParameterValue | null {
    return this.#value;
  }

  set value(
    input: IMimeTypeParameterValueLike | null,
  ) {
    this.#value = (typeof input === 'string')
      ? (
        (input === '')
          ? null
          : new MimeTypeParameterValue(input)
      )
      : input;
  }

  toString(
    mode: IMimeTypeParameterToStringMode = 'optionally-quoted',
  ): string {
    return (this.#value === null)
      ? this.#key.toString()
      : `${this.#key.toString()}=${this.#value.toString(mode as IMimeTypeParameterValueToStringMode)}`;
  }
}

/* READONLY */

export type IMimeTypeParameterWithReadonlyKeyLike<GKey extends string> =
  | MimeTypeParameterKey
  | MimeTypeParameterKeyWithReadonlyValue<GKey>
  | GKey
  ;

export class MimeTypeParameterWithReadonlyKey<GKey extends string> extends MimeTypeParameter {
  constructor(
    key: IMimeTypeParameterWithReadonlyKeyLike<GKey>,
    value?: IMimeTypeParameterValueLike | null,
  ) {
    super(
      key,
      value,
    );
  }

  override get key(): MimeTypeParameterKeyWithReadonlyValue<GKey> {
    return super.key as MimeTypeParameterKeyWithReadonlyValue<GKey>;
  }

  override set key(
    input: IMimeTypeParameterWithReadonlyKeyLike<GKey>,
  ) {
    if (this.key === void 0) {
      if (typeof input === 'string') {
        super.key = new MimeTypeParameterKeyWithReadonlyValue(input);
      } else if (input instanceof MimeTypeParameterKeyWithReadonlyValue) {
        super.key = input;
      } else {
        super.key = new MimeTypeParameterKeyWithReadonlyValue<GKey>(input.value as GKey);
      }
    } else {
      throw new Error(`Readonly`);
    }
  }
}
