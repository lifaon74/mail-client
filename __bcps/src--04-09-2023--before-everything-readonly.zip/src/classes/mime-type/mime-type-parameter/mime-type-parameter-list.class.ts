import { MimeTypeParameter, IMimeTypeParameterToStringMode, MIME_TYPE_PARAMETER_PATTERN } from './mime-type-parameter.class';
import { MimeTypeParameterValue, IMimeTypeParameterValueToStringMode } from './mime-type-parameter-value.class';
import { Dedup } from '../../../types/dedup.type';
import { MimeTypeParameterKey } from './mime-type-parameter-key.class';
import { EmailContact } from '../../email-contact/email-contact.class';
import { iterableToArray } from '../../../misc/iterable-to-array';

/** PATTERNS **/

const MIME_TYPE_PARAMETER_LIST_KEY_AND_VALUE_REGEXP: RegExp = new RegExp(`\\s*${MIME_TYPE_PARAMETER_PATTERN}\\s*(?:;|$)`, 'g');

/** TYPES **/

export type IMimeTypeParameterListKeyValueTupleEntry = [
  key: string,
  value: string,
];

export type IMimeTypeParameterListEntry =
  | IMimeTypeParameterListKeyValueTupleEntry
  | MimeTypeParameter
  ;

/** CLASS **/

export class MimeTypeParameterList {
  static parse(
    input: string,
  ): MimeTypeParameterList {
    let match: RegExpExecArray | null;
    let index: number = 0;
    const items: [string, string][] = [];

    while ((match = MIME_TYPE_PARAMETER_LIST_KEY_AND_VALUE_REGEXP.exec(input)) !== null) {
      if ((index === 0) && (match.index !== 0)) {
        throw new Error(`Invalid parameters`);
      }

      const [, key, value = ''] = match;

      items.push([
        key,
        value,
      ]);

      index = match.index + match[0].length;
    }

    if (index !== input.length) {
      throw new Error(`Invalid parameters`);
    }

    return new MimeTypeParameterList(items);
  }

  #list: MimeTypeParameter[];

  constructor(
    parameters: Iterable<IMimeTypeParameterListEntry> = [],
    dedup: Dedup = 'replace',
  ) {
    this.#list = [];

    const iterator: Iterator<IMimeTypeParameterListEntry> = parameters[Symbol.iterator]();
    let result: IteratorResult<IMimeTypeParameterListEntry>;
    while (!(result = iterator.next()).done) {
      const entry: IMimeTypeParameterListEntry = result.value;
      if (entry instanceof MimeTypeParameter) {
        this.setParameter(
          entry,
          dedup,
        );
      } else {
        this.set(
          entry[0],
          entry[1],
          dedup,
        );
      }
    }
  }

  get list(): MimeTypeParameter[] {
    return this.#list;
  }

  set list(
    input: Iterable<MimeTypeParameter>,
  ) {
    this.#list = iterableToArray<MimeTypeParameter>(input);
  }

  /** ARRAY **/

  getParameterIndex(
    key: string,
    fromIndex: number = 0,
  ): number {
    for (const l: number = this.#list.length; fromIndex < l; fromIndex++) {
      const parameter: MimeTypeParameter = this.#list[fromIndex];
      if (parameter.key.toString() === key) {
        return fromIndex;
      }
    }
    return -1;
  }

  getParameter(
    key: string,
    fromIndex?: number,
  ): MimeTypeParameter | undefined {
    const index: number = this.getParameterIndex(key, fromIndex);
    return (index === -1)
      ? void 0
      : this.#list[index];
  }

  setParameter(
    parameter: MimeTypeParameter,
    dedup: Dedup = 'replace',
  ): void {
    const index: number = this.getParameterIndex(parameter.key.toString());
    if (index === -1) {
      this.#list.push(parameter);
    } else {
      if (dedup === 'throw') {
        throw new Error(`Parameter already exists`);
      } else if (dedup === 'replace') {
        this.#list[index] = parameter;
      } // skip => do nothing
    }
  }

  /** MAP **/

  get size(): number {
    return this.#list.length;
  }

  has(
    key: string,
  ): boolean {
    return this.getParameterIndex(key) !== -1;
  }

  get(
    key: string,
    mode: IMimeTypeParameterValueToStringMode = 'unquoted',
  ): string | undefined {
    const parameter: MimeTypeParameter | undefined = this.getParameter(key);

    if (parameter === void 0) {
      return void 0;
    } else {
      const value: MimeTypeParameterValue | null = parameter.value;

      if (value === null) {
        return undefined;
      } else {
        return value.toString(mode);
      }
    }
  }

  set(
    key: string,
    value: string,
    dedup?: Dedup,
  ): void {
    this.setParameter(
      new MimeTypeParameter(key, value),
      dedup,
    );
  }

  delete(
    key: string,
  ): boolean {
    const index: number = this.getParameterIndex(key);
    if (index === -1) {
      return false;
    } else {
      this.#list.splice(index, 1);
      return true;
    }
  }

  clear(): void {
    this.#list.length = 0;
  }

  * entries(
    mode: IMimeTypeParameterValueToStringMode = 'unquoted',
  ): IterableIterator<[string, string]> {
    for (let i: number = 0, l: number = this.#list.length; i < l; i++) {
      const parameter: MimeTypeParameter = this.#list[i];

      const key: MimeTypeParameterKey = parameter.key;
      const value: MimeTypeParameterValue | null = parameter.value;

      yield [
        key.toString(),
        (value === null)
          ? ''
          : value.toString(mode),
      ];
    }
  }

  [Symbol.iterator](
    mode?: IMimeTypeParameterValueToStringMode,
  ): IterableIterator<[string, string]> {
    return this.entries(mode);
  }

  toString(
    mode: IMimeTypeParameterToStringMode = 'optionally-quoted',
  ): string {
    let output: string = '';

    for (let i: number = 0, l: number = this.#list.length; i < l; i++) {
      if (output !== '') {
        output += '; ';
      }

      output += this.#list[i].toString(mode);
    }

    return output;
  }
}
