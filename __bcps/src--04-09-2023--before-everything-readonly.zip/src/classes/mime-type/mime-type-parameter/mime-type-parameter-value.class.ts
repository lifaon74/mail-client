import { HTTP_TOKEN_PATTERN } from '../../../constants/http-token-pattern.constant';
import { HTTP_QUOTED_STRING_TOKEN_PATTERN } from '../../../constants/http-quoted-string-token-pattern.constant';

/** PATTERNS **/

// do not requires quoting
const MIME_TYPE_PARAMETER_VALUE_NOT_REQUIRING_QUOTING_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const MIME_TYPE_PARAMETER_VALUE_NOT_REQUIRING_QUOTING_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_VALUE_NOT_REQUIRING_QUOTING_PATTERN}$`);

// requires quoting
const MIME_TYPE_PARAMETER_VALUE_REQUIRING_QUOTING_PATTERN = `${HTTP_QUOTED_STRING_TOKEN_PATTERN}+`;
const MIME_TYPE_PARAMETER_VALUE_REQUIRING_QUOTING_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_VALUE_REQUIRING_QUOTING_PATTERN}$`);

// is quoted
const MIME_TYPE_PARAMETER_VALUE_QUOTED_PATTERN = `"(?:[\\u0009\\u0020-\\u0021\\u0023-\\u005b\\u005d-\\u007e\\u0080-\\u00ff]|(?:\\\\")|(?:\\\\\\\\))+"`;
const MIME_TYPE_PARAMETER_VALUE_QUOTED_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_VALUE_QUOTED_PATTERN}$`);

// value
export const MIME_TYPE_PARAMETER_VALUE_PATTERN = `(?:${MIME_TYPE_PARAMETER_VALUE_NOT_REQUIRING_QUOTING_PATTERN})|(?:${MIME_TYPE_PARAMETER_VALUE_QUOTED_PATTERN})`;

/** TYPES **/

export type IMimeTypeParameterValueToStringMode =
  | 'unquoted'
  | 'quoted'
  | 'optionally-quoted'
  ;

/** CLASS **/

export class MimeTypeParameterValue {
  #value!: string;
  #requiresQuoting!: boolean; // computed

  constructor(
    value: string,
  ) {
    this.value = value;
  }

  get value(): string {
    return this.#value;
  }

  set value(
    input: string,
  ) {
    if (MIME_TYPE_PARAMETER_VALUE_NOT_REQUIRING_QUOTING_REGEXP.test(input)) {
      this.#value = input;
      this.#requiresQuoting = false;
    } else {
      if (MIME_TYPE_PARAMETER_VALUE_QUOTED_REGEXP.test(input)) {
        input = unquoteMimeTypeParameterValue(input);
        this.#value = input;
        this.#requiresQuoting = doesMimeTypeParameterValueRequireQuoting(input);
      } else if (MIME_TYPE_PARAMETER_VALUE_REQUIRING_QUOTING_REGEXP.test(input)) {
        this.#value = input;
        this.#requiresQuoting = true;
      } else {
        throw new Error(`Invalid value`);
      }
    }
  }

  get requiresQuoting(): boolean {
    return this.#requiresQuoting;
  }

  get quoted(): string {
    return quoteMimeTypeParameterValue(this.#value);
  }

  get optionallyQuoted(): string {
    return this.#requiresQuoting
      ? this.quoted
      : this.value;
  }

  toString(
    mode: IMimeTypeParameterValueToStringMode = 'optionally-quoted',
  ): string {
    if (mode === 'unquoted') {
      return this.value;
    } else if (mode === 'quoted') {
      return this.quoted;
    } else {
      return this.optionallyQuoted;
    }
  }
}

/** FUNCTIONS **/

function escapeMimeTypeParameterValue(
  value: string,
): string {
  return value
    .replace('\\', '\\\\')
    .replace('"', '\\"');
}

function quoteMimeTypeParameterValue(
  value: string,
): string {
  return `"${escapeMimeTypeParameterValue(value)}"`;
}

function unescapeMimeTypeParameterValue(
  value: string,
): string {
  return value
    .replace('\\', '');
}

function unquoteMimeTypeParameterValue(
  value: string,
): string {
  return unescapeMimeTypeParameterValue(
    value
      .slice(1, -1),
  );
}

function doesMimeTypeParameterValueRequireQuoting(
  value: string,
): boolean {
  return !MIME_TYPE_PARAMETER_VALUE_NOT_REQUIRING_QUOTING_REGEXP.test(value);
}


