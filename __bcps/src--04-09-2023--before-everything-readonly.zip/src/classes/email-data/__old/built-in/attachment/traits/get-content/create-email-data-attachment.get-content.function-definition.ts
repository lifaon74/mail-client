export interface IEmailDataAttachmentGetContentFunction {
  (): string;
}
