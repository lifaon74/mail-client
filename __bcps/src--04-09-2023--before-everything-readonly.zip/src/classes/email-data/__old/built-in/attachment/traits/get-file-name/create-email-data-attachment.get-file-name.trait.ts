import { IEmailDataAttachmentGetFileNameFunction } from './create-email-data-attachment.get-file-name.function-definition';

export interface IEmailDataAttachmentGetFileNameTrait {
  getFileName: IEmailDataAttachmentGetFileNameFunction;
}
