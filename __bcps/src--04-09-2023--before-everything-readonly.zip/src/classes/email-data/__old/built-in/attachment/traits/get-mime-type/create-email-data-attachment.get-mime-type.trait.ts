import { IEmailDataAttachmentGetMimeTypeFunction } from './create-email-data-attachment.get-mime-type.function-definition';

export interface IEmailDataAttachmentGetMimeTypeTrait {
  getMimeType: IEmailDataAttachmentGetMimeTypeFunction;
}
