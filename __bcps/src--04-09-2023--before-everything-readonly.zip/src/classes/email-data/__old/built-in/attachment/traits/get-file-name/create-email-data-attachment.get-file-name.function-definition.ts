export interface IEmailDataAttachmentGetFileNameFunction {
  (): string;
}
