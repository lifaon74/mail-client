import { IEmailDataTextHTMLGetHTMLFunction } from './create-email-data-text-html.get-html.function-definition';

export interface IEmailDataTextHTMLGetHTMLTrait {
  getHTML: IEmailDataTextHTMLGetHTMLFunction;
}
