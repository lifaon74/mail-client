export interface IEmailDataTextPlainGetTextFunction {
  (): string;
}
