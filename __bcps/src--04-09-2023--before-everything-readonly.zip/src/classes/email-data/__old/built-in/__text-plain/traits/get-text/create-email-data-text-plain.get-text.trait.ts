import { IEmailDataTextPlainGetTextFunction } from './create-email-data-text-plain.get-text.function-definition';

export interface IEmailDataTextPlainGetTextTrait {
  getText: IEmailDataTextPlainGetTextFunction;
}
