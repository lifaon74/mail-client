import {
  IEmailHeaderContentTransferEncodingGetMimeTypeFunction,
} from './email-header-content-transfer-encoding.get-content-transfer-encoding.function-definition';

export interface IEmailHeaderContentTransferEncodingGetMimeTypeTrait {
  getContentTransferEncoding: IEmailHeaderContentTransferEncodingGetMimeTypeFunction;
}
