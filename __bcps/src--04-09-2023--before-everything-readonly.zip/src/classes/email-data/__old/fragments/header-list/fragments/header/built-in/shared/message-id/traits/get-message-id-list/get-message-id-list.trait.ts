import { IGetMessageIdListFunction } from './get-message-id-list.function-definition';

export interface IGetMessageIdListTrait {
  getMessageIdList: IGetMessageIdListFunction;
}
