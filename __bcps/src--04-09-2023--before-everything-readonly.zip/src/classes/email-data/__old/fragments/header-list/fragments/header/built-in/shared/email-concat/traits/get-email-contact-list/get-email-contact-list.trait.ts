import { IGetEmailContactListFunction } from './get-email-contact-list.function-definition';

export interface IGetEmailContactListTrait {
  getEmailContactList: IGetEmailContactListFunction;
}
