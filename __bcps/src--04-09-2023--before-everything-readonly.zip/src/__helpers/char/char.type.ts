import { u8 } from '@lifaon/number-types';

export type char_t = u8; // [0, 127]

