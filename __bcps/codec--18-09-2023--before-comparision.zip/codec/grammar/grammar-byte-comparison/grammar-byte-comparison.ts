import { IGrammarByteComparisonAstNode, GrammarByteComparisonAstNodeType } from './grammar-byte-comparison-ast-node.type';
import { IGrammarByteComparisonExpressionAstNode } from './comparisions/grammar-byte-comparison-expression-ast-node.type';

export function GrammarByteComparison(
  expression: IGrammarByteComparisonExpressionAstNode,
): IGrammarByteComparisonAstNode {
  return {
    __type__: GrammarByteComparisonAstNodeType,
    expression,
  };
}


/*
GrammarByteComparison(
  or(eq(1), neq(1), gt(1), lt(1), lte(1), gte(1), and(4, 5), not(5))

  range(1, 2) => and(gte(1), lte(2))
)
 */
