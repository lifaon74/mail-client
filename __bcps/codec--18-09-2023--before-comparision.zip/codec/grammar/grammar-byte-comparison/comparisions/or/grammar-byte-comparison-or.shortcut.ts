import { GrammarByteComparisonOr } from './grammar-byte-comparison-or';

export const or = GrammarByteComparisonOr;

