import {
  IGrammarByteComparisonEqualsAstNode,
  isGrammarByteComparisonEqualsAstNode,
} from './equals/grammar-byte-comparison-equals-ast-node.type';

export type IGrammarByteComparisonExpressionAstNode =
  | IGrammarByteComparisonEqualsAstNode
  ;

export function isGrammarByteComparisonExpressionAstNode(
  input: object,
): input is IGrammarByteComparisonExpressionAstNode {
  return isGrammarByteComparisonEqualsAstNode(input);
}

