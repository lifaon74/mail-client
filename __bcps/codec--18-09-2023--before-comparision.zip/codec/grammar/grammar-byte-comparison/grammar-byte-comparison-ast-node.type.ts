import { AstNode } from '../../../../ast/__shared__/ast-node.type';
import { isAstNode } from '../../../../ast/__shared__/is-ast-node';
import { IGrammarByteComparisonExpressionAstNode } from './comparisions/grammar-byte-comparison-expression-ast-node.type';

export const GrammarByteComparisonAstNodeType = 'GrammarByteComparison';

export type IGrammarByteComparisonAstNodeType = typeof GrammarByteComparisonAstNodeType;

export interface IGrammarByteComparisonAstNode extends AstNode<IGrammarByteComparisonAstNodeType> {
  readonly expression: IGrammarByteComparisonExpressionAstNode;
}

export function isGrammarByteComparisonAstNode(
  input: object,
): input is IGrammarByteComparisonAstNode {
  return isAstNode<IGrammarByteComparisonAstNodeType>(input, GrammarByteComparisonAstNodeType);
}

