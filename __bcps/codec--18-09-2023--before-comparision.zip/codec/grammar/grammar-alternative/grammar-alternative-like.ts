import { IGrammarExpressionLikeList, grammarExpressionLikeListToExpressionList } from '../__shared__/grammar-expression-like.type';
import { IGrammarAlternativeAstNode } from './grammar-alternative-ast-node.type';
import { GrammarAlternative } from './grammar-alternative';

export function GrammarAlternativeLike(
  expressions: IGrammarExpressionLikeList,
): IGrammarAlternativeAstNode {
  return GrammarAlternative(
    grammarExpressionLikeListToExpressionList(expressions),
  );
}
