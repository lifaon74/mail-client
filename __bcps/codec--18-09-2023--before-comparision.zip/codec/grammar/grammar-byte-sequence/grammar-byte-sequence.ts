import { IGrammarByteSequenceAstNode, GrammarByteSequenceAstNodeType } from './grammar-byte-sequence-ast-node.type';

export function GrammarByteSequence(
  bytes: Uint8Array,
): IGrammarByteSequenceAstNode {
  return {
    __type__: GrammarByteSequenceAstNodeType,
    bytes,
  };
}

