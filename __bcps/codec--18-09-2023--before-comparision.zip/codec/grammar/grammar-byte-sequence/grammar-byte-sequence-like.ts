import { IByteSequenceLike, byteSequenceLikeToUint8Array } from '../__shared__/byte-sequence-like.type';
import { IGrammarByteSequenceAstNode } from './grammar-byte-sequence-ast-node.type';
import { GrammarByteSequence } from './grammar-byte-sequence';

export function GrammarByteSequenceLike(
  bytes: IByteSequenceLike,
): IGrammarByteSequenceAstNode {
  return GrammarByteSequence(
    byteSequenceLikeToUint8Array(bytes),
  );
}
