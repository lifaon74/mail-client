import { IGrammarByteSequenceAstNode } from './grammar-byte-sequence-ast-node.type';
import { GrammarByteSequence } from './grammar-byte-sequence';

export function GrammarByteString(
  input: string,
): IGrammarByteSequenceAstNode {
  return GrammarByteSequence(
    new TextEncoder().encode(input),
  );
}



