import { IByteSequenceLike, byteSequenceLikeToUint8Array } from '../__shared__/byte-sequence-like.type';
import { IGrammarByteAlternativeAstNode } from './grammar-byte-alternative-ast-node.type';
import { GrammarByteAlternative } from './grammar-byte-alternative';

export function GrammarByteAlternativeLike(
  bytes: IByteSequenceLike,
): IGrammarByteAlternativeAstNode {
  return GrammarByteAlternative(
    byteSequenceLikeToUint8Array(bytes),
  );
}
