import { AstNode } from '../../../../ast/__shared__/ast-node.type';
import { isAstNode } from '../../../../ast/__shared__/is-ast-node';

export const GrammarByteAlternativeAstNodeType = 'GrammarByteAlternative';

export type IGrammarByteAlternativeAstNodeType = typeof GrammarByteAlternativeAstNodeType;

export interface IGrammarByteAlternativeAstNode extends AstNode<IGrammarByteAlternativeAstNodeType> {
  readonly bytes: Uint8Array;
}

export function isGrammarByteAlternativeAstNode(
  input: object,
): input is IGrammarByteAlternativeAstNode {
  return isAstNode<IGrammarByteAlternativeAstNodeType>(input, GrammarByteAlternativeAstNodeType);
}

