import { IGrammarByteAlternativeAstNode, GrammarByteAlternativeAstNodeType } from './grammar-byte-alternative-ast-node.type';

export function GrammarByteAlternative(
  bytes: Uint8Array,
): IGrammarByteAlternativeAstNode {
  return {
    __type__: GrammarByteAlternativeAstNodeType,
    bytes,
  };
}

// export function GrammarByteAllExcept(
//   bytes: Uint8Array,
// ): IGrammarByteAlternativeAstNode {
//   return {
//     __type__: GrammarByteAlternativeAstNodeType,
//     bytes,
//   };
// }
