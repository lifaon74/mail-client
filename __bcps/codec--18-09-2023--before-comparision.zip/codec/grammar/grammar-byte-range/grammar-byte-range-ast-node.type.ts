import { AstNode } from '../../../../ast/__shared__/ast-node.type';
import { isAstNode } from '../../../../ast/__shared__/is-ast-node';

export const GrammarByteRangeAstNodeType = 'GrammarByteRange';

export type IGrammarByteRangeAstNodeType = typeof GrammarByteRangeAstNodeType;

export interface IGrammarByteRangeAstNode extends AstNode<IGrammarByteRangeAstNodeType> {
  readonly start: number;
  readonly end: number;
}

export function isGrammarByteRangeAstNode(
  input: object,
): input is IGrammarByteRangeAstNode {
  return isAstNode<IGrammarByteRangeAstNodeType>(input, GrammarByteRangeAstNodeType);
}

