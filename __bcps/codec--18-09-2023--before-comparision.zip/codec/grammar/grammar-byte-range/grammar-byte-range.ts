import { IGrammarByteRangeAstNode, GrammarByteRangeAstNodeType } from './grammar-byte-range-ast-node.type';

export function GrammarByteRange(
  start: number,
  end: number,
): IGrammarByteRangeAstNode {
  return {
    __type__: GrammarByteRangeAstNodeType,
    start,
    end,
  };
}
