import { IGrammarRuleAstNode, GrammarRuleAstNodeType } from './grammar-rule-ast-node.type';
import { grammarExpressionLikeToExpression, IGrammarExpressionLike } from '../__shared__/grammar-expression-like.type';

export function GrammarRule(
  name: string,
  expression: IGrammarExpressionLike,
): IGrammarRuleAstNode {
  return {
    __type__: GrammarRuleAstNodeType,
    name,
    expression: grammarExpressionLikeToExpression(expression),
  };
}
