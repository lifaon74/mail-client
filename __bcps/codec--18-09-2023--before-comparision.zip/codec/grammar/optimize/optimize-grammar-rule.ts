import { IGrammarRuleAstNode } from '../grammar-rule/grammar-rule-ast-node.type';
import { optimizeGrammarExpression } from './optimize-grammar-expression';
import { IGrammarExpressionAstNode } from '../grammar-expression/grammar-expression-ast-node.type';
import { GrammarRule } from '../grammar-rule/grammar-rule';

export function optimizeGrammarRule(
  node: IGrammarRuleAstNode,
): IGrammarRuleAstNode {
  const optimizedExpression: IGrammarExpressionAstNode = optimizeGrammarExpression(node.expression);

  if (optimizedExpression === node.expression) {
    return node;
  } else {
    return GrammarRule(
      node.name,
      optimizedExpression,
    );
  }
}
