import { isGrammarConcatAstNode } from '../grammar-concat/grammar-concat-ast-node.type';
import { isGrammarByteSequenceAstNode } from '../grammar-byte-sequence/grammar-byte-sequence-ast-node.type';
import { isGrammarAlternativeAstNode } from '../grammar-alternative/grammar-alternative-ast-node.type';
import { isGrammarRuleIdentifierAstNode } from '../grammar-rule-identifier/grammar-rule-identifier-ast-node.type';
import { optimizeGrammarConcat } from './optimize-grammar-concat';
import { optimizeGrammarByteSequence } from './optimize-grammar-byte-sequence';
import { IGrammarExpressionAstNode } from '../grammar-expression/grammar-expression-ast-node.type';
import { optimizeGrammarAlternative } from './optimize-grammar-alternative';
import { isGrammarByteRangeAstNode } from '../grammar-byte-range/grammar-byte-range-ast-node.type';
import { optimizeGrammarByteRange } from './optimize-grammar-byte-range';
import { optimizeGrammarRepeat } from './optimize-grammar-repeat';
import { isGrammarRepeatAstNode } from '../grammar-repeat/grammar-repeat-ast-node.type';
import { optimizeGrammarRuleIdentifier } from './optimize-grammar-rule-identifier';
import { optimizeGrammarByteAlternative } from './optimize-grammar-byte-alternative';
import { isGrammarByteAlternativeAstNode } from '../grammar-byte-alternative/grammar-byte-alternative-ast-node.type';

export function optimizeGrammarExpression(
  node: IGrammarExpressionAstNode,
): IGrammarExpressionAstNode {
  if (isGrammarAlternativeAstNode(node)) {
    return optimizeGrammarAlternative(node);
  } else if (isGrammarByteAlternativeAstNode(node)) {
    return optimizeGrammarByteAlternative(node);
  } else if (isGrammarByteRangeAstNode(node)) {
    return optimizeGrammarByteRange(node);
  } else if (isGrammarByteSequenceAstNode(node)) {
    return optimizeGrammarByteSequence(node);
  } else if (isGrammarConcatAstNode(node)) {
    return optimizeGrammarConcat(node);
  } else if (isGrammarRepeatAstNode(node)) {
    return optimizeGrammarRepeat(node);
  } else if (isGrammarRuleIdentifierAstNode(node)) {
    return optimizeGrammarRuleIdentifier(node);
  } else {
    throw new Error(`Unknown node: ${(node as any).__type__}`);
  }
}
