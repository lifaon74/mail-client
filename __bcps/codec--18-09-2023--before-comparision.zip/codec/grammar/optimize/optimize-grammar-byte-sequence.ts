import { IGrammarByteSequenceAstNode } from '../grammar-byte-sequence/grammar-byte-sequence-ast-node.type';

export function optimizeGrammarByteSequence(
  node: IGrammarByteSequenceAstNode,
): IGrammarByteSequenceAstNode {
  return node;
}
