import { IGrammarConcatAstNode } from '../grammar-concat/grammar-concat-ast-node.type';
import { optimizeGrammarExpression } from './optimize-grammar-expression';
import { IGrammarExpressionAstNode } from '../grammar-expression/grammar-expression-ast-node.type';
import { GrammarByteSequence } from '../grammar-byte-sequence/grammar-byte-sequence';
import { GrammarEmpty } from '../grammar-byte-sequence/grammar-empty';
import { GrammarConcat } from '../grammar-concat/grammar-concat';
import { isGrammarByteSequenceAstNode } from '../grammar-byte-sequence/grammar-byte-sequence-ast-node.type';

export function optimizeGrammarConcat(
  node: IGrammarConcatAstNode,
): IGrammarExpressionAstNode {
  const optimizedExpressions: IGrammarExpressionAstNode[] = [];
  let byteSequence: number[] | undefined = void 0;

  // TODO optimize repetitions

  const appendByteSequence = (): void => {
    if (byteSequence !== void 0) {
      optimizedExpressions.push(
        GrammarByteSequence(
          new Uint8Array(byteSequence),
        ),
      );
      byteSequence = void 0;
    }
  };

  for (let i: number = 0, l: number = node.expressions.length; i < l; i++) {
    const optimizedExpression: IGrammarExpressionAstNode = optimizeGrammarExpression(node.expressions[i]);

    if (isGrammarByteSequenceAstNode(optimizedExpression)) {
      if (byteSequence === void 0) {
        byteSequence = [...optimizedExpression.bytes];
      } else {
        byteSequence.push(...optimizedExpression.bytes);
      }
    } else {
      appendByteSequence();
      optimizedExpressions.push(optimizedExpression);
    }
  }

  appendByteSequence();

  if (optimizedExpressions.length === 0) {
    return GrammarEmpty;
  } else if (optimizedExpressions.length === 1) {
    return optimizedExpressions[0];
  } else {
    return (
      (optimizedExpressions.length === node.expressions.length)
      && optimizedExpressions.every((optimizedExpression: IGrammarExpressionAstNode, index: number): boolean => {
        return optimizedExpression === node.expressions[index];
      })
    )
      ? node
      : GrammarConcat(optimizedExpressions);
  }
}
