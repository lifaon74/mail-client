import { IGrammarExpressionAstNode } from '../grammar-expression/grammar-expression-ast-node.type';
import { IGrammarRuleIdentifierAstNode } from '../grammar-rule-identifier/grammar-rule-identifier-ast-node.type';

export function optimizeGrammarRuleIdentifier(
  node: IGrammarRuleIdentifierAstNode,
): IGrammarExpressionAstNode {
  return node;
}
