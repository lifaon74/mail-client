import { IGrammarByteRangeAstNode } from '../grammar-byte-range/grammar-byte-range-ast-node.type';
import { GrammarByteSequence } from '../grammar-byte-sequence/grammar-byte-sequence';
import { IGrammarByteSequenceAstNode } from '../grammar-byte-sequence/grammar-byte-sequence-ast-node.type';

export function optimizeGrammarByteRange(
  node: IGrammarByteRangeAstNode,
): IGrammarByteRangeAstNode | IGrammarByteSequenceAstNode {
  if (node.start === node.end) {
    return GrammarByteSequence(new Uint8Array([node.start]));
  } else {
    return node;
  }
}
