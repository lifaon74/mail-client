import { IGrammarExpressionAstNode } from '../grammar-expression/grammar-expression-ast-node.type';
import { IGrammarByteAlternativeAstNode } from '../grammar-byte-alternative/grammar-byte-alternative-ast-node.type';

export function optimizeGrammarByteAlternative(
  node: IGrammarByteAlternativeAstNode,
): IGrammarExpressionAstNode {
  // TODO
  return node;
}
