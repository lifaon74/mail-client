import { IGrammarAlternativeAstNode } from '../grammar-alternative/grammar-alternative-ast-node.type';
import { optimizeGrammarExpression } from './optimize-grammar-expression';
import { IGrammarExpressionAstNode } from '../grammar-expression/grammar-expression-ast-node.type';
import { GrammarEmpty } from '../grammar-byte-sequence/grammar-empty';
import { GrammarAlternative } from '../grammar-alternative/grammar-alternative';
import { isGrammarByteSequenceAstNode } from '../grammar-byte-sequence/grammar-byte-sequence-ast-node.type';
import { GrammarByteRange } from '../grammar-byte-range/grammar-byte-range';

export function optimizeGrammarAlternative(
  node: IGrammarAlternativeAstNode,
): IGrammarExpressionAstNode {

  const optimizedExpressions: IGrammarExpressionAstNode[] = [];
  let byteRange: [start: number, end: number] | undefined = void 0;

  const appendByteRange = (): void => {
    if (byteRange !== void 0) {
      optimizedExpressions.push(
        GrammarByteRange(
          byteRange[0],
          byteRange[1],
        ),
      );
      byteRange = void 0;
    }
  };

  for (let i: number = 0, l: number = node.expressions.length; i < l; i++) {
    const optimizedExpression: IGrammarExpressionAstNode = optimizeGrammarExpression(node.expressions[i]);

    // TODO do not append byteRange if one char only
    if (isGrammarByteSequenceAstNode(optimizedExpression) && (optimizedExpression.bytes.length === 1)) {
      if (byteRange === void 0) {
        byteRange = [
          optimizedExpression.bytes[0],
          optimizedExpression.bytes[0],
        ];
      } else {
        byteRange = [
          Math.min(byteRange[0], optimizedExpression.bytes[0]),
          Math.max(byteRange[1], optimizedExpression.bytes[0]),
        ];
      }
    } else {
      appendByteRange();
      optimizedExpressions.push(optimizedExpression);
    }
  }

  appendByteRange();

  if (optimizedExpressions.length === 0) {
    return GrammarEmpty;
  } else if (optimizedExpressions.length === 1) {
    return optimizedExpressions[0];
  } else {
    return (
      (optimizedExpressions.length === node.expressions.length)
      && optimizedExpressions.every((optimizedExpression: IGrammarExpressionAstNode, index: number): boolean => {
        return optimizedExpression === node.expressions[index];
      })
    )
      ? node
      : GrammarAlternative(optimizedExpressions);
  }
}
