import { IGrammarRepeatAstNode, GrammarRepeatAstNodeType } from './grammar-repeat-ast-node.type';
import { IGrammarExpressionAstNode } from '../grammar-expression/grammar-expression-ast-node.type';
import { IGrammarExpressionLike, grammarExpressionLikeToExpression } from '../__shared__/grammar-expression-like.type';

export function GrammarRepeat(
  expression: IGrammarExpressionLike,
  min: number = 0,
  max: number = Number.POSITIVE_INFINITY,
): IGrammarRepeatAstNode {
  return {
    __type__: GrammarRepeatAstNodeType,
    expression: grammarExpressionLikeToExpression(expression),
    min,
    max,
  };
}
