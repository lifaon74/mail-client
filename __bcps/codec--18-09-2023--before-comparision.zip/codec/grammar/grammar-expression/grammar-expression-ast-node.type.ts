import { IGrammarAlternativeAstNode, isGrammarAlternativeAstNode } from '../grammar-alternative/grammar-alternative-ast-node.type';
import { isGrammarByteSequenceAstNode, IGrammarByteSequenceAstNode } from '../grammar-byte-sequence/grammar-byte-sequence-ast-node.type';
import { IGrammarConcatAstNode, isGrammarConcatAstNode } from '../grammar-concat/grammar-concat-ast-node.type';
import {
  IGrammarRuleIdentifierAstNode,
  isGrammarRuleIdentifierAstNode,
} from '../grammar-rule-identifier/grammar-rule-identifier-ast-node.type';
import { IGrammarByteRangeAstNode, isGrammarByteRangeAstNode } from '../grammar-byte-range/grammar-byte-range-ast-node.type';
import { IGrammarRepeatAstNode, isGrammarRepeatAstNode } from '../grammar-repeat/grammar-repeat-ast-node.type';
import {
  isGrammarByteAlternativeAstNode,
  IGrammarByteAlternativeAstNode,
} from '../grammar-byte-alternative/grammar-byte-alternative-ast-node.type';

export type IGrammarExpressionAstNode =
  | IGrammarAlternativeAstNode
  | IGrammarByteAlternativeAstNode
  | IGrammarByteRangeAstNode
  | IGrammarByteSequenceAstNode
  | IGrammarConcatAstNode
  | IGrammarRepeatAstNode
  | IGrammarRuleIdentifierAstNode
  ;

export function isGrammarExpressionAstNode(
  input: object,
): input is IGrammarExpressionAstNode {
  return isGrammarAlternativeAstNode(input)
    || isGrammarByteAlternativeAstNode(input)
    || isGrammarByteRangeAstNode(input)
    || isGrammarByteSequenceAstNode(input)
    || isGrammarConcatAstNode(input)
    || isGrammarRepeatAstNode(input)
    || isGrammarRuleIdentifierAstNode(input)
    ;
}

