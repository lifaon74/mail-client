import { IGrammarExpressionLikeList, grammarExpressionLikeListToExpressionList } from '../__shared__/grammar-expression-like.type';
import { IGrammarConcatAstNode } from './grammar-concat-ast-node.type';
import { GrammarConcat } from './grammar-concat';

export function GrammarConcatLike(
  expressions: IGrammarExpressionLikeList,
): IGrammarConcatAstNode {
  return GrammarConcat(
    grammarExpressionLikeListToExpressionList(expressions),
  );
}
