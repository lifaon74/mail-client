import { GrammarRule } from './grammar/grammar-rule/grammar-rule';
import { GrammarConcat } from './grammar/grammar-concat/grammar-concat';
import { GrammarByte } from './grammar/grammar-byte-sequence/grammar-byte';
import {
  CHAR_0,
  CHAR_A_LOWER_CASE,
  CHAR_B_LOWER_CASE,
  CHAR_1,
  CHAR_2,
  CHAR_9,
  CHAR_Z_LOWER_CASE,
  CHAR_Z_UPPER_CASE,
  CHAR_A_UPPER_CASE,
  CHAR_F_LOWER_CASE,
  CHAR_F_UPPER_CASE,
  CHAR_EXCLAMATION_MARK,
  CHAR_NUMBER_SIGN,
  CHAR_DOLLAR,
  CHAR_PERCENT,
  CHAR_AMPERSAND,
  CHAR_SINGLE_QUOTE,
  CHAR_ASTERISK,
  CHAR_PLUS,
  CHAR_MINUS,
  CHAR_HAT,
  CHAR_DOT,
  CHAR_UNDERSCORE,
  CHAR_GRAVE,
  CHAR_VERTICAL_BAR,
  CHAR_TILDE,
  CHAR_DOUBLE_QUOTE, CHAR_EQUALS, CHAR_BACKSLASH, CHAR_SLASH, CHAR_SEMI_COLON,
} from '../../constants/chars/chars.constant';
import { IGrammarAstNode } from './grammar/grammar/grammar-ast-node.type';
import { Grammar } from './grammar/grammar/grammar';
import { ILines } from '../../misc/lines/lines.type';
import { linesToString } from '../../misc/lines/functions/lines-to-string';
import { IGrammarRuleAstNode } from './grammar/grammar-rule/grammar-rule-ast-node.type';
import { GrammarAlternative } from './grammar/grammar-alternative/grammar-alternative';
import { indentLines } from '../../misc/lines/functions/indent-lines';
import { IGrammarAlternativeAstNode, isGrammarAlternativeAstNode } from './grammar/grammar-alternative/grammar-alternative-ast-node.type';
import { IGrammarConcatAstNode, isGrammarConcatAstNode } from './grammar/grammar-concat/grammar-concat-ast-node.type';
import { IGrammarExpressionAstNode } from './grammar/grammar-expression/grammar-expression-ast-node.type';
import {
  isGrammarRuleIdentifierAstNode,
  IGrammarRuleIdentifierAstNode,
} from './grammar/grammar-rule-identifier/grammar-rule-identifier-ast-node.type';
import { GrammarRuleIdentifier } from './grammar/grammar-rule-identifier/grammar-rule-identifier';
import {
  IGrammarByteSequenceAstNode,
  isGrammarByteSequenceAstNode,
} from './grammar/grammar-byte-sequence/grammar-byte-sequence-ast-node.type';
import { optimizeGrammar } from './grammar/optimize/optimize-grammar';
import { GrammarByteRange } from './grammar/grammar-byte-range/grammar-byte-range';
import { IGrammarByteRangeAstNode, isGrammarByteRangeAstNode } from './grammar/grammar-byte-range/grammar-byte-range-ast-node.type';
import { IGrammarRepeatAstNode, isGrammarRepeatAstNode } from './grammar/grammar-repeat/grammar-repeat-ast-node.type';
import { inlineLastLines } from '../../misc/lines/functions/after-last-line';
import { GrammarByteString } from './grammar/grammar-byte-sequence/grammar-byte-string';
import { GrammarByteAlternative } from './grammar/grammar-byte-alternative/grammar-byte-alternative';
import { GrammarRepeat } from './grammar/grammar-repeat/grammar-repeat';
import {
  IGrammarByteAlternativeAstNode,
  isGrammarByteAlternativeAstNode,
} from './grammar/grammar-byte-alternative/grammar-byte-alternative-ast-node.type';

/*---------*/
export type byte_t = number;

export type IDecoderResult<GValue> = IteratorResult<void, GValue>;

export type IDecoder<GValue> = Iterator<void, GValue, byte_t>;

export interface IDecoderFactory<GValue> {
  (): IDecoder<GValue>;
}

export type IDecoderGenerator<GValue> = Generator<void, GValue, byte_t>;

export interface IDecoderIterable<GValue> {
  [Symbol.iterator]: IDecoderFactory<GValue>;
}

export type IEncoder = Iterator<byte_t, void, void>;

/*---------*/

// export function textEncoder(
//   input: string,
// ): IEncoder {
//   new TextEncoder().encode(input);
// }

/*---------*/

/*
tutorial: https://tomassetti.me/guide-parsing-algorithms-terminology/

https://en.wikipedia.org/wiki/Backus%E2%80%93Naur_form
https://en.wikipedia.org/wiki/Extended_Backus%E2%80%93Naur_form

https://github.com/dhconnelly/prettybnf
from bnf to abnf: https://softwareengineering.stackexchange.com/questions/356419/is-repetition-expressed-in-backus-naur-form-by-recursive-production-definitions

 */

export interface IUint8ArrayParser {
  (
    buffer: Uint8Array,
    index: number,
  ): IParsedUint8ArrayAstNode | IGenericParsedUint8ArrayErrorAstNode;
}

export interface IParsedUint8ArrayAstNode {
  readonly type: string;
  readonly start: number;
  readonly end: number;
  readonly children: readonly IParsedUint8ArrayAstNode[];
}

export interface IParsedUint8ArrayErrorAstNode<GSubType extends string> {
  readonly type: 'error';
  readonly subType: GSubType;
  readonly start: number;
  readonly end: number;
}

export type IGenericParsedUint8ArrayErrorAstNode = IParsedUint8ArrayErrorAstNode<string>;

export interface IParsedUint8ArrayErrorAlternativeAstNode extends IParsedUint8ArrayErrorAstNode<'alternative'> {
  readonly errors: readonly IGenericParsedUint8ArrayErrorAstNode[];
}

export interface IParsedUint8ArrayErrorByteRangeAstNode extends IParsedUint8ArrayErrorAstNode<'byte-range'> {
  readonly range: readonly [start: number, end: number];
}

export interface IParsedUint8ArrayErrorRuleAstNode extends IParsedUint8ArrayErrorAstNode<'rule'> {
  readonly name: string;
  readonly error: IGenericParsedUint8ArrayErrorAstNode;
}

export function transpileGrammarAlternativeToJavascriptParseUint8ArrayToAstFunction(
  {
    expressions,
  }: IGrammarAlternativeAstNode,
): ILines {
  return [
    `(buffer, index) => {`,
    ...indentLines([
      `const errors = [];`,
      ``,
      `const expressions = [`,
      ...indentLines([
        ...expressions.flatMap((expression: IGrammarExpressionAstNode): ILines => {
          return inlineLastLines(
            transpileGrammarExpressionToJavascriptParseUint8ArrayToAstFunction(expression),
            [`,`],
          );
        }),
      ]),
      `];`,
      ``,
      `for (let i = 0; i < ${expressions.length}; i++) {`,
      ...indentLines([
        `const result = expressions[i](buffer, index);`,
        ``,
        `if (result.type === 'error') {`,
        ...indentLines([
          `errors.push(result);`,
        ]),
        `} else {`,
        ...indentLines([
          `return {`,
          ...indentLines([
            `type: 'alternative',`,
            `start: index,`,
            `end: result.end,`,
            `children: [result],`,
          ]),
          `};`,
        ]),
        `}`,
      ]),
      `}`,
      ``,
      `return {`,
      ...indentLines([
        `type: 'error',`,
        `subType: 'alternative',`,
        `start: index,`,
        `end: index + 1,`, // TODO maybe errors(max(error.end))
        `errors,`,
      ]),
      `};`,
    ]),
    `}`,
  ];
}

export function transpileGrammarByteAlternativeToJavascriptParseUint8ArrayToAstFunction(
  {
    bytes,
  }: IGrammarByteAlternativeAstNode,
): ILines {
  return [
    `(buffer, index) => {`,
    ...indentLines([
      `return (`,
      ...indentLines([
        ...Array.from(bytes).flatMap((byte: number, index: number): ILines => {
          return [
            `${(index > 0) ? '|| ' : ''}(buffer[index] === ${byte})`,
          ];
        }),
      ]),
      `) `,
      ...indentLines([
        `? {`,
        ...indentLines([
          `type: 'byte-alternative',`,
          `start: index,`,
          `end: index + 1,`,
          `children: [],`,
        ]),
        `} : {`,
        ...indentLines([
          `type: 'error',`,
          `subType: 'byte-range',`,
          `start: index,`,
          `end: index + 1,`,
          `bytes: new Uint8Array([${bytes.join(', ')}]),`,
        ]),
        `};`,
      ]),
    ]),
    `}`,
  ];
}

export function transpileGrammarByteRangeToJavascriptParseUint8ArrayToAstFunction(
  {
    start,
    end,
  }: IGrammarByteRangeAstNode,
): ILines {
  return [
    `(buffer, index) => {`,
    ...indentLines([
      `return (${start} <= buffer[index] && buffer[index] <= ${end})`,
      ...indentLines([
        `? {`,
        ...indentLines([
          `type: 'byte-range',`,
          `start: index,`,
          `end: index + 1,`,
          `children: [],`,
        ]),
        `} : {`,
        ...indentLines([
          `type: 'error',`,
          `subType: 'byte-range',`,
          `start: index,`,
          `end: index + 1,`,
          `range: [${start}, ${end}],`,
        ]),
        `};`,
      ]),
    ]),
    `}`,
  ];
}

export function transpileGrammarByteSequenceToJavascriptParseUint8ArrayToAstFunction(
  {
    bytes,
  }: IGrammarByteSequenceAstNode,
): ILines {
  return [
    `(buffer, index) => {`,
    ...indentLines([
      `return (`,
      ...indentLines([
        ...Array.from(bytes).flatMap((byte: number, index: number): ILines => {
          return [
            `${(index > 0) ? '&& ' : ''}(buffer[index + ${index}] === ${byte})`,
          ];
        }),
      ]),
      `) `,
      ...indentLines([
        `? {`,
        ...indentLines([
          `type: 'byte-sequence',`,
          `start: index,`,
          `end: index + ${bytes.length},`,
          `children: [],`,
        ]),
        `} : {`,
        ...indentLines([
          `type: 'error',`,
          `subType: 'byte-sequence',`,
          `start: index,`,
          `end: index + ${bytes.length},`,
          `bytes: new Uint8Array([${bytes.join(', ')}]),`,
        ]),
        `};`,
      ]),
    ]),
    `}`,
  ];
}

export function transpileGrammarConcatToJavascriptParseUint8ArrayToAstFunction(
  {
    expressions,
  }: IGrammarConcatAstNode,
): ILines {
  return [
    `(buffer, index) => {`,
    ...indentLines([
      `const children = new Array(${expressions.length});`,
      `let _index = index;`,
      ``,
      `const expressions = [`,
      ...indentLines([
        ...expressions.flatMap((expression: IGrammarExpressionAstNode): ILines => {
          return inlineLastLines(
            transpileGrammarExpressionToJavascriptParseUint8ArrayToAstFunction(expression),
            [`,`],
          );
        }),
      ]),
      `];`,
      ``,
      `for (let i = 0; i < ${expressions.length}; i++) {`,
      ...indentLines([
        `const result = expressions[i](buffer, _index);`,
        ``,
        `if (result.type === 'error') {`,
        ...indentLines([
          `return {`,
          ...indentLines([
            `type: 'error',`,
            `subType: 'concat',`,
            `start: index,`,
            `end: result.end,`,
            `error: result,`,
          ]),
          `};`,
        ]),
        `} else {`,
        ...indentLines([
          `children[i] = result;`,
          `_index = result.end;`,
        ]),
        `}`,
      ]),
      `}`,
      ``,
      `return {`,
      ...indentLines([
        `type: 'concat',`,
        `start: index,`,
        `end: _index,`,
        `children,`,
      ]),
      `};`,
    ]),
    `}`,
  ];
}

export function transpileGrammarExpressionToJavascriptParseUint8ArrayToAstFunction(
  node: IGrammarExpressionAstNode,
): ILines {
  if (isGrammarAlternativeAstNode(node)) {
    return transpileGrammarAlternativeToJavascriptParseUint8ArrayToAstFunction(node);
  } else if (isGrammarByteAlternativeAstNode(node)) {
    return transpileGrammarByteAlternativeToJavascriptParseUint8ArrayToAstFunction(node);
  } else if (isGrammarByteRangeAstNode(node)) {
    return transpileGrammarByteRangeToJavascriptParseUint8ArrayToAstFunction(node);
  } else if (isGrammarByteSequenceAstNode(node)) {
    return transpileGrammarByteSequenceToJavascriptParseUint8ArrayToAstFunction(node);
  } else if (isGrammarConcatAstNode(node)) {
    return transpileGrammarConcatToJavascriptParseUint8ArrayToAstFunction(node);
  } else if (isGrammarRepeatAstNode(node)) {
    return transpileGrammarRepeatToJavascriptParseUint8ArrayToAstFunction(node);
  } else if (isGrammarRuleIdentifierAstNode(node)) {
    return transpileGrammarRuleIdentifierToJavascriptParseUint8ArrayToAstFunction(node);
  } else {
    throw new Error(`Unknown node: ${(node as any).type}`);
  }
}

export function transpileGrammarRepeatToJavascriptParseUint8ArrayToAstFunction(
  {
    expression,
    min,
    max,
  }: IGrammarRepeatAstNode,
): ILines {
  return [

    `(buffer, index) => {`,
    ...indentLines([
      `let children = [];`,
      `let _index = index;`,
      ``,
      `const expression = (`,
      ...indentLines([
        ...transpileGrammarExpressionToJavascriptParseUint8ArrayToAstFunction(expression),
      ]),
      `);`,
      ``,
      `for (let i = 0; i <= ${max}; i++) {`,
      ...indentLines([
        `const result = expression(buffer, _index);`,

        `if (result.type === 'error') {`,
        ...indentLines([
          `if (${(min === max) ? `i === ${min}` : `(${min} <= i) && (i <= ${max})`}) {`,
          ...indentLines([
            `break;`,
          ]),
          `} else {`,
          ...indentLines([
            `return {`,
            ...indentLines([
              `type: 'error',`,
              `subType: 'repeat',`,
              `start: index,`,
              `end: result.end,`,
              `error: result,`,
            ]),
            `};`,
          ]),
          `}`,
        ]),
        `} else {`,
        ...indentLines([
          `children.push(result);`,
          `_index = result.end;`,
        ]),
        `}`,
      ]),
      `}`,
      ``,
      `return {`,
      ...indentLines([
        `type: 'repeat',`,
        `start: index,`,
        `end: _index,`,
        `children,`,
      ]),
      `};`,
    ]),
    `}`,
  ];
}

export function transpileGrammarRuleToJavascriptParseUint8ArrayToAstFunction(
  {
    name,
    expression,
  }: IGrammarRuleAstNode,
): ILines {
  return [
    `rules.set(${JSON.stringify(name)}, (buffer, index) => {`,
    ...indentLines([
      `const result = (`,
      ...indentLines([
        ...transpileGrammarExpressionToJavascriptParseUint8ArrayToAstFunction(expression),
      ]),
      `)(buffer, index);`,
      ``,
      `if (result.type === 'error') {`,
      ...indentLines([
        `return {`,
        ...indentLines([
          `type: 'error',`,
          `subType: 'rule',`,
          `start: index,`,
          `end: result.end,`,
          `name: ${JSON.stringify(name)},`,
          `error: result,`,
        ]),
        `};`,
      ]),
      `} else {`,
      ...indentLines([
        `return {`,
        ...indentLines([
          `type: 'rule',`,
          `start: index,`,
          `end: result.end,`,
          `children: [result],`,
          `name: ${JSON.stringify(name)},`,
        ]),
        `};`,
      ]),
      `}`,
    ]),
    `});`,
  ];
}

export function transpileGrammarRuleIdentifierToJavascriptParseUint8ArrayToAstFunction(
  {
    name,
  }: IGrammarRuleIdentifierAstNode,
): ILines {
  return [
    `(buffer, index) => {`,
    ...indentLines([
      `return rules.get(${JSON.stringify(name)})(buffer, index);`,
    ]),
    `}`,
  ];
}

export function transpileGrammarToJavascriptParseUint8ArrayToAstFunction(
  {
    rules,
  }: IGrammarAstNode,
): ILines {
  return [
    `(`,
    ...indentLines([
      `rules = new Map(),`,
    ]),
    `) => {`,
    ...indentLines([
      ...rules.flatMap(transpileGrammarRuleToJavascriptParseUint8ArrayToAstFunction),
      `return rules;`,
    ]),
    `}`,
  ];
}

export type IUint8ArrayParserRules = Map<string, IUint8ArrayParser>;

export interface IGrammarForUint8ArrayParser {
  (
    rules?: IUint8ArrayParserRules,
  ): IUint8ArrayParserRules;
}

export function compileAndOptimizeGrammarToJavascriptParseUint8ArrayToAstFunction(
  grammar: IGrammarAstNode,
): IGrammarForUint8ArrayParser {
  return compileGrammarToJavascriptParseUint8ArrayToAstFunction(
    optimizeGrammar(grammar),
  );
}

export function compileGrammarToJavascriptParseUint8ArrayToAstFunction(
  grammar: IGrammarAstNode,
): IGrammarForUint8ArrayParser {
  const code: string = linesToString(
    transpileGrammarToJavascriptParseUint8ArrayToAstFunction(
      grammar,
    ),
  );

  console.log(code);

  return new Function('rules', `return (${code})(rules);`) as IGrammarForUint8ArrayParser;
}

/*---------*/

// console.groupCollapsed(`${error.name}: ${error.message}`);
// console.error(error);
// console.log(`at index ${error.start} of:`);
// console.log(error.buffer);
//
// const chunkAStyle: string = '';
// const chunkBStyle: string = 'color: red; font-weight: bold';
// const chunkCStyle: string = 'color: rgba(255, 0, 0, 0.7);';
//
// const chunkA: Uint8Array = error.buffer.slice(Math.max(0, error.start - extra), error.start);
// const chunkB: Uint8Array = error.buffer.slice(error.start, error.end);
// const chunkC: Uint8Array = error.buffer.slice(error.end + 1, error.end + extra);
//
// console.log(`%c...${chunkA.join(', ')}, %c${chunkB.join(', ')}, %c${chunkC.join(', ')}...`, chunkAStyle, chunkBStyle, chunkCStyle);
// console.log(`%c...${new TextDecoder().decode(chunkA)}%c${new TextDecoder().decode(chunkB)}%c${new TextDecoder().decode(chunkC)}...`, chunkAStyle, chunkBStyle, chunkCStyle);
// console.groupEnd();

export function printBufferChunkError(
  buffer: Uint8Array,
  start: number,
  end: number,
  extra: number = 30,
): void {

  const chunkBeforeStyle: string = '';
  const chunkErroredStyle: string = 'color: red; font-weight: bold';
  const chunkAfterStyle: string = 'color: rgba(255, 0, 0, 0.7);';

  const chunkBeforeStart: number = Math.max(0, start - extra);
  const chunkAfterEnd: number = Math.min(buffer.length, end + extra);

  const chunkBefore: Uint8Array = buffer.slice(chunkBeforeStart, start);
  const chunkErrored: Uint8Array = buffer.slice(start, end);
  const chunkAfter: Uint8Array = buffer.slice(end + 1, chunkAfterEnd);

  const before = (value: string = '...'): string => {
    return (chunkBeforeStart === 0)
      ? ''
      : value;
  };

  const after = (value: string = '...'): string => {
    return (chunkAfterEnd === buffer.length)
      ? ''
      : value;
  };

  const afterIfNotEmpty = (input: string, after: string): string => {
    return (input === '')
      ? ''
      : `${input}${after}`;
  };

  const bytes = (chunk: Uint8Array): string => {
    return chunk.join(', ');
  };

  const chars = (chunk: Uint8Array): string => {
    return new TextDecoder().decode(chunk);
  };

  console.log(`from index ${start} to ${end}:`);
  console.log(`%c${before()}${afterIfNotEmpty(bytes(chunkBefore), ', ')}%c${afterIfNotEmpty(bytes(chunkErrored), ', ')}%c${bytes(chunkAfter)}${after()}`, chunkBeforeStyle, chunkErroredStyle, chunkAfterStyle);
  console.log(`%c${before()}${chars(chunkBefore)}%c${chars(chunkErrored)}%c${chars(chunkAfter)}${after()}`, chunkBeforeStyle, chunkErroredStyle, chunkAfterStyle);
}

export function printGrammarErrorBuffer(
  buffer: Uint8Array,
  {
    start,
    end,
  }: IGenericParsedUint8ArrayErrorAstNode,
): void {
  printBufferChunkError(buffer, start, end);
}

export function printGrammarAlternativeError(
  buffer: Uint8Array,
  {
    errors,
  }: IParsedUint8ArrayErrorAlternativeAstNode,
): void {
  console.log('Alternative:');
  errors.forEach((error: IGenericParsedUint8ArrayErrorAstNode, index: number): void => {
    console.groupCollapsed(`alternative - ${index}`);
    printGrammarError(buffer, error);
    console.groupEnd();
  });
}

export function printGrammarByteRangeError(
  buffer: Uint8Array,
  node: IParsedUint8ArrayErrorByteRangeAstNode,
): void {
  console.log(`Expected byte in range [${node.range[0]}, ${node.range[1]}]`);
  printGrammarErrorBuffer(buffer, node);
}

export function printGrammarRuleError(
  buffer: Uint8Array,
  {
    name,
    error,
  }: IParsedUint8ArrayErrorRuleAstNode,
): void {
  console.groupCollapsed(`in rule: ${name}`);
  printGrammarError(buffer, error);
  console.groupEnd();
}

export function printGrammarError(
  buffer: Uint8Array,
  node: IGenericParsedUint8ArrayErrorAstNode,
): void {
  if (node.subType === 'alternative') {
    printGrammarAlternativeError(buffer, node as any);
  } else if (node.subType === 'byte-range') {
    printGrammarByteRangeError(buffer, node as any);
  } else if (node.subType === 'rule') {
    printGrammarRuleError(buffer, node as any);
  } else {
    console.log('TODO');
  }
}

/*---------*/

function grammarDebug1(): void {
  const digit = GrammarRule('digit', GrammarByteRange(CHAR_0, CHAR_9));
  const alpha_lowercase = GrammarRule('alpha_lowercase', GrammarAlternative([
    GrammarByte(CHAR_A_LOWER_CASE),
    GrammarByte(CHAR_B_LOWER_CASE),
    GrammarRuleIdentifier('digit'),
  ]));

  const grammar = Grammar([
    digit,
    alpha_lowercase,
  ]);
  // console.log(grammar);

  const optimizedGrammar = optimizeGrammar(grammar);

  console.log(optimizedGrammar);

  // console.log(optimizeGrammarConcat(GrammarConcat([GrammarByte(CHAR_0), GrammarByte(CHAR_1), GrammarByte(CHAR_2)])));
  // console.log(optimizeGrammarAlternative(GrammarAlternative([GrammarByte(CHAR_0), GrammarByte(CHAR_1), GrammarByte(CHAR_2)])));
  // console.log(optimizeGrammarRule(alpha_lowercase));
  // console.log(optimizeGrammar(grammar));

  // // const lines: ILines = transpileGrammarByteToJavascriptParseUint8ArrayToAstFunction(GrammarByte(CHAR_0));
  // // const lines: ILines = transpileGrammarConcatToJavascriptParseUint8ArrayToAstFunction(GrammarConcat([GrammarByte(CHAR_0), GrammarByte(CHAR_1)]));
  // // const lines: ILines = transpileGrammarAlternativeToJavascriptParseUint8ArrayToAstFunction(GrammarAlternative([GrammarByte(CHAR_0), GrammarByte(CHAR_1)]));
  // const lines: ILines = transpileGrammarRuleToJavascriptParseUint8ArrayToAstFunction(digit);
  // // const lines: ILines = transpileGrammarRuleToJavascriptParseUint8ArrayToAstFunction(alpha_lowercase);
  // // const lines: ILines = transpileGrammarToJavascriptParseUint8ArrayToAstFunction(grammar);
  //
  // const code: string = linesToString(lines);
  //
  // console.log(code);
  //
  // const fnc = new Function('buffer', 'index', `return (${code})(buffer, index);`);
  //
  // console.log(fnc([CHAR_0, CHAR_1], 0));
  // // console.log(fnc([CHAR_A_LOWER_CASE, CHAR_1], 0));
}

// email rfc: https://datatracker.ietf.org/doc/html/rfc2045
// email rfc: https://datatracker.ietf.org/doc/html/rfc2046
// MIME type rfc: https://datatracker.ietf.org/doc/html/rfc2425#section-15

function grammarDebug2(): void {
  const digit = GrammarRule('digit', GrammarByteRange(CHAR_0, CHAR_9));
  const hex_digit = GrammarRule(
    'hex_digit',
    GrammarAlternative([
      GrammarRuleIdentifier('digit'),
      GrammarByteRange(CHAR_A_LOWER_CASE, CHAR_F_LOWER_CASE),
      GrammarByteRange(CHAR_A_UPPER_CASE, CHAR_F_UPPER_CASE),
    ]),
  );

  const alpha_lower_case = GrammarRule('alpha_lower_case', GrammarByteRange(CHAR_A_LOWER_CASE, CHAR_Z_LOWER_CASE));
  const alpha_upper_case = GrammarRule('alpha_upper_case', GrammarByteRange(CHAR_A_UPPER_CASE, CHAR_Z_UPPER_CASE));
  const alpha = GrammarRule('alpha',
    GrammarAlternative([
      GrammarRuleIdentifier('alpha_lower_case'),
      GrammarRuleIdentifier('alpha_upper_case'),
    ]),
  );

  const grammar = Grammar([
    digit,
    hex_digit,
    alpha_lower_case,
    alpha_upper_case,
    alpha,
  ]);

  const compiledGrammar = compileAndOptimizeGrammarToJavascriptParseUint8ArrayToAstFunction(grammar);
  const rules = compiledGrammar();

  const buffer = new Uint8Array([CHAR_0, CHAR_1, CHAR_2]);

  const tree = rules.get('alpha')!(buffer, 0);

  console.log(tree);

  printGrammarError(buffer, tree as any);
}

function grammarDebug3(): void {
  // mime-type: https://datatracker.ietf.org/doc/html/rfc2045#section-5.1
  // list of iana mime-types: https://www.iana.org/assignments/media-types/media-types.xhtml#multipart

  /*
  // http://bibnum.bnf.fr/WARC/WARC_ISO_28500_version1_latestdraft.pdf

  named-field = field-name ":" [ field-value ]
 field-name = token
 field-value = *( field-content | LWS ) ; further qualified
 ; by field
 ; definitions
 field-content = <the OCTETs making up the field-value
 and consisting of either *TEXT or combinations
 of token, separators, and quoted-string>
 OCTET = <any 8-bit sequence of data>
 token = 1*<any US-ASCII character
 except CTLs or separators>
 separators = "(" | ")" | "<" | ">" | "@"
 | "," | ";" | ":" | "\" | <">
 | "/" | "[" | "]" | "?" | "="
 | "{" | "}" | SP | HT
 TEXT = <any OCTET except CTLs,
 but including LWS>
 CHAR = <UTF-8 characters; RFC3629> ; (0-191, 194-244)
 DIGIT = <any US-ASCII digit "0".."9">
 CTL = <any US-ASCII control character
 (octets 0 - 31) and DEL (127)>
 CR = <ASCII CR, carriage return> ; (13)
ISO 28500
© ISO 2006 — All rights reserved 5
 LF = <ASCII LF, linefeed> ; (10)
 SP = <ASCII SP, space> ; (32)
 HT = <ASCII HT, horizontal-tab> ; (9)
 CRLF = CR LF
 LWS = [CRLF] 1*( SP | HT ) ; semantics same as
 ; single SP
 quoted-string = ( <"> *(qdtext | quoted-pair ) <"> )
 qdtext = <any TEXT except <">>
 quoted-pair = "\" CHAR ; single-character quoting
 uri = "<" <'URI' per RFC3986> ">"

   */

  const mime_type = GrammarRule('mime-type', GrammarConcat([
    GrammarRuleIdentifier('type'),
    GrammarByte(CHAR_SLASH),
    GrammarRuleIdentifier('subtype'),
    GrammarRepeat(
      GrammarConcat([
        GrammarByte(CHAR_SEMI_COLON),
        GrammarRuleIdentifier('parameter'),
      ]),
    ),
  ]));

  const type = GrammarRule('type', GrammarRuleIdentifier('token'));

  const subtype = GrammarRule('subtype', GrammarRuleIdentifier('token'));

  const parameter = GrammarRule('parameter', GrammarConcat([
    GrammarRuleIdentifier('attribute'),
    GrammarByte(CHAR_EQUALS),
    GrammarRuleIdentifier('value'),
  ]));

  const attribute = GrammarRule('attribute', GrammarRuleIdentifier('token'));

  const value = GrammarRule('value', GrammarAlternative([
    // GrammarRuleIdentifier('token'),
    GrammarRuleIdentifier('quoted-string'),
  ]));

  const token = GrammarRule('token', GrammarRepeat(
    GrammarAlternative([
      // TODO support all except
      GrammarByteRange(CHAR_0, CHAR_9),
      GrammarByteRange(CHAR_A_LOWER_CASE, CHAR_Z_LOWER_CASE),
      GrammarByteRange(CHAR_A_UPPER_CASE, CHAR_Z_UPPER_CASE),
      GrammarByteAlternative(new Uint8Array([
        CHAR_EXCLAMATION_MARK,
        CHAR_NUMBER_SIGN,
        CHAR_DOLLAR,
        CHAR_PERCENT,
        CHAR_AMPERSAND,
        CHAR_SINGLE_QUOTE,
        CHAR_ASTERISK,
        CHAR_PLUS,
        CHAR_MINUS,
        CHAR_DOT,
        CHAR_HAT,
        CHAR_UNDERSCORE,
        CHAR_GRAVE,
        CHAR_VERTICAL_BAR,
        CHAR_TILDE,
      ])),
    ]),
    1,
  ));

  const quoted_string = GrammarRule('quoted-string', GrammarConcat([
    GrammarByte(CHAR_DOUBLE_QUOTE),
    GrammarRepeat(
      GrammarAlternative([
        GrammarRuleIdentifier('quoted-string-token'),
        GrammarRuleIdentifier('quoted-pair'),
      ]),
    ),
    GrammarByte(CHAR_DOUBLE_QUOTE),
  ]));

  const quoted_pair = GrammarRule('quoted-pair', GrammarConcat([
    GrammarByte(CHAR_BACKSLASH),
    GrammarByte(CHAR_DOUBLE_QUOTE),
  ]));

  const quoted_string_token = GrammarRule('quoted-string-token', GrammarAlternative([
    GrammarByte(0x09),
    GrammarByteRange(0x20 /* SP */, 0x21 /* ! */),
    // exclude "
    GrammarByteRange(0x23 /* # */, 0x7e /* ~ */),
  ]));

  const grammar = Grammar([
    mime_type,
    type,
    subtype,
    parameter,
    attribute,
    value,
    token,
    quoted_string,
    quoted_pair,
    quoted_string_token,
  ]);

  const compiledGrammar = compileAndOptimizeGrammarToJavascriptParseUint8ArrayToAstFunction(grammar);
  const rules = compiledGrammar();

  // const buffer = new Uint8Array([CHAR_0, CHAR_1, CHAR_2]);
  const buffer = new TextEncoder().encode('image/png; asefesf="i7888888888888888\\"888888888888888888888888888888888"');
  console.log(buffer);

  const tree = rules.get('mime-type')!(buffer, 0);

  console.log(tree);

  printGrammarError(buffer, tree as any);
}

/*---------*/

export async function codecDebug(): Promise<void> {
  // grammarDebug1();
  // grammarDebug2();
  grammarDebug3();
}
