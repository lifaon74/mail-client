export type char_string_t = Uint8Array; // of char_t

