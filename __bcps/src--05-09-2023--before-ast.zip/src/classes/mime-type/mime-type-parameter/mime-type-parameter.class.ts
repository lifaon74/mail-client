import {
  MimeTypeParameterValue,
  MIME_TYPE_PARAMETER_VALUE_PATTERN,
  IMimeTypeParameterValueToStringMode,
  IMimeTypeParameterValueToStringOptions,
} from './mime-type-parameter-value.class';
import { MimeTypeParameterKey, MIME_TYPE_PARAMETER_KEY_PATTERN } from './mime-type-parameter-key.class';

/** PATTERNS **/

export const MIME_TYPE_PARAMETER_PATTERN = `(${MIME_TYPE_PARAMETER_KEY_PATTERN})(?:=(${MIME_TYPE_PARAMETER_VALUE_PATTERN}))?`;
const MIME_TYPE_PARAMETER_REGEXP = new RegExp(`^${MIME_TYPE_PARAMETER_PATTERN}$`);

/** TYPES **/

export type IMimeTypeParameterToStringMode = Omit<IMimeTypeParameterValueToStringMode, 'unquoted'>;

export interface IMimeTypeParameterToStringOptions extends Omit<IMimeTypeParameterValueToStringOptions, 'mode'> {
  mode?: IMimeTypeParameterToStringMode;
}

export interface IMimeTypeParameterParseToPartsResult {
  key: MimeTypeParameterKey;
  value: MimeTypeParameterValue;
}

/** CLASS **/

export class MimeTypeParameter {
  static parse(
    input: string,
  ): MimeTypeParameter {
    const match: RegExpExecArray | null = MIME_TYPE_PARAMETER_REGEXP.exec(input);
    if (match === null) {
      throw new Error(`Invalid parameter`);
    } else {
      const [, key, value = ''] = match;

      return new MimeTypeParameter(
        key,
        value,
      );
    }
  }

  static parseToParts(
    input: string,
  ): IMimeTypeParameterParseToPartsResult {
    const match: RegExpExecArray | null = MIME_TYPE_PARAMETER_REGEXP.exec(input);
    if (match === null) {
      throw new Error(`Invalid parameter`);
    } else {
      const [, key, value = ''] = match;

      return {
        key: new MimeTypeParameterKey(key),
        value: new MimeTypeParameterValue(value),
      };
    }
  }

  readonly #key: MimeTypeParameterKey;
  readonly #value: MimeTypeParameterValue;

  constructor(
    key: string,
    value: string = '',
  ) {
    this.#key = new MimeTypeParameterKey(key);
    this.#value = new MimeTypeParameterValue(value);
  }

  get keyObject(): MimeTypeParameterKey {
    return this.#key.value;
  }

  get key(): string {
    return this.#key.value;
  }

  get value(): MimeTypeParameterValue {
    return this.#value;
  }

  toString(
    {
      mode = 'optionally-quoted',
    }: IMimeTypeParameterToStringOptions = {},
  ): string {
    return (this.#value.value === '')
      ? this.#key.toString()
      : `${this.#key.toString()}=${this.#value.toString({ mode: mode as IMimeTypeParameterValueToStringMode })}`;
  }
}
