import { MimeTypeParameterKeyWithReadonlyValue } from '../../mime-type-parameter-key.class';

export const MIME_TYPE_PARAMETER_BOUNDARY_KEY_NAME = 'boundary';

export type IMimeTypeParameterBoundaryKeyName = typeof MIME_TYPE_PARAMETER_BOUNDARY_KEY_NAME;

export const MIME_TYPE_PARAMETER_BOUNDARY_KEY = new MimeTypeParameterKeyWithReadonlyValue<IMimeTypeParameterBoundaryKeyName>(MIME_TYPE_PARAMETER_BOUNDARY_KEY_NAME);
