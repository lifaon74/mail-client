import { HTTP_TOKEN_PATTERN } from '../../constants/http-token-pattern.constant';
import { MimeTypeParameterList } from './mime-type-parameter/mime-type-parameter-list.class';
import { IMimeTypeParameterToStringMode } from './mime-type-parameter/mime-type-parameter.class';

/** PATTERNS **/

const TYPE_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const TYPE_REGEXP = new RegExp(`^${TYPE_PATTERN}$`);

const SUBTYPE_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const SUBTYPE_REGEXP = new RegExp(`^${TYPE_PATTERN}$`);

const TYPE_AND_SUBTYPE_REGEXP: RegExp = new RegExp(`^(${TYPE_PATTERN})/(${SUBTYPE_PATTERN})$`, 'g');

/*
https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/MIME_types
 */

/** CLASS **/

export interface IMimeTypeOptions {
  type: string;
  subtype: string;
  parameters?: MimeTypeParameterList | Iterable<[string, string]>;
}

export class MimeTypeClass {
  static parse(
    input: string,
  ): MimeTypeClass {
    const index: number = input.indexOf(';');
    let typeAndSubtype: string;
    let parameters: string;

    if (index === -1) {
      typeAndSubtype = input;
      parameters = '';
    } else {
      typeAndSubtype = input.slice(0, index);
      parameters = input.slice(index + 1);
    }

    TYPE_AND_SUBTYPE_REGEXP.lastIndex = 0;
    const match: RegExpExecArray | null = TYPE_AND_SUBTYPE_REGEXP.exec(typeAndSubtype);

    if (match === null) {
      throw new Error(`Invalid type or subtype`);
    } else {
      return new MimeTypeClass({
        type: match[1],
        subtype: match[2],
        parameters: MimeTypeParameterList.parse(parameters),
      });
    }
  }

  #type!: string;
  #subtype!: string;
  readonly #parameters!: MimeTypeParameterList;

  constructor(
    {
      type,
      subtype,
      parameters = new MimeTypeParameterList(),
    }: IMimeTypeOptions,
  ) {
    this.type = type;
    this.subtype = subtype;
    this.#parameters = (parameters instanceof MimeTypeParameterList)
      ? parameters
      : new MimeTypeParameterList(parameters);
  }

  get type(): string {
    return this.#type;
  }

  set type(
    input: string,
  ) {
    if (TYPE_REGEXP.test(input)) {
      this.#type = input;
    } else {
      throw new Error(`Invalid type`);
    }
  }

  get subtype(): string {
    return this.#subtype;
  }

  set subtype(
    input: string,
  ) {
    if (SUBTYPE_REGEXP.test(input)) {
      this.#subtype = input;
    } else {
      throw new Error(`Invalid subtype`);
    }
  }

  get typeAndSubtype(): string {
    return `${this.#type}/${this.#subtype}`;
  }

  get parameters(): MimeTypeParameterList {
    return this.#parameters;
  }

  toString(
    mode?: IMimeTypeParameterToStringMode,
  ): string {
    const parametersString: string = (this.#parameters.size === 0)
      ? ''
      : `; ${this.#parameters.toString(mode)}`;
    return `${this.typeAndSubtype}${parametersString}`;
  }
}
