import { createEmailHeaderContentTransferEncoding } from '../create-email-header-content-transfer-encoding';

/**
 * @deprecated
 */
export const EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_BASE64_CONSTANT = createEmailHeaderContentTransferEncoding('base64');
