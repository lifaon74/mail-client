import { IMessageIdListToStringFunction } from './message-id-list.to-string.function-definition';

export interface IMessageIdListToStringTrait {
  toString: IMessageIdListToStringFunction;
}
