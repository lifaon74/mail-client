import { IEmailHeaderSubjectToStringFunction } from './email-header-subject.to-string.function-definition';

export interface IEmailHeaderSubjectToStringTrait {
  toString: IEmailHeaderSubjectToStringFunction;
}
