import { IEmailHeaderSenderGetSenderFunction } from './email-header-sender.get-sender.function-definition';

export interface IEmailHeaderSenderGetSenderTrait {
  getSender: IEmailHeaderSenderGetSenderFunction;
}
