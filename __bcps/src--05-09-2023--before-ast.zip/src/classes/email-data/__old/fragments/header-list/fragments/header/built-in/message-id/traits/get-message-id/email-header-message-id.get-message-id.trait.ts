import { IEmailHeaderMessageIdGetMessageIdFunction } from './email-header-message-id.get-message-id.function-definition';

export interface IEmailHeaderMessageIdGetMessageIdTrait {
  getMessageId: IEmailHeaderMessageIdGetMessageIdFunction;
}
