export interface ISMTPDataContentGetHeadersFunction {
  (): string;
}
