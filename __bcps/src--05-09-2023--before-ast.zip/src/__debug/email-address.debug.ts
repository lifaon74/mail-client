import { EmailAddress } from '../classes/email-address/email-address.class';
import { EmailContactName } from '../classes/email-contact/email-contact-name.class';
import { EmailContact } from '../classes/email-contact/email-contact.class';
import { EmailContactList } from '../classes/email-contact/email-contact-list.class';

export function emailAddressDebug(): void {
  // const emailAddress = EmailAddress.parse('a@b.com');
  // const emailAddress = EmailAddress.parse('"John.\\"Doe."@example.com');
  // const emailAddress = EmailAddress.parse('valentin.richard@example.com');
  // console.log(emailAddress);

  // console.log(EmailContact.parse(`"valentin.richard" <valentin.richard@infomaniak.com>`));
  // console.log(EmailContact.parse(`valentin.richard+to2@infomaniak.com`));
  console.log(EmailContactList.parse(`valentin.richard@infomaniak.com, valentin.richard+to2@infomaniak.com, "valentin.richard" <valentin.richard@infomaniak.com>`).toString());
}
