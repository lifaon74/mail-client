export const HTTP_QUOTED_STRING_TOKEN_PATTERN = '[\\u0009\\u0020-\\u007e\\u0080-\\u00ff]';
