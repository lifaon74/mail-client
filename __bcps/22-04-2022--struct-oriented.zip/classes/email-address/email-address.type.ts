import { char_string_t } from '../../helpers/string/char-string.type';
import { IDomain } from '../domain/domain.type';

export interface IEmailAddress {
  readonly localpart: char_string_t;
  readonly domain: IDomain;
}
