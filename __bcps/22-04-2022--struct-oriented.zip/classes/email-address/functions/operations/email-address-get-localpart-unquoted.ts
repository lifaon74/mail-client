import { char_string_t } from '../../../../helpers/string/char-string.type';
import { char_string_from_string } from '../../../../helpers/string/functions/convert/char-string-from-string';
import { char_string_to_string } from '../../../../helpers/string/functions/convert/char-string-to-string';
import { IEmailAddress } from '../../email-address.type';

export function emailAddressGetLocalpartUnquoted(
  {
    localpart,
  }: IEmailAddress,
): char_string_t {
  return char_string_from_string(
    char_string_to_string(localpart)
      .replace(new RegExp('\\\\([^\\x0a\\x0d])', 'g'), '$1')
      .slice(1, -1),
  );
}
