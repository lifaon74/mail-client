import { char_string_t } from '../../../../../helpers/string/char-string.type';
import { char_string_from_string } from '../../../../../helpers/string/functions/convert/char-string-from-string';
import { char_string_concat } from '../../../../../helpers/string/functions/operations/char-string-concat';
import { domainToCharString } from '../../../../domain/funtions/convert/to/domain-to-char-string';
import { IEmailAddress } from '../../../email-address.type';

const SEPARATOR: char_string_t = char_string_from_string('@');

export function emailAddressToCharString(
  {
    localpart,
    domain,
  }: IEmailAddress,
): char_string_t {
  return char_string_concat([
    localpart,
    SEPARATOR,
    domainToCharString(domain),
  ]);
}
