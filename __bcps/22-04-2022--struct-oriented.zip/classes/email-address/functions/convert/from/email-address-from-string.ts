import { char_string_from_string } from '../../../../../helpers/string/functions/convert/char-string-from-string';
import { domainFromString } from '../../../../domain/funtions/convert/from/domain-from-string';
import { IEmailAddress } from '../../../email-address.type';

export function emailAddressFromString(
  input: string,
): IEmailAddress {
  const index: number = input.lastIndexOf('@');

  if (index === -1) {
    throw createInvalidEmailAddressError(`missing @`);
  }

  const localpart: string = input.slice(0, index);
  const domain: string = input.slice(index + 1);

  /* LOCALPART */
  if (
    !LOCAL_PART_REGEXP.test(localpart)
    && !QUOTED_LOCAL_PART_REGEXP.test(localpart)
    && (localpart.length <= 64)
  ) {
    throw createInvalidEmailAddressError(`invalid localpart`);
  }

  return {
    localpart: char_string_from_string(localpart),
    domain: domainFromString(domain),
  };
}

/*--------*/

function createInvalidEmailAddressError(
  message: string,
): Error {
  return new Error(`Invalid email address: ${message}`);
}

const LOCAL_PART_REGEXP: RegExp = new RegExp('^[A-Za-z0-9!#$%&\'*+\\-/=?^_`{|}~.]+$');

// [\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f] === [^\x09-\x0a\x0d\x20\x5c]
const QUOTED_LOCAL_PART_REGEXP: RegExp = new RegExp('^"(?:[^\\x09-\\x0a\\x0d\\x20\\x5c]|\\\\[^\\x0a\\x0d])+"$');
