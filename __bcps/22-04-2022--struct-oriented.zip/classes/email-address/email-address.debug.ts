import { emailAddressFromString } from './functions/convert/from/email-address-from-string';

export function emailAddressDebug(): void {
  // const emailAddress = emailAddressFromString('a@b.com');
  // const emailAddress = emailAddressFromString('"John.\\"Doe."@example.com');
  const emailAddress = emailAddressFromString('valentin.richard@example.com');

  console.log(emailAddress);
}
