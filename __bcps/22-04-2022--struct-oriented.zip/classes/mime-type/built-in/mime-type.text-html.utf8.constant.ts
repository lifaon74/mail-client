import { char_string_from_string } from '../../../helpers/string/functions/convert/char-string-from-string';
import { IMimeType } from '../mime-type.type';

export const MIME_TYPE_TEXT_HTML_UTF8_CONSTANT: IMimeType = {
  type: char_string_from_string('text'),
  subtype: char_string_from_string('html'),
  parameters: [
    {
      key: char_string_from_string('charset'),
      value: char_string_from_string('UTF-8'),
    },
  ],
};
