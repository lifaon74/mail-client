import { char_string_t } from '../../../helpers/string/char-string.type';
import { char_string_from_string } from '../../../helpers/string/functions/convert/char-string-from-string';
import {
  IGenerateBoundaryOptions,
} from '../components/mime-type-parameter-list/components/mime-type-parameter/built-in/boundary/generate-boundary';
import {
  mimeTypeParameterBoundaryGenerate,
} from '../components/mime-type-parameter-list/components/mime-type-parameter/built-in/boundary/mime-type-parameter.boundary.generate';
import {
  IMimeTypeParameterBoundary,
} from '../components/mime-type-parameter-list/components/mime-type-parameter/built-in/boundary/mime-type-parameter.boundary.type';
import { IMimeType } from '../mime-type.type';

export interface IMimeTypeMultipartAlternative extends IMimeType {
  readonly parameters: readonly [IMimeTypeParameterBoundary];
}

const TYPE: char_string_t = char_string_from_string('multipart');
const SUBTYPE: char_string_t = char_string_from_string('alternative');

export function mimeTypeMultipartAlternativeGenerate(
  options?: IGenerateBoundaryOptions,
): IMimeTypeMultipartAlternative {
  return {
    type: TYPE,
    subtype: SUBTYPE,
    parameters: [
      mimeTypeParameterBoundaryGenerate(options),
    ],
  };
}
