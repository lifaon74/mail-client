import { char_string_t } from '../../helpers/string/char-string.type';
import { IMimeTypeParameterList } from './components/mime-type-parameter-list/mime-type-parameter-list.type';

export interface IMimeType {
  readonly type: char_string_t;
  readonly subtype: char_string_t;
  readonly parameters: IMimeTypeParameterList;
}



