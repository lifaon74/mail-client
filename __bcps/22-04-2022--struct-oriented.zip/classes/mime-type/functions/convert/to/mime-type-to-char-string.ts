import { char_string_t } from '../../../../../helpers/string/char-string.type';
import { CHAR_STRING_EMPTY } from '../../../../../helpers/string/constants/char-string.empty.constant';
import { char_string_from_string } from '../../../../../helpers/string/functions/convert/char-string-from-string';
import { char_string_concat } from '../../../../../helpers/string/functions/operations/char-string-concat';
import {
  mimeTypeParameterListToCharString,
} from '../../../components/mime-type-parameter-list/functions/convert/to/mime-type-parameter-list-to-char-string';
import { IMimeType } from '../../../mime-type.type';

const PARAMETERS_CHAR_STRING_SEPARATOR: char_string_t = char_string_from_string('; ');
const TYPE_SUBTYPE_CHAR_STRING_SEPARATOR: char_string_t = char_string_from_string('/');

export function mimeTypeToCharString(
  {
    type,
    subtype,
    parameters,
  }: IMimeType,
): char_string_t {
  const parametersCharString: char_string_t = (parameters.length === 0)
    ? CHAR_STRING_EMPTY
    : char_string_concat([
      PARAMETERS_CHAR_STRING_SEPARATOR,
      mimeTypeParameterListToCharString(parameters),
    ]);

  return char_string_concat([
    type,
    TYPE_SUBTYPE_CHAR_STRING_SEPARATOR,
    subtype,
    parametersCharString,
  ]);
}
