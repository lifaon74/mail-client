import { char_string_from_string } from '../../helpers/string/functions/convert/char-string-from-string';
import { char_string_to_string } from '../../helpers/string/functions/convert/char-string-to-string';
import { mimeTypeToCharString } from './functions/convert/to/mime-type-to-char-string';
import { IMimeType } from './mime-type.type';

export function mimeTypeDebug(): void {
  const data: IMimeType = {
    type: char_string_from_string('multipart'),
    subtype: char_string_from_string('mixed'),
    parameters: [
      {
        key: char_string_from_string('boundary'),
        value: char_string_from_string('"------------20f7c0nUPvZRtniUu0yqxVCY"'),
      },
    ],
  };

  console.log(data);
  console.log(char_string_to_string(mimeTypeToCharString(data)));
}
