import { u32 } from '@lifaon/number-types';
import { char_string_t } from '../../../../../../../../../helpers/string/char-string.type';
import { char_string_length } from '../../../../../../../../../helpers/string/functions/char-string-length';
import { char_string_from_string } from '../../../../../../../../../helpers/string/functions/convert/char-string-from-string';
import { char_string_concat } from '../../../../../../../../../helpers/string/functions/operations/char-string-concat';
import { IMimeTypeParameter } from '../../../mime-type-parameter.type';

const SEPARATOR: char_string_t = char_string_from_string('=');

export function mimeTypeParameterToCharString(
  {
    key,
    value,
  }: IMimeTypeParameter,
): char_string_t {
  const valueLength: u32 = char_string_length(value);

  return (valueLength === 0)
    ? key
    : char_string_concat([
      key,
      SEPARATOR,
      value,
    ]);
}
