import { char_string_t } from '../../../../../../helpers/string/char-string.type';

export type IMimeTypeParameterKey = char_string_t;
export type IMimeTypeParameterValue = char_string_t;

export interface IMimeTypeParameter {
  readonly key: IMimeTypeParameterKey;
  readonly value: IMimeTypeParameterValue;
}

