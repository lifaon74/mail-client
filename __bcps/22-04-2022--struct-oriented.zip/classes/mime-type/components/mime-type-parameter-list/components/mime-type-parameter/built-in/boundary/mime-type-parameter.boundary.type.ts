import { char_string_t } from '../../../../../../../../helpers/string/char-string.type';
import { IMimeTypeParameter } from '../../mime-type-parameter.type';

export interface IMimeTypeParameterBoundary extends IMimeTypeParameter {
  readonly boundary: char_string_t;
}

