import { char_string_t } from '../../../../../../../../helpers/string/char-string.type';
import { char_string_from_string } from '../../../../../../../../helpers/string/functions/convert/char-string-from-string';
import { char_string_concat } from '../../../../../../../../helpers/string/functions/operations/char-string-concat';
import { generateBoundary, IGenerateBoundaryOptions } from './generate-boundary';
import { IMimeTypeParameterBoundary } from './mime-type-parameter.boundary.type';

const MIME_TYPE_PARAMETER_BOUNDARY_KEY: char_string_t = char_string_from_string('boundary');
const BOUNDARY_QUOTE: char_string_t = char_string_from_string('"');

export function mimeTypeParameterBoundaryGenerate(
  options?: IGenerateBoundaryOptions,
): IMimeTypeParameterBoundary {
  const boundary: char_string_t = generateBoundary(options);
  return {
    boundary,
    key: MIME_TYPE_PARAMETER_BOUNDARY_KEY,
    value: char_string_concat([
      BOUNDARY_QUOTE,
      boundary,
      BOUNDARY_QUOTE,
    ]),
  };
}
