import { IMimeTypeParameter } from './components/mime-type-parameter/mime-type-parameter.type';

export type IMimeTypeParameterList = readonly IMimeTypeParameter[];


