import { char_string_t } from '../../../../../../../helpers/string/char-string.type';
import { char_string_from_string } from '../../../../../../../helpers/string/functions/convert/char-string-from-string';
import { char_string_join } from '../../../../../../../helpers/string/functions/operations/char-string-join';
import {
  mimeTypeParameterToCharString,
} from '../../../components/mime-type-parameter/functions/convert/to/mime-type-parameter-to-char-string';
import { IMimeTypeParameterList } from '../../../mime-type-parameter-list.type';

const SEPARATOR: char_string_t = char_string_from_string('; ');

export function mimeTypeParameterListToCharString(
  parameters: IMimeTypeParameterList,
): char_string_t {
  return char_string_join(
    parameters.map(mimeTypeParameterToCharString),
    SEPARATOR,
  );
}
