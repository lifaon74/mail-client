import { char_string_t } from '../../helpers/string/char-string.type';

// export interface IDomain {
//   readonly value: char_string_t;
// }

export type IDomain = char_string_t;


