import { char_string_t } from '../../../../../helpers/string/char-string.type';
import { char_string_to_string } from '../../../../../helpers/string/functions/convert/char-string-to-string';
import { IDomain } from '../../../domain.type';
import { domainFromString } from './domain-from-string';

export function domainFromCharString(
  input: char_string_t,
): IDomain {
  return domainFromString(char_string_to_string(input));
}
