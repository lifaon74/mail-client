import { char_string_from_string } from '../../../../../helpers/string/functions/convert/char-string-from-string';
import { IDomain } from '../../../domain.type';

export function domainFromString(
  input: string,
): IDomain {
  try {
    const url: URL = new URL(`https://${input}`);
    if (input === url.hostname) {
      return char_string_from_string(input);
    } else {
      throw null;
    }
  } catch {
    throw new Error(`Invalid domain`);
  }
}
