import { char_string_t } from '../../../../../helpers/string/char-string.type';
import { IDomain } from '../../../domain.type';

export function domainToCharString(
  domain: IDomain,
): char_string_t {
  return domain;
}

