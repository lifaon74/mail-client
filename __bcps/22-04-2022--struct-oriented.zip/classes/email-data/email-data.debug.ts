import { char_string_from_string } from '../../helpers/string/functions/convert/char-string-from-string';
import { char_string_to_string } from '../../helpers/string/functions/convert/char-string-to-string';
import {
  emailDataMultipartAlternativeFromTextAndHTML
} from './built-in/multipart-alternative/email-data.multipart-alternative.from-text-and-html';
import {
  emailHeaderContentTypeMultipartAlternativeGenerate,
} from './components/header-list/components/header/built-in/content-type/built-in/email-header.content-type.multipart-alternative.generate';
import {
  EMAIL_HEADER_CONTENT_TYPE_TEXT_PLAIN_UTF8_CONSTANT,
} from './components/header-list/components/header/built-in/content-type/built-in/email-header.content-type.text-plain.utf8.constant';
import { emailHeaderDateCreate } from './components/header-list/components/header/built-in/date/email-header.date.create';
import { IEmailData } from './email-data.type';
import { emailDataToCharString } from './functions/convert/to/email-data-to-char-string';

export function emailDataDebug(): void {
  // const emailData: IEmailData = {
  //   headers: [
  //     emailHeaderDateCreate(new Date()),
  //     EMAIL_HEADER_CONTENT_TYPE_TEXT_PLAIN_UTF8_CONSTANT,
  //     emailHeaderContentTypeMultipartAlternativeGenerate(),
  //   ],
  //   body: char_string_from_string('abc'),
  // };

  // mimeTypeParameterBoundaryGenerate
  // const emailData: IEmailData = emailDataTextPlainFromString('abc');

  const emailData: IEmailData = emailDataMultipartAlternativeFromTextAndHTML({
    text: 'text',
    html: 'html',
  });

  // TODO continue here

  console.log(emailData);
  console.log(char_string_to_string(emailDataToCharString(emailData)));
}
