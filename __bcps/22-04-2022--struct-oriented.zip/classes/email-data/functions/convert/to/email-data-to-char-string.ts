import { char_string_t } from '../../../../../helpers/string/char-string.type';
import { char_string_from_string } from '../../../../../helpers/string/functions/convert/char-string-from-string';
import { char_string_concat } from '../../../../../helpers/string/functions/operations/char-string-concat';
import { emailBodyToCharString } from '../../../components/body/functions/convert/to/email-body-to-char-string';
import { emailHeaderListToCharString } from '../../../components/header-list/functions/convert/to/email-header-list-to-char-string';
import { IEmailData } from '../../../email-data.type';

const SEPARATOR: char_string_t = char_string_from_string('\r\n\r\n');

export function emailDataToCharString(
  {
    headers,
    body,
  }: IEmailData,
): char_string_t {
  return char_string_concat([
    emailHeaderListToCharString(headers),
    SEPARATOR,
    emailBodyToCharString(body),
  ]);
}
