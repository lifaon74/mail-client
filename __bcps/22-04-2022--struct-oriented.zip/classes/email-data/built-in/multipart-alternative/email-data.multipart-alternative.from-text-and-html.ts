import { emailDataTextHTMLFromString } from '../text-html/email-data.text-html.from-string';
import { emailDataTextPlainFromString } from '../text-plain/email-data.text-plain.from-string';
import { emailDataMultipartAlternativeFromContent } from './email-data.multipart-alternative.from-content';
import { IEmailDataMultipartAlternative } from './email-data.multipart-alternative.type';

export interface IEmailDataMultipartAlternativeFromTextAndHTML {
  text: string;
  html: string;
}

export function emailDataMultipartAlternativeFromTextAndHTML(
  {
    text,
    html,
  }: IEmailDataMultipartAlternativeFromTextAndHTML,
): IEmailDataMultipartAlternative {
  return emailDataMultipartAlternativeFromContent([
    emailDataTextPlainFromString(text),
    emailDataTextHTMLFromString(html),
  ]);
}

