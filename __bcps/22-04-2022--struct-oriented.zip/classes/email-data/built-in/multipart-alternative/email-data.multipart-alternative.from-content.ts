import { char_string_t } from '../../../../helpers/string/char-string.type';
import { char_string_from_string } from '../../../../helpers/string/functions/convert/char-string-from-string';
import { IEmailBody } from '../../components/body/email-body.type';
import {
  emailHeaderContentTypeMultipartAlternativeGenerate,
  IEmailHeaderContentTypeMultipartAlternative,
} from '../../components/header-list/components/header/built-in/content-type/built-in/email-header.content-type.multipart-alternative.generate';
import { IEmailDataMultipartAlternative, IEmailDataMultipartAlternativeContent } from './email-data.multipart-alternative.type';

export function emailDataMultipartAlternativeFromContent(
  content: IEmailDataMultipartAlternativeContent,
): IEmailDataMultipartAlternative {
  const header: IEmailHeaderContentTypeMultipartAlternative = emailHeaderContentTypeMultipartAlternativeGenerate();
  const boundary: char_string_t = header.mimeType.parameters[0].boundary;

  return {
    content,
    headers: [
      header,
    ],
    get body(): IEmailBody {
      return char_string_from_string('abc');
    },
  };
}

