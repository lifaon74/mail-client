import { IEmailData } from '../../email-data.type';

export type IEmailDataMultipartAlternativeContent = readonly IEmailData[];

export interface IEmailDataMultipartAlternative extends IEmailData {
  readonly content: IEmailDataMultipartAlternativeContent;
}

