import { stringToUTF8EncodedStringBuffer } from '@lirx/core';
import { IEmailBody } from '../../components/body/email-body.type';
import { emailBodyFromUint8ArrayAsBase64 } from '../../components/body/functions/convert/from/email-body-from-uint8-array-as-base64';
import {
  EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_BASE64_CONSTANT,
} from '../../components/header-list/components/header/built-in/content-transfer-encoding/built-in/email-header.content-transfer-encoding.base64.constant';
import {
  EMAIL_HEADER_CONTENT_TYPE_TEXT_HTML_UTF8_CONSTANT,
} from '../../components/header-list/components/header/built-in/content-type/built-in/email-header.content-type.text-html.utf8.constant';
import { IEmailDataTextHTML } from './email-data.text-html.type';

export function emailDataTextHTMLFromString(
  html: string,
): IEmailDataTextHTML {
  return {
    html,
    headers: [
      EMAIL_HEADER_CONTENT_TYPE_TEXT_HTML_UTF8_CONSTANT,
      EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_BASE64_CONSTANT,
    ],
    get body(): IEmailBody {
      return emailBodyFromUint8ArrayAsBase64(stringToUTF8EncodedStringBuffer(html));
    },
  };
}
