import { IEmailData } from '../../email-data.type';

export interface IEmailDataTextHTML extends IEmailData {
  readonly html: string;
}

