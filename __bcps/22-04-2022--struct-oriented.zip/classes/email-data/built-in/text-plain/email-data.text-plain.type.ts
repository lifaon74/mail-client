import { IEmailData } from '../../email-data.type';

export interface IEmailDataTextPlain extends IEmailData {
  readonly text: string;
}

