import { stringToUTF8EncodedStringBuffer } from '@lirx/core';
import { IEmailBody } from '../../components/body/email-body.type';
import { emailBodyFromUint8ArrayAsBase64 } from '../../components/body/functions/convert/from/email-body-from-uint8-array-as-base64';
import {
  EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_BASE64_CONSTANT,
} from '../../components/header-list/components/header/built-in/content-transfer-encoding/built-in/email-header.content-transfer-encoding.base64.constant';
import {
  EMAIL_HEADER_CONTENT_TYPE_TEXT_PLAIN_UTF8_CONSTANT,
} from '../../components/header-list/components/header/built-in/content-type/built-in/email-header.content-type.text-plain.utf8.constant';
import { IEmailDataTextPlain } from './email-data.text-plain.type';

export function emailDataTextPlainFromString(
  text: string,
): IEmailDataTextPlain {
  return {
    text,
    headers: [
      EMAIL_HEADER_CONTENT_TYPE_TEXT_PLAIN_UTF8_CONSTANT,
      EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_BASE64_CONSTANT,
    ],
    get body(): IEmailBody {
      return emailBodyFromUint8ArrayAsBase64(stringToUTF8EncodedStringBuffer(text));
    },
  };
}
