import { char_string_t } from '../../../../helpers/string/char-string.type';

export type IEmailBody = char_string_t;

