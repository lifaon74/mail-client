import { char_string_t } from '../../../../../../../helpers/string/char-string.type';
import { IEmailBody } from '../../../email-body.type';

export function emailBodyToCharString(
  body: IEmailBody,
): char_string_t {
  return body;
}
