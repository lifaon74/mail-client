import { u32 } from '../../../../../../../../../number-types/dist';
import { encodeUint8ArrayToBase64 } from '../../../../../../../helpers/base64/encode-uint8-array-to-base64';
import { char_string_t } from '../../../../../../../helpers/string/char-string.type';
import { char_string_length } from '../../../../../../../helpers/string/functions/char-string-length';
import { char_string_new } from '../../../../../../../helpers/string/functions/char-string-new';
import { char_string_from_string } from '../../../../../../../helpers/string/functions/convert/char-string-from-string';
import { char_string_set } from '../../../../../../../helpers/string/functions/operations/char-string-set';
import { char_string_shallow_slice } from '../../../../../../../helpers/string/functions/operations/char-string-shallow-slice';
import { IEmailBody } from '../../../email-body.type';

const SPLIT_SIZE = 76;

const SEPARATOR: char_string_t = char_string_from_string('\r\n');

export function emailBodyFromUint8ArrayAsBase64(
  data: Uint8Array,
): IEmailBody {
  const dataBase64: char_string_t = encodeUint8ArrayToBase64(data);

  const linesCount: u32 = Math.ceil(char_string_length(dataBase64) / SPLIT_SIZE);
  const dataBase64Length: u32 = char_string_length(dataBase64);
  const separatorLength: u32 = char_string_length(SEPARATOR);
  const outputLength: u32 = dataBase64Length
  + (separatorLength * Math.max(0, linesCount - 1));

  const output: char_string_t = char_string_new(outputLength);

  let dataBase64Index: u32 = 0;
  let outputIndex: u32 = 0;

  while ((dataBase64.length - dataBase64Index) > SPLIT_SIZE) {
    char_string_set(output, char_string_shallow_slice(dataBase64, dataBase64Index, dataBase64Index + SPLIT_SIZE), outputIndex);
    outputIndex += SPLIT_SIZE;
    dataBase64Index += SPLIT_SIZE;

    char_string_set(output, SEPARATOR, outputIndex);
    outputIndex += 2;
  }

  char_string_set(output, char_string_shallow_slice(dataBase64, dataBase64Index), outputIndex);

  return output;
}
