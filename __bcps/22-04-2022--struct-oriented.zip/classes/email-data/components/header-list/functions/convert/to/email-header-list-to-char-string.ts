import { char_string_t } from '../../../../../../../helpers/string/char-string.type';
import { char_string_from_string } from '../../../../../../../helpers/string/functions/convert/char-string-from-string';
import { char_string_join } from '../../../../../../../helpers/string/functions/operations/char-string-join';
import { emailHeaderToCharString } from '../../../components/header/functions/convert/to/email-header-to-char-string';
import { IEmailHeaderList } from '../../../email-header-list.type';

const SEPARATOR: char_string_t = char_string_from_string('\r\n');

export function emailHeaderListToCharString(
  headers: IEmailHeaderList,
): char_string_t {
  return char_string_join(
    headers.map(emailHeaderToCharString),
    SEPARATOR,
  );
}
