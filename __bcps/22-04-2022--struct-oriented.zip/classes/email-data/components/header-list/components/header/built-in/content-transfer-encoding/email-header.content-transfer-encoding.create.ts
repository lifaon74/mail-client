import { char_string_from_string } from '../../../../../../../../helpers/string/functions/convert/char-string-from-string';
import { IEmailHeaderKey, IEmailHeaderValue } from '../../email-header.type';
import { IContentTransferEncoding, IEmailHeaderContentTransferEncoding } from './email-header.content-transfer-encoding.type';

const EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_KEY: IEmailHeaderKey = char_string_from_string('Content-Transfer-Encoding');

export function emailHeaderContentTransferEncodingCreate(
  contentTransferEncoding: IContentTransferEncoding,
): IEmailHeaderContentTransferEncoding {
  return {
    contentTransferEncoding,
    key: EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_KEY,
    get value(): IEmailHeaderValue {
      return contentTransferEncoding;
    },
  };
}
