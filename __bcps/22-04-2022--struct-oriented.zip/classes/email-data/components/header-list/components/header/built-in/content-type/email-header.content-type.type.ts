import { IMimeType } from '../../../../../../../mime-type/mime-type.type';
import { IEmailHeader } from '../../email-header.type';

export interface IEmailHeaderContentType extends IEmailHeader {
  readonly mimeType: IMimeType;
}
