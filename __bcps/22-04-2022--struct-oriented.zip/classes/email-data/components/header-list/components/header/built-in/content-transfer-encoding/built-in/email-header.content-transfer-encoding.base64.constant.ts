import { char_string_from_string } from '../../../../../../../../../helpers/string/functions/convert/char-string-from-string';
import { emailHeaderContentTransferEncodingCreate } from '../email-header.content-transfer-encoding.create';

export const EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_BASE64_CONSTANT = emailHeaderContentTransferEncodingCreate(char_string_from_string('base64'));
