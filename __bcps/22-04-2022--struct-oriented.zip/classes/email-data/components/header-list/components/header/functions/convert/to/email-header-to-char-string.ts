import { char_string_t } from '../../../../../../../../../helpers/string/char-string.type';
import { char_string_from_string } from '../../../../../../../../../helpers/string/functions/convert/char-string-from-string';
import { char_string_concat } from '../../../../../../../../../helpers/string/functions/operations/char-string-concat';
import { IEmailHeader } from '../../../email-header.type';

const SEPARATOR: char_string_t = char_string_from_string(': ');

export function emailHeaderToCharString(
  {
    key,
    value,
  }: IEmailHeader,
): char_string_t {
  return char_string_concat([
    key,
    SEPARATOR,
    value,
  ]);
}
