import { char_string_from_string } from '../../../../../../../../helpers/string/functions/convert/char-string-from-string';
import { mimeTypeToCharString } from '../../../../../../../mime-type/functions/convert/to/mime-type-to-char-string';
import { IMimeType } from '../../../../../../../mime-type/mime-type.type';
import { IEmailHeaderKey, IEmailHeaderValue } from '../../email-header.type';
import { IEmailHeaderContentType } from './email-header.content-type.type';

const EMAIL_HEADER_CONTENT_TYPE_KEY: IEmailHeaderKey = char_string_from_string('Content-Type');

export function emailHeaderContentTypeFromMimeType(
  mimeType: IMimeType,
): IEmailHeaderContentType {
  return {
    mimeType,
    key: EMAIL_HEADER_CONTENT_TYPE_KEY,
    get value(): IEmailHeaderValue {
      return mimeTypeToCharString(mimeType);
    },
  };
}
