import { char_string_t } from '../../../../../../helpers/string/char-string.type';

export type IEmailHeaderKey = char_string_t;
export type IEmailHeaderValue = char_string_t;

export interface IEmailHeader {
  readonly key: IEmailHeaderKey;
  readonly value: IEmailHeaderValue;
}

