import { char_string_from_string } from '../../../../../../../../helpers/string/functions/convert/char-string-from-string';
import { IEmailHeaderKey, IEmailHeaderValue } from '../../email-header.type';
import { IEmailHeaderDate } from './email-header.date.type';

const EMAIL_HEADER_DATE_KEY: IEmailHeaderKey = char_string_from_string('Date');

export function emailHeaderDateCreate(
  date: Date,
): IEmailHeaderDate {
  return {
    date,
    key: EMAIL_HEADER_DATE_KEY,
    get value(): IEmailHeaderValue {
      return char_string_from_string(date.toISOString());
    },
  };
}
