import { IEmailHeader } from '../../email-header.type';

export interface IEmailHeaderDate extends IEmailHeader {
  readonly date: Date;
}

