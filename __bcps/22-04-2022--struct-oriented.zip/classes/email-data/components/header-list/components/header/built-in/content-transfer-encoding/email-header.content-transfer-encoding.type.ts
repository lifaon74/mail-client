import { char_string_t } from '../../../../../../../../helpers/string/char-string.type';
import { IEmailHeader } from '../../email-header.type';

export type IClassicContentTransferEncoding =
  | '7bit'
  | '8bit'
  | 'binary'
  | 'quoted-printable'
  | 'base64'
  ;

export type IContentTransferEncoding = char_string_t;

export interface IEmailHeaderContentTransferEncoding extends IEmailHeader {
  readonly contentTransferEncoding: IContentTransferEncoding;
}
