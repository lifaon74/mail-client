import {
  IMimeTypeMultipartAlternative,
  mimeTypeMultipartAlternativeGenerate,
} from '../../../../../../../../mime-type/built-in/mime-type.multipart-alternative.generate';
import {
  IGenerateBoundaryOptions,
} from '../../../../../../../../mime-type/components/mime-type-parameter-list/components/mime-type-parameter/built-in/boundary/generate-boundary';
import { emailHeaderContentTypeFromMimeType } from '../email-header.content-type.from-mime-type';
import { IEmailHeaderContentType } from '../email-header.content-type.type';

export interface IEmailHeaderContentTypeMultipartAlternative extends IEmailHeaderContentType {
  readonly mimeType: IMimeTypeMultipartAlternative;
}

export function emailHeaderContentTypeMultipartAlternativeGenerate(
  options?: IGenerateBoundaryOptions,
): IEmailHeaderContentTypeMultipartAlternative {
  return emailHeaderContentTypeFromMimeType(mimeTypeMultipartAlternativeGenerate(options)) as IEmailHeaderContentTypeMultipartAlternative;
}
