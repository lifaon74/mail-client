import { IEmailBody } from './components/body/email-body.type';
import { IEmailHeaderList } from './components/header-list/email-header-list.type';

export interface IEmailData {
  readonly headers: IEmailHeaderList;
  readonly body: IEmailBody;
}

