import { char_string_t } from '../char-string.type';
import { char_string_new } from '../functions/char-string-new';

export const CHAR_STRING_EMPTY: char_string_t = char_string_new(0);
