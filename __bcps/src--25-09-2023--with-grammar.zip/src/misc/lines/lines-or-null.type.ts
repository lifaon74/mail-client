import { ILines } from './lines.type';

export type ILinesOrNull = ILines | null;
