

export const SMTP_CONFIG = {
  hostname: "mail.infomaniak.com",
  port: 465,
  username: "valentin.richard@infomaniak.com",
  password: "Pa$$W0rd_[infomaniak]",
};

