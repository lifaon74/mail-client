import { ISMTPDataContentHeaderGetKeyFunction } from './smtp-data-content-header.get-key.function-definition';

export interface ISMTPDataContentHeaderGetKeyTrait {
  getKey: ISMTPDataContentHeaderGetKeyFunction;
}
