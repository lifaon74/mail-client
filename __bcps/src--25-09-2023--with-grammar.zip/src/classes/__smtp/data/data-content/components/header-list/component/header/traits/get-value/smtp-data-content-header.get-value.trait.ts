import { ISMTPDataContentHeaderGetValueFunction } from './smtp-data-content-header.get-value.function-definition';

export interface ISMTPDataContentHeaderGetValueTrait {
  getValue: ISMTPDataContentHeaderGetValueFunction;
}
