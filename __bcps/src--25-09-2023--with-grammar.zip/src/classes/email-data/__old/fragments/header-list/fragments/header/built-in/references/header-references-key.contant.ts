export const HEADER_REFERENCES_KEY_NAME = 'References';
