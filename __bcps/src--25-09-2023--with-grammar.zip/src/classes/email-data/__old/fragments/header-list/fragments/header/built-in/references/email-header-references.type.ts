import { IEmailHeaderMessageIdList } from '../shared/message-id/email-header-message-id-list/email-header-message-id-list.type';

export interface IEmailHeaderReferences extends IEmailHeaderMessageIdList {
}
