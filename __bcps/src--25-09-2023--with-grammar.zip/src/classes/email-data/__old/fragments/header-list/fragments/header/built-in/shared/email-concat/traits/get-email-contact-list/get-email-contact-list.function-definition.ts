import { IEmailContactList } from '../../email-contact-list/email-contact-list.type';

export interface IGetEmailContactListFunction {
  (): IEmailContactList;
}
