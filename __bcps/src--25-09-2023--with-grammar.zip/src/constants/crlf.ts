export const CRLF: string = '\r\n';
export const CRLF_LENGTH: number = CRLF.length;
