import {
  IGrammarByteComparisonGreaterThanOrEqualsAstNode
} from '../../../grammar-byte-sequence-comparison/comparisons/greater-than-or-equals/grammar-byte-comparison-greater-than-or-equals-ast-node.type';

export function optimizeGrammarByteComparisonGreaterThanOrEquals(
  node: IGrammarByteComparisonGreaterThanOrEqualsAstNode,
): IGrammarByteComparisonGreaterThanOrEqualsAstNode {
  return node;
}
