import { GrammarEndAstNodeType, IGrammarEndAstNode } from './grammar-end-ast-node.type';

export const GrammarEnd: IGrammarEndAstNode = {
  __type__: GrammarEndAstNodeType,
};

