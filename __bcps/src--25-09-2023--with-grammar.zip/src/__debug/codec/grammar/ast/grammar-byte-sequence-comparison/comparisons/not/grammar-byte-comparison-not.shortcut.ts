import { GrammarByteComparisonNot } from './grammar-byte-comparison-not';

export const not = GrammarByteComparisonNot;

