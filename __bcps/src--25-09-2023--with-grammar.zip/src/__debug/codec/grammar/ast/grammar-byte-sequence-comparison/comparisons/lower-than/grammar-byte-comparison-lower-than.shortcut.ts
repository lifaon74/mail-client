import { GrammarByteComparisonLowerThan } from './grammar-byte-comparison-lower-than';

export const lt = GrammarByteComparisonLowerThan;

