import { GrammarByteComparisonNotOr } from './grammar-byte-comparison-not-or';

export const nor = GrammarByteComparisonNotOr;

