import { IUint8ArrayParser } from './uint8-array-parser.type';

export type IUint8ArrayParserRules = Map<string, IUint8ArrayParser>;
