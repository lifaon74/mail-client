import { AstNode } from '../../../../../ast/__shared__/ast-node.type';
import { isAstNode } from '../../../../../ast/__shared__/is-ast-node';

export const GrammarOptimizedByteAstNodeType = 'GrammarOptimizedByte';

export type IGrammarOptimizedByteAstNodeType = typeof GrammarOptimizedByteAstNodeType;

export interface IGrammarOptimizedByteAstNode extends AstNode<IGrammarOptimizedByteAstNodeType> {
  readonly value: number;
}

export function isGrammarOptimizedByteAstNode(
  input: object,
): input is IGrammarOptimizedByteAstNode {
  return isAstNode<IGrammarOptimizedByteAstNodeType>(input, GrammarOptimizedByteAstNodeType);
}

