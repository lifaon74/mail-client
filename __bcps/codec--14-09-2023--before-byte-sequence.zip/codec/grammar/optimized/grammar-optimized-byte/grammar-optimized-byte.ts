import { IGrammarOptimizedByteAstNode, GrammarOptimizedByteAstNodeType } from './grammar-optimized-byte-ast-node.type';

export function GrammarOptimizedByte(
  value: number,
): IGrammarOptimizedByteAstNode {
  return {
    __type__: GrammarOptimizedByteAstNodeType,
    value,
  };
}
