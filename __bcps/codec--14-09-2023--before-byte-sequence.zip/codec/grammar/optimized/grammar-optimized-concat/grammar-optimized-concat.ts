import { IGrammarOptimizedConcatAstNode, GrammarOptimizedConcatAstNodeType } from './grammar-optimized-concat-ast-node.type';
import { IGrammarOptimizedExpressionAstNode } from '../grammar-optimized-expression/grammar-optimized-expression-ast-node.type';

export function GrammarOptimizedConcat(
  expressions: readonly IGrammarOptimizedExpressionAstNode[],
): IGrammarOptimizedConcatAstNode {
  return {
    __type__: GrammarOptimizedConcatAstNodeType,
    expressions,
  };
}
