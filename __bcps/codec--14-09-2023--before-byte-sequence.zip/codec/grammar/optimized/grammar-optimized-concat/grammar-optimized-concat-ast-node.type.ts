
import { IGrammarOptimizedExpressionAstNode } from '../grammar-optimized-expression/grammar-optimized-expression-ast-node.type';
import { AstNode } from '../../../../../ast/__shared__/ast-node.type';
import { isAstNode } from '../../../../../ast/__shared__/is-ast-node';

export const GrammarOptimizedConcatAstNodeType = 'GrammarOptimizedConcat';

export type IGrammarOptimizedConcatAstNodeType = typeof GrammarOptimizedConcatAstNodeType;

export interface IGrammarOptimizedConcatAstNode extends AstNode<IGrammarOptimizedConcatAstNodeType> {
  readonly expressions: readonly IGrammarOptimizedExpressionAstNode[];
}

export function isGrammarOptimizedConcatAstNode(
  input: object,
): input is IGrammarOptimizedConcatAstNode {
  return isAstNode<IGrammarOptimizedConcatAstNodeType>(input, GrammarOptimizedConcatAstNodeType);
}

