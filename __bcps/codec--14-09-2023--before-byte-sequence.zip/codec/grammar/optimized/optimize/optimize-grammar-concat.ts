import { IGrammarConcatAstNode } from '../../grammar-concat/grammar-concat-ast-node.type';
import { IGrammarExpressionAstNode } from '../../grammar-expression/grammar-expression-ast-node.type';
import { isGrammarByteAstNode } from '../../grammar-byte-sequence/grammar-byte-sequence-ast-node.type';

export function optimizeGrammarConcat(
  {
    expressions,
  }: IGrammarConcatAstNode,
) {
  const optimizedExpressions
  for (let i = 0, l = expressions.length; i < l; i++) {
    const expression: IGrammarExpressionAstNode = expressions[i];

    if (isGrammarByteAstNode(expression)) {
      const sequence: number[] = [];
      for (l = expressions.length; i < l; i++) {
        const expression: IGrammarExpressionAstNode = expressions[i];

        if (isGrammarByteAstNode(expression)) {
          sequence.push(expression.value);
        } else {
          break;
        }
      }


    }
  }
}
