import { AstNode } from '../../../../../ast/__shared__/ast-node.type';
import { isAstNode } from '../../../../../ast/__shared__/is-ast-node';
import { IGrammarOptimizedExpressionAstNode } from '../grammar-optimized-expression/grammar-optimized-expression-ast-node.type';

export const GrammarOptimizedAstNodeType = 'GrammarOptimized';

export type IGrammarOptimizedAstNodeType = typeof GrammarOptimizedAstNodeType;

export interface IGrammarOptimizedAstNode extends AstNode<IGrammarOptimizedAstNodeType> {
  readonly expressions: readonly IGrammarOptimizedExpressionAstNode[];
}

export function isGrammarOptimizedAstNode(
  input: object,
): input is IGrammarOptimizedAstNode {
  return isAstNode<IGrammarOptimizedAstNodeType>(input, GrammarOptimizedAstNodeType);
}

