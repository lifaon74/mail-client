import {
  IGrammarOptimizedByteSequenceAstNode,
  GrammarOptimizedByteSequenceAstNodeType,
} from './grammar-optimized-byte-sequence-ast-node.type';

export function GrammarOptimizedByteSequence(
  sequence: Uint8Array,
): IGrammarOptimizedByteSequenceAstNode {
  return {
    __type__: GrammarOptimizedByteSequenceAstNodeType,
    sequence,
  };
}
