import {
  isGrammarOptimizedByteAstNode,
  IGrammarOptimizedByteAstNode,
} from '../grammar-optimized-byte/grammar-optimized-byte-ast-node.type';
import {
  IGrammarOptimizedByteSequenceAstNode,
  isGrammarOptimizedByteSequenceAstNode,
} from '../grammar-optimized-byte-sequence/grammar-optimized-byte-sequence-ast-node.type';
import {
  IGrammarOptimizedConcatAstNode,
  isGrammarOptimizedConcatAstNode,
} from '../grammar-optimized-concat/grammar-optimized-concat-ast-node.type';

export type IGrammarOptimizedExpressionAstNode =
  // | IGrammarOptimizedAlternativeAstNode
  | IGrammarOptimizedByteAstNode
  | IGrammarOptimizedByteSequenceAstNode
  | IGrammarOptimizedConcatAstNode
  // | IGrammarOptimizedEmptyAstNode
  // | IGrammarOptimizedRuleIdentifierAstNode
  ;

export function isGrammarOptimizedExpressionAstNode(
  input: object,
): input is IGrammarOptimizedExpressionAstNode {
  return /*isGrammarOptimizedAlternativeAstNode(input)*/ true
    || isGrammarOptimizedByteAstNode(input)
    || isGrammarOptimizedByteSequenceAstNode(input)
    || isGrammarOptimizedConcatAstNode(input)
    // || isGrammarOptimizedEmptyAstNode(input)
    // || isGrammarOptimizedRuleIdentifierAstNode(input)
    ;
}

