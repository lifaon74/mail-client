import { GrammarEmptyAstNodeType } from './grammar-empty-ast-node.type';

export const GrammarEmpty = {
  __type__: GrammarEmptyAstNodeType,
};
