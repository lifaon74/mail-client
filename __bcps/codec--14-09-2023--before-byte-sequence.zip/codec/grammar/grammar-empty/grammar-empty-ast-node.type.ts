import { AstNode } from '../../../../ast/__shared__/ast-node.type';
import { isAstNode } from '../../../../ast/__shared__/is-ast-node';

export const GrammarEmptyAstNodeType = 'GrammarEmpty';

export type IGrammarEmptyAstNodeType = typeof GrammarEmptyAstNodeType;

export interface IGrammarEmptyAstNode extends AstNode<IGrammarEmptyAstNodeType> {
}

export function isGrammarEmptyAstNode(
  input: object,
): input is IGrammarEmptyAstNode {
  return isAstNode<IGrammarEmptyAstNodeType>(input, GrammarEmptyAstNodeType);
}

