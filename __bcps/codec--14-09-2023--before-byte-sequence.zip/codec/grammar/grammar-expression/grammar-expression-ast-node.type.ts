import { IGrammarAlternativeAstNode, isGrammarAlternativeAstNode } from '../grammar-alternative/grammar-alternative-ast-node.type';
import { IGrammarByteAstNode, isGrammarByteAstNode } from '../grammar-byte-sequence/grammar-byte-sequence-ast-node.type';
import { IGrammarConcatAstNode, isGrammarConcatAstNode } from '../grammar-concat/grammar-concat-ast-node.type';
import {
  IGrammarRuleIdentifierAstNode,
  isGrammarRuleIdentifierAstNode,
} from '../grammar-rule-identifier/grammar-rule-identifier-ast-node.type';
import { IGrammarEmptyAstNode, isGrammarEmptyAstNode } from '../grammar-empty/grammar-empty-ast-node.type';

export type IGrammarExpressionAstNode =
  | IGrammarAlternativeAstNode
  | IGrammarByteAstNode
  | IGrammarConcatAstNode
  | IGrammarEmptyAstNode
  | IGrammarRuleIdentifierAstNode
  ;

export function isGrammarExpressionAstNode(
  input: object,
): input is IGrammarExpressionAstNode {
  return isGrammarAlternativeAstNode(input)
    || isGrammarByteAstNode(input)
    || isGrammarConcatAstNode(input)
    || isGrammarEmptyAstNode(input)
    || isGrammarRuleIdentifierAstNode(input)
    ;
}

