import { IGrammarByteAstNode, GrammarByteAstNodeType } from './grammar-byte-sequence-ast-node.type';

export function GrammarByte(
  value: number,
): IGrammarByteAstNode {
  return {
    __type__: GrammarByteAstNodeType,
    value,
  };
}
