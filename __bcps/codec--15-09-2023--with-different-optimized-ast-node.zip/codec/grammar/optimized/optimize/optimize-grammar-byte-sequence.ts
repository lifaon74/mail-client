import { IGrammarOptimizedExpressionAstNode } from '../grammar-optimized-expression/grammar-optimized-expression-ast-node.type';
import { IGrammarByteSequenceAstNode } from '../../grammar-byte-sequence/grammar-byte-sequence-ast-node.type';
import { GrammarOptimizedByteSequence } from '../grammar-optimized-byte-sequence/grammar-optimized-byte-sequence';

export function optimizeGrammarByteSequence(
  {
    bytes,
  }: IGrammarByteSequenceAstNode,
): IGrammarOptimizedExpressionAstNode {
  return GrammarOptimizedByteSequence(bytes);
}
