import { IGrammarConcatAstNode } from '../../grammar-concat/grammar-concat-ast-node.type';
import { IGrammarOptimizedExpressionAstNode } from '../grammar-optimized-expression/grammar-optimized-expression-ast-node.type';
import { GrammarOptimizedByteSequence } from '../grammar-optimized-byte-sequence/grammar-optimized-byte-sequence';
import { optimizeGrammarExpression } from './optimize-grammar-expression';
import { GrammarOptimizedConcat } from '../grammar-optimized-concat/grammar-optimized-concat';
import { isGrammarOptimizedByteSequenceAstNode } from '../grammar-optimized-byte-sequence/grammar-optimized-byte-sequence-ast-node.type';
import { GrammarOptimizedEmpty } from '../grammar-optimized-byte-sequence/grammar-optimized-empty';

export function optimizeGrammarConcat(
  {
    expressions,
  }: IGrammarConcatAstNode,
): IGrammarOptimizedExpressionAstNode {

  const optimizedExpressions: IGrammarOptimizedExpressionAstNode[] = [];
  let byteSequence: number[] | undefined = void 0;

  const appendByteSequence = (): void => {
    if (byteSequence !== void 0) {
      optimizedExpressions.push(
        GrammarOptimizedByteSequence(
          new Uint8Array(byteSequence),
        ),
      );
      byteSequence = void 0;
    }
  };

  for (let i: number = 0, l = expressions.length; i < l; i++) {
    const expression: IGrammarOptimizedExpressionAstNode = optimizeGrammarExpression(expressions[i]);

    if (isGrammarOptimizedByteSequenceAstNode(expression)) {
      if (byteSequence === void 0) {
        byteSequence = [...expression.bytes];
      } else {
        byteSequence.push(...expression.bytes);
      }
    } else {
      appendByteSequence();
    }
  }

  appendByteSequence();

  if (optimizedExpressions.length === 0) {
    return GrammarOptimizedEmpty;
  } else if (optimizedExpressions.length === 1) {
    return optimizedExpressions[0];
  } else {
    return GrammarOptimizedConcat(optimizedExpressions);
  }
}
