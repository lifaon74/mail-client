import { isGrammarConcatAstNode } from '../../grammar-concat/grammar-concat-ast-node.type';
import { IGrammarExpressionAstNode } from '../../grammar-expression/grammar-expression-ast-node.type';
import { isGrammarByteSequenceAstNode } from '../../grammar-byte-sequence/grammar-byte-sequence-ast-node.type';
import { isGrammarAlternativeAstNode } from '../../grammar-alternative/grammar-alternative-ast-node.type';
import { isGrammarRuleIdentifierAstNode } from '../../grammar-rule-identifier/grammar-rule-identifier-ast-node.type';
import { optimizeGrammarConcat } from './optimize-grammar-concat';
import { IGrammarOptimizedExpressionAstNode } from '../grammar-optimized-expression/grammar-optimized-expression-ast-node.type';
import { optimizeGrammarByteSequence } from './optimize-grammar-byte-sequence';

export function optimizeGrammarExpression(
  node: IGrammarExpressionAstNode,
): IGrammarOptimizedExpressionAstNode {
  if (isGrammarAlternativeAstNode(node)) {
    throw 'TODO';
  } else if (isGrammarByteSequenceAstNode(node)) {
    return optimizeGrammarByteSequence(node);
  } else if (isGrammarConcatAstNode(node)) {
    return optimizeGrammarConcat(node);
  } else if (isGrammarRuleIdentifierAstNode(node)) {
    throw 'TODO';
  } else {
    throw new Error(`Unknown node: ${(node as any).__type__}`);
  }
}
