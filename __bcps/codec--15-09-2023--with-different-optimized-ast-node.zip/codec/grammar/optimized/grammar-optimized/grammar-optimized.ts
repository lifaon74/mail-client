import { IGrammarOptimizedAstNode, GrammarOptimizedAstNodeType } from './grammar-optimized-ast-node.type';
import { IGrammarOptimizedExpressionAstNode } from '../grammar-optimized-expression/grammar-optimized-expression-ast-node.type';

export function GrammarOptimized(
  expressions: readonly IGrammarOptimizedExpressionAstNode[],
): IGrammarOptimizedAstNode {
  return {
    __type__: GrammarOptimizedAstNodeType,
    expressions,
  };
}
