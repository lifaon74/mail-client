import {
  IGrammarOptimizedByteSequenceAstNode,
  GrammarOptimizedByteSequenceAstNodeType,
} from './grammar-optimized-byte-sequence-ast-node.type';

export function GrammarOptimizedByteSequence(
  bytes: Uint8Array,
): IGrammarOptimizedByteSequenceAstNode {
  return {
    __type__: GrammarOptimizedByteSequenceAstNodeType,
    bytes,
  };
}
