import { GrammarOptimizedByteSequence } from './grammar-optimized-byte-sequence';

export const GrammarOptimizedEmpty = GrammarOptimizedByteSequence(new Uint8Array(0));
