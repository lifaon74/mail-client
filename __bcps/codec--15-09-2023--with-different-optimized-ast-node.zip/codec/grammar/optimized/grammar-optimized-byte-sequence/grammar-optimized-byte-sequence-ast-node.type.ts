import { AstNode } from '../../../../../ast/__shared__/ast-node.type';
import { isAstNode } from '../../../../../ast/__shared__/is-ast-node';

export const GrammarOptimizedByteSequenceAstNodeType = 'GrammarOptimizedByteSequence';

export type IGrammarOptimizedByteSequenceAstNodeType = typeof GrammarOptimizedByteSequenceAstNodeType;

export interface IGrammarOptimizedByteSequenceAstNode extends AstNode<IGrammarOptimizedByteSequenceAstNodeType> {
  readonly bytes: Uint8Array;
}

export function isGrammarOptimizedByteSequenceAstNode(
  input: object,
): input is IGrammarOptimizedByteSequenceAstNode {
  return isAstNode<IGrammarOptimizedByteSequenceAstNodeType>(input, GrammarOptimizedByteSequenceAstNodeType);
}

