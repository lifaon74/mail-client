import { GrammarByteSequence } from './grammar-byte-sequence';
import { IGrammarByteSequenceAstNode } from './grammar-byte-sequence-ast-node.type';

export function GrammarByte(
  value: number,
): IGrammarByteSequenceAstNode {
  return GrammarByteSequence(new Uint8Array([value]));
}
