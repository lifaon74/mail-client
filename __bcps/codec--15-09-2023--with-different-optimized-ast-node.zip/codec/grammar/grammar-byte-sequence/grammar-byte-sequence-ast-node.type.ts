import { AstNode } from '../../../../ast/__shared__/ast-node.type';
import { isAstNode } from '../../../../ast/__shared__/is-ast-node';

export const GrammarByteSequenceAstNodeType = 'GrammarByteSequence';

export type IGrammarByteSequenceAstNodeType = typeof GrammarByteSequenceAstNodeType;

export interface IGrammarByteSequenceAstNode extends AstNode<IGrammarByteSequenceAstNodeType> {
  readonly bytes: Uint8Array;
}

export function isGrammarByteSequenceAstNode(
  input: object,
): input is IGrammarByteSequenceAstNode {
  return isAstNode<IGrammarByteSequenceAstNodeType>(input, GrammarByteSequenceAstNodeType);
}

