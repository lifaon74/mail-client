import { IGrammarByteSequenceAstNode, GrammarByteSequenceAstNodeType } from './grammar-byte-sequence-ast-node.type';

export function GrammarByteSequence(
  bytes: Uint8Array | ArrayLike<number> | ArrayBufferLike,
): IGrammarByteSequenceAstNode {
  return {
    __type__: GrammarByteSequenceAstNodeType,
    bytes: (bytes instanceof Uint8Array)
      ? bytes
      : new Uint8Array(bytes),
  };
}
