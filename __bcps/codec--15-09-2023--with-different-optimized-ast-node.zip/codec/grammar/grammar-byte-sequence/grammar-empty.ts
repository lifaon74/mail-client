import { GrammarByteSequence } from './grammar-byte-sequence';

export const GrammarEmpty = GrammarByteSequence(new Uint8Array(0));
