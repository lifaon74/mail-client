import { IGrammarAlternativeAstNode, isGrammarAlternativeAstNode } from '../grammar-alternative/grammar-alternative-ast-node.type';
import { isGrammarByteSequenceAstNode, IGrammarByteSequenceAstNode } from '../grammar-byte-sequence/grammar-byte-sequence-ast-node.type';
import { IGrammarConcatAstNode, isGrammarConcatAstNode } from '../grammar-concat/grammar-concat-ast-node.type';
import {
  IGrammarRuleIdentifierAstNode,
  isGrammarRuleIdentifierAstNode,
} from '../grammar-rule-identifier/grammar-rule-identifier-ast-node.type';

export type IGrammarExpressionAstNode =
  | IGrammarAlternativeAstNode
  | IGrammarByteSequenceAstNode
  | IGrammarConcatAstNode
  | IGrammarRuleIdentifierAstNode
  ;

export function isGrammarExpressionAstNode(
  input: object,
): input is IGrammarExpressionAstNode {
  return isGrammarAlternativeAstNode(input)
    || isGrammarByteSequenceAstNode(input)
    || isGrammarConcatAstNode(input)
    || isGrammarRuleIdentifierAstNode(input)
    ;
}

