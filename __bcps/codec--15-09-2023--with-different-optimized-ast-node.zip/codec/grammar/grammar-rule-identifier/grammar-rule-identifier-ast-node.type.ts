import { AstNode } from '../../../../ast/__shared__/ast-node.type';
import { isAstNode } from '../../../../ast/__shared__/is-ast-node';

export const GrammarRuleIdentifierAstNodeType = 'GrammarRuleIdentifier';

export type IGrammarRuleIdentifierAstNodeType = typeof GrammarRuleIdentifierAstNodeType;

export interface IGrammarRuleIdentifierAstNode extends AstNode<IGrammarRuleIdentifierAstNodeType> {
  readonly name: string;
}

export function isGrammarRuleIdentifierAstNode(
  input: object,
): input is IGrammarRuleIdentifierAstNode {
  return isAstNode<IGrammarRuleIdentifierAstNodeType>(input, GrammarRuleIdentifierAstNodeType);
}
