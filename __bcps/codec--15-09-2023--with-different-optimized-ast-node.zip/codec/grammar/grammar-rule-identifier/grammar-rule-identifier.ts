import { GrammarRuleIdentifierAstNodeType, IGrammarRuleIdentifierAstNode } from './grammar-rule-identifier-ast-node.type';

export function GrammarRuleIdentifier(
  name: string,
): IGrammarRuleIdentifierAstNode {
  return {
    __type__: GrammarRuleIdentifierAstNodeType,
    name,
  };
}
