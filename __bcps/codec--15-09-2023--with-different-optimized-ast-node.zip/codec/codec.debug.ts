import { readableStreamToAsyncIterable } from '@lirx/utils';
import { u8 } from '@lifaon/number-types';
import { writableStreamDisposableContext } from '../disposable/disposable.debug';
import { GrammarRule } from './grammar/grammar-rule/grammar-rule';
import { GrammarConcat } from './grammar/grammar-concat/grammar-concat';
import { GrammarByte } from './grammar/grammar-byte-sequence/grammar-byte';
import { CHAR_0, CHAR_A_LOWER_CASE, CHAR_B_LOWER_CASE, CHAR_1 } from '../../constants/chars/chars.constant';
import { IGrammarAstNode } from './grammar/grammar/grammar-ast-node.type';
import { Grammar } from './grammar/grammar/grammar';
import { ILines } from '../../misc/lines/lines.type';
import { linesToString } from '../../misc/lines/functions/lines-to-string';
import { IGrammarRuleAstNode, isGrammarRuleAstNode } from './grammar/grammar-rule/grammar-rule-ast-node.type';
import { GrammarAlternative } from './grammar/grammar-alternative/grammar-alternative';
import { indentLines } from '../../misc/lines/functions/indent-lines';
import { IGrammarAlternativeAstNode, isGrammarAlternativeAstNode } from './grammar/grammar-alternative/grammar-alternative-ast-node.type';
import { IGrammarConcatAstNode, isGrammarConcatAstNode } from './grammar/grammar-concat/grammar-concat-ast-node.type';
import { IGrammarExpressionAstNode } from './grammar/grammar-expression/grammar-expression-ast-node.type';
import {
  isGrammarRuleIdentifierAstNode,
  IGrammarRuleIdentifierAstNode,
} from './grammar/grammar-rule-identifier/grammar-rule-identifier-ast-node.type';
import { GrammarRuleIdentifier } from './grammar/grammar-rule-identifier/grammar-rule-identifier';
import { optimizeGrammarConcat } from './grammar/optimized/optimize/optimize-grammar-concat';
import {
  IGrammarByteSequenceAstNode,
  isGrammarByteSequenceAstNode,
} from './grammar/grammar-byte-sequence/grammar-byte-sequence-ast-node.type';

/*---------*/
export type byte_t = number;

export type IDecoderResult<GValue> = IteratorResult<void, GValue>;

export type IDecoder<GValue> = Iterator<void, GValue, byte_t>;

export interface IDecoderFactory<GValue> {
  (): IDecoder<GValue>;
}

export type IDecoderGenerator<GValue> = Generator<void, GValue, byte_t>;

export interface IDecoderIterable<GValue> {
  [Symbol.iterator]: IDecoderFactory<GValue>;
}

export type IEncoder = Iterator<byte_t, void, void>;

/*---------*/

// export function textEncoder(
//   input: string,
// ): IEncoder {
//   new TextEncoder().encode(input);
// }

/*---------*/

/*
tutorial: https://tomassetti.me/guide-parsing-algorithms-terminology/

https://en.wikipedia.org/wiki/Backus%E2%80%93Naur_form
https://en.wikipedia.org/wiki/Extended_Backus%E2%80%93Naur_form

https://github.com/dhconnelly/prettybnf
 */

export interface IParseUint8ArrayToAstFunction {
  (
    buffer: Uint8Array,
    index: number,
  ): IParsedUint8ArrayAstNode | null;
}

export interface IParsedUint8ArrayAstNode {
  readonly name: string;
  readonly start: number;
  readonly end: number;
  readonly children: readonly IParsedUint8ArrayAstNode[];
}

export function transpileGrammarAlternativeToJavascriptParseUint8ArrayToAstFunction(
  {
    expressions,
  }: IGrammarAlternativeAstNode,
): ILines {
  return [
    `(buffer, index) => {`,
    ...indentLines([
      ...expressions.flatMap((expression: IGrammarExpressionAstNode, index: number): ILines => {
        return [
          `{`,
          ...indentLines([
            `const result = (`,
            ...indentLines([
              ...transpileGrammarExpressionToJavascriptParseUint8ArrayToAstFunction(expression),
            ]),
            `)(buffer, index);`,
            ``,
            `if (result !== null) {`,
            ...indentLines([
              `return {`,
              ...indentLines([
                `name: 'alternative',`,
                `start: index,`,
                `end: result.end,`,
                `children: [result],`,
              ]),
              `};`,
            ]),
            `}`,
          ]),
          `}`,
          ``,
        ];
      }),
      `return null;`,
    ]),
    `}`,
  ];
}

export function transpileGrammarByteSequenceToJavascriptParseUint8ArrayToAstFunction(
  {
    bytes,
  }: IGrammarByteSequenceAstNode,
): ILines {
  return [
    `(buffer, index) => {`,
    ...indentLines([
      `return (buffer[index] === true) ? {`, // TODO
      ...indentLines([
        `name: 'byte',`,
        `start: index,`,
        `end: index + 1,`,
        `children: [],`,
      ]),
      `} : null;`,
    ]),
    `}`,
  ];
}

export function transpileGrammarByteSequenceToJavascriptEndIndex(
  {
    bytes,
  }: IGrammarByteSequenceAstNode,
  index: string,
): ILines {
  return [
    // `((buffer[${index}] === ${value}) ? (${index} + 1) : -1)`,
  ];
}

export function transpileGrammarConcatToJavascriptParseUint8ArrayToAstFunction(
  {
    expressions,
  }: IGrammarConcatAstNode,
): ILines {
  return [
    `(buffer, index) => {`,
    ...indentLines([
      `const children = new Array(${expressions.length});`,
      `let _index = index;`,
      ``,
      ...expressions.flatMap((expression: IGrammarExpressionAstNode, index: number): ILines => {
        return [
          `{`,
          ...indentLines([
            `const result = (`,
            ...indentLines([
              ...transpileGrammarExpressionToJavascriptParseUint8ArrayToAstFunction(expression),
            ]),
            `)(buffer, _index);`,
            ``,
            `if (result === null) {`,
            ...indentLines([
              `return null;`,
            ]),
            `} else {`, ...indentLines([
              `children[${index}] = result;`,
              `_index = result.end;`,
            ]),
            `}`,
          ]),
          `}`,
          ``,
        ];
      }),
      `return {`,
      ...indentLines([
        `name: 'concat',`,
        `start: index,`,
        `end: _index,`,
        `children,`,
      ]),
      `};`,
    ]),
    `}`,
  ];
}

export function transpileGrammarExpressionToJavascriptParseUint8ArrayToAstFunction(
  node: IGrammarExpressionAstNode,
): ILines {
  if (isGrammarAlternativeAstNode(node)) {
    return transpileGrammarAlternativeToJavascriptParseUint8ArrayToAstFunction(node);
  } else if (isGrammarByteSequenceAstNode(node)) {
    return transpileGrammarByteSequenceToJavascriptParseUint8ArrayToAstFunction(node);
  } else if (isGrammarConcatAstNode(node)) {
    return transpileGrammarConcatToJavascriptParseUint8ArrayToAstFunction(node);
  } else if (isGrammarRuleIdentifierAstNode(node)) {
    return transpileGrammarRuleIdentifierToJavascriptParseUint8ArrayToAstFunction(node);
  } else {
    throw new Error(`Unknown node: ${(node as any).__type__}`);
  }
}

export function transpileGrammarRuleToJavascriptParseUint8ArrayToAstFunction(
  {
    name,
    expression,
  }: IGrammarRuleAstNode,
): ILines {
  return [
    `(buffer, index) => {`,
    ...indentLines([
      `const result = (`,
      ...indentLines([
        ...transpileGrammarExpressionToJavascriptParseUint8ArrayToAstFunction(expression),
      ]),
      `)(buffer, index);`,
      ``,
      `if (result === null) {`,
      ...indentLines([
        `return null;`,
      ]),
      `} else {`,
      ...indentLines([
        `return {`,
        ...indentLines([
          `name: ${JSON.stringify(`rule::${name}`)},`,
          `start: index,`,
          `end: result.end,`,
          `children: [result],`,
        ]),
        `};`,
      ]),
      `}`,
    ]),
    `}`,
  ];
}

export function transpileGrammarRuleIdentifierToJavascriptParseUint8ArrayToAstFunction(
  {
    name,
  }: IGrammarRuleIdentifierAstNode,
): ILines {
  return [
    `(buffer, index) => {`,
    ...indentLines([
      `return rule_${name}(buffer, index);`,
    ]),
    `}`,
  ];
}

export function transpileGrammarToJavascriptParseUint8ArrayToAstFunction(
  {
    rules,
  }: IGrammarAstNode,
): ILines {
  return [
    `() => {`,
    ...indentLines([
      ...rules.flatMap((rule: IGrammarRuleAstNode): ILines => {
        return [
          `const rule_${rule.name} = (`,
          ...indentLines([
            ...transpileGrammarRuleToJavascriptParseUint8ArrayToAstFunction(rule),
          ]),
          `);`,
        ];
      }),
    ]),
    `}`,
  ];
}

// export type IUnknownGrammarAstNode =
//   | IGrammarAstNode
//   | IGrammarAlternativeAstNode
//   | IGrammarByteAstNode
//   | IGrammarConcatAstNode
//   | IGrammarRuleAstNode
//   ;
//
// export function transpileUnknownGrammarToJavascriptParseUint8ArrayToAstFunction(
//   node: IUnknownGrammarAstNode,
// ): ILines {
//   if (isGrammarAlternativeAstNode(node)) {
//     throw 'TODO'; // TODO
//   } else if (isGrammarByteAstNode(node)) {
//     return transpileGrammarByteToJavascriptParseUint8ArrayToAstFunction(node);
//   } else if (isGrammarRuleAstNode(node)) {
//     return transpileGrammarRuleToJavascriptParseUint8ArrayToAstFunction(node);
//   } else {
//     throw new Error(`Unknown node: ${(node as any).__type__}`);
//   }
// }

/*---------*/

// const buffer = [1, 2];
// const a = ((b, i) => {
//   return ((b, i) => b[i] === 5)(b, i)
//     || ((b, i) => b[i] === 6)(b, i + 1)
// })(buffer, 0);
//
// console.log(a);

/*---------*/

export async function codecDebug(): Promise<void> {
  const digit = GrammarRule('digit', GrammarAlternative([GrammarByte(CHAR_0), GrammarByte(CHAR_1)]));
  const alpha_lowercase = GrammarRule('alpha_lowercase', GrammarAlternative([
    GrammarByte(CHAR_A_LOWER_CASE),
    GrammarByte(CHAR_B_LOWER_CASE),
    GrammarRuleIdentifier('digit'),
  ]));

  const grammar = Grammar([
    digit,
    alpha_lowercase,
  ]);

  // console.log(grammar);

  console.log(optimizeGrammarConcat(GrammarConcat([GrammarByte(CHAR_0), GrammarByte(CHAR_1)])));


  // // const lines: ILines = transpileGrammarByteToJavascriptParseUint8ArrayToAstFunction(GrammarByte(CHAR_0));
  // // const lines: ILines = transpileGrammarConcatToJavascriptParseUint8ArrayToAstFunction(GrammarConcat([GrammarByte(CHAR_0), GrammarByte(CHAR_1)]));
  // // const lines: ILines = transpileGrammarAlternativeToJavascriptParseUint8ArrayToAstFunction(GrammarAlternative([GrammarByte(CHAR_0), GrammarByte(CHAR_1)]));
  // const lines: ILines = transpileGrammarRuleToJavascriptParseUint8ArrayToAstFunction(digit);
  // // const lines: ILines = transpileGrammarRuleToJavascriptParseUint8ArrayToAstFunction(alpha_lowercase);
  // // const lines: ILines = transpileGrammarToJavascriptParseUint8ArrayToAstFunction(grammar);
  //
  // const code: string = linesToString(lines);
  //
  // console.log(code);
  //
  // const fnc = new Function('buffer', 'index', `return (${code})(buffer, index);`);
  //
  // console.log(fnc([CHAR_0, CHAR_1], 0));
  // // console.log(fnc([CHAR_A_LOWER_CASE, CHAR_1], 0));

  /*
  expected: {
    name: 'digit',
    start: number;
    children: [
    ]
  }
   */
}
