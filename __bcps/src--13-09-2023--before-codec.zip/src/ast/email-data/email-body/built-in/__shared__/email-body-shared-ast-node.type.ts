import { AstNode } from '../../../../__shared__/ast-node.type';

export interface IEmailBodySharedAstNode<GType extends string> extends AstNode<GType> {

}

