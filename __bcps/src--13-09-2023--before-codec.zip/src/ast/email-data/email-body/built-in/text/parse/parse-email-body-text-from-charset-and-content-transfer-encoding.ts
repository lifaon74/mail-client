import {
  IContentTransferEncoding,
} from '../../../../../email-header/email-header/built-in/content-transfer-encoding/content-transfer-encoding.type';
import { IEmailBodyTextAstNode, EmailBodyTextAstNodeType } from '../email-body-text-ast-node.type';
import { CRLF } from '../../../../../../constants/crlf';
import { ParseError } from '../../../../../../parse-and-serialize/parse-error';
import { parseHexNumber } from '../../../../../../parse-and-serialize/parse-hex-number';
import { CHAR_EQUALS, CHAR_HT, CHAR_SP } from '../../../../../../constants/chars/chars.constant';

// DOC: https://www.w3.org/Protocols/rfc1341/5_Content-Transfer-Encoding.html

export function parseEmailBodyTextFromCharsetAndContentTransferEncoding(
  input: string,
  charset: string,
  contentTransferEncoding: IContentTransferEncoding,
): IEmailBodyTextAstNode {
  let value: string;

  // if (input.endsWith(CRLF)) {
  //   input = input.slice(0, -CRLF_LENGTH)
  // } else {
  //   throw new Error(`Invalid ${EmailBodyTextAstNodeType}`);
  // }

  if (
    (contentTransferEncoding === '7bit')
    || (contentTransferEncoding === '8bit')
    || (contentTransferEncoding === 'binary')
  ) {
    // TODO support multiline
    value = input;
  } else if (contentTransferEncoding === 'quoted-printable') {
    const buffer = new TextEncoder().encode(input);
    value = 'abc';

    ParseError.catch(() => {
      console.log('parseQuotedPrintable', parseQuotedPrintable(buffer));
    });
    // value = input
    //   .replace(
    //     new RegExp(`=([0-9A-Fa-f][0-9A-Fa-f])`, 'g'),
    //     (_, hex: string): string => {
    //       const code: number = parseInt(hex, 16);
    //       console.log(code);
    //       return String.fromCharCode(code);
    //     },
    //   )
    //   .split(CRLF)
    //   .map((chunk: string): string => {
    //     return chunk.trimEnd();
    //   })
    //   .join('\n');
  } else if (contentTransferEncoding === 'base64') {
    value = atob(input.replace(new RegExp(CRLF, 'g'), ''));
  } else {
    throw new Error(`Unknown contentTransferEncoding: ${contentTransferEncoding}`);
  }

  if (charset !== 'utf-8') {
    throw new Error(`Unsupported charset: ${charset}.`); // TODO support more
    // value = new TextDecoder(charset, { fatal: true }).decode(new Uint8Array(String.from));
  }

  return {
    __type__: EmailBodyTextAstNodeType,
    charset,
    encoding: contentTransferEncoding,
    value,
  };
}

/**
 * Converts a "quoted-printable" buffer to a decoded buffer
 * https://www.w3.org/Protocols/rfc1341/5_Content-Transfer-Encoding.html
 */
export function parseQuotedPrintable(
  buffer: Uint8Array,
): Uint8Array {
  let bufferIndex: number = 0;
  const bufferLength: number = buffer.length;

  const output: Uint8Array = new Uint8Array(bufferLength);
  let outputLength: number = 0;

  while (bufferIndex < bufferLength) {
    const char: number = buffer[bufferIndex];

    if (char === CHAR_EQUALS) { // rule #1
      const decodedChar: number = ParseError.wrap(parseHexNumber, buffer, bufferIndex + 1, bufferIndex + 3);
      bufferIndex += 3;
      console.log(decodedChar);
    } else if (isQuotedPrintableChar(char)) { // rule #2
      output[bufferIndex++] = char;
    } else if ( // rule #3
      (char === CHAR_HT)
      || (char === CHAR_SP)
    ) {
      if (
        (bufferIndex + 1 === buffer.length)
        || isQuotedPrintableChar(buffer[bufferIndex])
      ) {
        output[bufferIndex++] = char;
      } else {
        throw new ParseError(
          `A tab or space must be followed by a printable char`,
          buffer,
          bufferIndex + 1,
          bufferIndex + 2,
        );
      }
    } else {
      throw ParseError.invalidChar(buffer, bufferIndex);
    }
  }

  const a = output.subarray(0, outputLength);
  console.log('a', a);

  throw 'TODO';
}

function isQuotedPrintableChar(
  char: number,
): boolean {
  return ((33 <= char) && (char <= 60))
    || ((62 <= char) && (char <= 126));
}

