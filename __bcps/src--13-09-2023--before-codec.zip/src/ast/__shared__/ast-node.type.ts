export interface AstNode<GType extends string> {
  readonly __type__: GType;
}

