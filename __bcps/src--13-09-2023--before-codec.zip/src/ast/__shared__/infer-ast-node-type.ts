import { IGenericAstNode } from './generic-ast-node.type';
import { AstNode } from './ast-node.type';

export type InferAstNodeType<GAstNode extends IGenericAstNode> =
  GAstNode extends AstNode<infer GType>
    ? GType
    : never;
