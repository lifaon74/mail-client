import { AstNode } from './ast-node.type';

export type IGenericAstNode = AstNode<any>;
