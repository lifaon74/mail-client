import { AstNode } from '../../../../__shared__/ast-node.type';

export interface IEmailHeaderSharedAstNode<GType extends string, GKey extends string> extends AstNode<GType> {
  readonly key: GKey;
}
