import { AstNode } from '../../../__shared__/ast-node.type';

export const MimeTypeTypeAstNodeType = 'MimeTypeType';

export type IMimeTypeTypeAstNodeType = typeof MimeTypeTypeAstNodeType;

export interface IMimeTypeTypeAstNode extends AstNode<IMimeTypeTypeAstNodeType> {
  readonly value: string;
}



