import { AstNode } from '../../../../../../../__shared__/ast-node.type';

export const MimeTypeParameterKeyAstNodeType = 'MimeTypeParameterKey';

export type IMimeTypeParameterKeyAstNodeType = typeof MimeTypeParameterKeyAstNodeType;

export interface IMimeTypeParameterKeyAstNode extends AstNode<IMimeTypeParameterKeyAstNodeType> {
  readonly value: string;
}



