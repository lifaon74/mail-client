import { AstNode } from '../../../../__shared__/ast-node.type';

export const EmailContactNameAstNodeType = 'EmailContactName';

export type IEmailContactNameAstNodeType = typeof EmailContactNameAstNodeType;

export interface IEmailContactNameAstNode extends AstNode<IEmailContactNameAstNodeType> {
  readonly value: string;
}



