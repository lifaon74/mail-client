import { IEmailContactNameAstNode } from './email-contact-name-ast-node.type';

/** FUNCTION **/

export function serializeEmailContactName(
  input: IEmailContactNameAstNode,
): string {
  // TODO
  return input.value;
}
