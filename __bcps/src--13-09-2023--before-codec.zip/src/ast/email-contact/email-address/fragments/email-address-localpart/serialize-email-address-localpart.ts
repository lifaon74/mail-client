import { IEmailAddressLocalpartAstNode } from './email-address-localpart-ast-node.type';

/** FUNCTION **/

export function serializeEmailAddressLocalpart(
  input: IEmailAddressLocalpartAstNode,
): string {
  // TODO
  return input.value;
}
