import { AstNode } from '../../../../__shared__/ast-node.type';

export const EmailAddressLocalpartAstNodeType = 'EmailAddressLocalpart';

export type IEmailAddressLocalpartAstNodeType = typeof EmailAddressLocalpartAstNodeType;

export interface IEmailAddressLocalpartAstNode extends AstNode<IEmailAddressLocalpartAstNodeType> {
  readonly value: string;
}



