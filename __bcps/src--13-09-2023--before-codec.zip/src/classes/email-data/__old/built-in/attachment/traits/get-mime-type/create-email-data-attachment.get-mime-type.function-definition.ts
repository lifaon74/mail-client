import { IMimeType } from '../../../../../mime-type/mime-type.type';

export interface IEmailDataAttachmentGetMimeTypeFunction {
  (): IMimeType;
}
