export const HEADER_BCC_KEY_NAME = 'Bcc';
