import { IEmailContactListToStringFunction } from './email-contact-list.to-string.function-definition';

export interface IEmailContactListToStringTrait {
  toString: IEmailContactListToStringFunction;
}
