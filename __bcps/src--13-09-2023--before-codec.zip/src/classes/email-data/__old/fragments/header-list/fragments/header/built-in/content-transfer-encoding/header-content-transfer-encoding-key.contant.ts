export const HEADER_CONTENT_TRANSFER_ENCODING_KEY_NAME = 'Content-Transfer-Encoding';
