export const HEADER_SENDER_KEY_NAME = 'Sender';
