export interface ISMTPDataContentGetBodyFunction {
  (): string;
}
