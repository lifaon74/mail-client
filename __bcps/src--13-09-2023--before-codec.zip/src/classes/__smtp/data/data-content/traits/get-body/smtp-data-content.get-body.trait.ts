import { ISMTPDataContentGetBodyFunction } from './smtp-data-content.get-body.function-definition';

export interface ISMTPDataContentGetBodyTrait {
  getBody: ISMTPDataContentGetBodyFunction;
}
