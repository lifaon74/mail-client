RFC: https://www.rfc-editor.org/rfc/rfc6838.html

https://en.wikipedia.org/wiki/Media_type
https://www.iana.org/assignments/media-types/media-types.xhtml
