// export interface IParseErrorOptions {
//   buffer: Uint8Array;
//   index: number;
//   message?: string;
//   cause?: any;
// }

export class ParseError extends Error {
  static invalidChar(
    buffer: Uint8Array,
    index: number,
  ): ParseError {
    return new ParseError(
      `Invalid char.`,
      buffer,
      index,
      index + 1,
    );
  }


  static slice(
    buffer: Uint8Array,
    start: number,
    end: number,
  ): Uint8Array {
    if (buffer.length < end) {
      throw new ParseError(
        `Not enough bytes: ${end - start} expected but ${end - buffer.length} found.`,
        buffer,
        start,
        end,
      );
    } else {
      return buffer.subarray(start, end);
    }
  }

  static wrap<GResult>(
    callback: (buffer: Uint8Array) => GResult,
    buffer: Uint8Array,
    start: number,
    end: number,
  ): GResult {
    try {
      return callback(
        ParseError.slice(buffer, start, end),
      );
    } catch (error: unknown) {
      if (error instanceof ParseError) {
        throw new ParseError(
          error.message,
          buffer,
          error.start + start,
          error.end + start,
          { cause: error },
        );
      } else {
        throw error;
      }
    }
  }

  static try(
    callbacks: ArrayLike<() => void>,
    onError: () => never,
  ): void {
    for (let i = 0, l = callbacks.length; i < l; i++) {
      try {
        return callbacks[i]();
      } catch (error: unknown) {
        if (!(error instanceof ParseError)) {
          throw error;
        }
      }
    }
    onError();
  }

  static catch(
    callback: () => void,
    extra: number = 30,
  ): void {
    try {
      return callback();
    } catch (error: unknown) {
      if (error instanceof ParseError) {
        console.groupCollapsed(`${error.name}: ${error.message}`);
        console.error(error);
        console.log(`at index ${error.start} of:`);
        console.log(error.buffer);

        const chunkAStyle: string = '';
        const chunkBStyle: string = 'color: red; font-weight: bold';
        const chunkCStyle: string = 'color: rgba(255, 0, 0, 0.7);';

        const chunkA: Uint8Array = error.buffer.slice(Math.max(0, error.start - extra), error.start);
        const chunkB: Uint8Array = error.buffer.slice(error.start, error.end);
        const chunkC: Uint8Array = error.buffer.slice(error.end + 1, error.end + extra);

        console.log(`%c...${chunkA.join(', ')}, %c${chunkB.join(', ')}, %c${chunkC.join(', ')}...`, chunkAStyle, chunkBStyle, chunkCStyle);
        console.log(`%c...${new TextDecoder().decode(chunkA)}%c${new TextDecoder().decode(chunkB)}%c${new TextDecoder().decode(chunkC)}...`, chunkAStyle, chunkBStyle, chunkCStyle);
        console.groupEnd();
      } else {
        throw error;
      }
    }
  }

  readonly buffer: Uint8Array;
  readonly start: number;
  readonly end: number;

  constructor(
    message: string,
    buffer: Uint8Array,
    start: number,
    end: number,
    options?: any,
  ) {
    super(message, options);
    this.buffer = buffer;
    this.start = start;
    this.end = end;
    this.name = this.constructor.name;
  }
}
