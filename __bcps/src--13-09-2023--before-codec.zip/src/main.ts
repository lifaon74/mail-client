import { debug } from './__debug/debug';

function main(): void {
  debug();
}

main();
