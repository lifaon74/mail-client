import { readableStreamToAsyncIterable } from '@lirx/utils';
import { u8 } from '@lifaon/number-types';
import { writableStreamDisposableContext } from '../disposable/disposable.debug';

/*---------*/

export const DONE = Symbol('DONE');
export type IDone = typeof DONE;


/*---------*/


export interface IDecoder<GValue> {
  (
    byte: number,
  ): GValue | IDone;
}

export interface IEncoder {
  (): number | IDone;
}


/*---------*/

export function createEncoderFromIterator(
  iterator: Iterator<number>,
): IEncoder {
  return () => {

  };
}

/*---------*/

// export function textEncoder(
//   input: string,
// ): IEncoder {
//   new TextEncoder().encode(input);
// }


/*---------*/

export async function codecDebug(): Promise<void> {
  const a = function *() {
    return 6;
  };

  console.log(a().next());
}
