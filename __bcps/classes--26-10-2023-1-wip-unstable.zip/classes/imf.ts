import { IMFHeaders } from './email/email-headers/email-headers.class';

export class IMFData {
  constructor(
    public readonly headers: IMFHeaders,
    public readonly body: string,
  ) {
  }

  text(): string {

  }
}


export class IMFTextData {

}


const a = new Request();
