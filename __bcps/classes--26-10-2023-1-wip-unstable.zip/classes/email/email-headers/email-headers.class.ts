import { IWellKnownEmailHeaderNames } from './well-known/well-known-email-header-names.type';
import { CRLF } from '../../../constants/crlf';

/*
DOC:

- Common Internet Message Headers: https://datatracker.ietf.org/doc/html/rfc2076
- Multipurpose Internet Mail Extensions (MIME),
Part One: Format of Internet Message Bodies
https://datatracker.ietf.org/doc/html/rfc2045


 */

/** TYPES **/

export type IEmailHeaderKey =
  | IWellKnownEmailHeaderNames
  | string
  ;

export type IEmailHeaderTuple = readonly [
  key: IEmailHeaderKey,
  value: string,
];

export type IClassicContentTransferEncoding =
  | '7bit'
  | '8bit'
  | 'binary'
  | 'quoted-printable'
  | 'base64'
  ;

export type IContentTransferEncoding =
  | IClassicContentTransferEncoding
  | string
  ;

/** CLASS **/

export class IMFHeaders {
  static parse(
    input: string,
  ): IMFHeaders {
    const rawHeaders: string[] = [];

    const appendLine = (
      line: string,
    ): void => {
      if (
        line.startsWith(' ')
        || line.startsWith('\t')
      ) {
        if (rawHeaders.length === 0) {
          throw new Error(`Not an header list`);
        } else {
          rawHeaders[rawHeaders.length - 1] += line;
        }
      } else {
        rawHeaders.push(line);
      }
    };

    let position: number = 0;

    while (true) {
      const index: number = input.indexOf(CRLF, position);
      if (index === -1) {
        appendLine(input.slice(position));
        break;
      } else {
        appendLine(input.slice(position, index));
        position = index + 2;
      }
    }

    const emailHeaders = new IMFHeaders();

    for (let i = 0, l = rawHeaders.length; i < l; i++) {
      const header: string = rawHeaders[i];
      const index: number = header.indexOf(': ');

      // TODO improve parsing
      if (index === -1) {
        if (header.endsWith(':')) { // empty header
          emailHeaders.set(
            header.slice(0, -1),
            '',
          );
        } else {
          throw new Error(`Invalid email header: ${JSON.stringify(header)}`);
        }
      } else {
        emailHeaders.set(
          header.slice(0, index),
          header.slice(index + 2),
        );
      }
    }

    return emailHeaders;
  }

  readonly #headers: Map<string, string>;

  constructor(
    input: Iterable<IEmailHeaderTuple> = [],
  ) {
    this.#headers = new Map<string, string>(input);
  }

  /** MAP **/

  get size(): number {
    return this.#headers.size;
  }

  has(
    key: IEmailHeaderKey,
  ): boolean {
    return this.#headers.has(key);
  }

  get(
    key: IEmailHeaderKey,
  ): string | undefined {
    return this.#headers.get(key);
  }

  set(
    key: IEmailHeaderKey,
    value: string,
  ): this {
    this.#headers.set(key, value);
    return this;
  }

  delete(
    key: IEmailHeaderKey,
  ): boolean {
    return this.#headers.delete(key);
  }

  clear(): void {
    this.#headers.clear();
  }

  keys(): IterableIterator<string> {
    return this.#headers.keys();
  }

  values(): IterableIterator<string> {
    return this.#headers.values();
  }

  entries(): IterableIterator<IEmailHeaderTuple> {
    return this.#headers.entries();
  }

  [Symbol.iterator](): IterableIterator<IEmailHeaderTuple> {
    return this.entries();
  }

  toString(): string {
    let output: string = '';

    const iterator: Iterator<IEmailHeaderTuple> = this.entries();
    let result: IteratorResult<IEmailHeaderTuple>;
    while (!(result = iterator.next()).done) {
      const [key, value]: IEmailHeaderTuple = result.value;

      if (output !== '') {
        output += CRLF;
      }

      output += `${key}: ${value}`;
    }

    return output;
  }
}

