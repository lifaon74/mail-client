import { EmailHeaderContentTransferEncoding } from '../email-header.content-transfer-encoding.type';

export const EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_BASE64_CONSTANT = new EmailHeaderContentTransferEncoding('base64');
