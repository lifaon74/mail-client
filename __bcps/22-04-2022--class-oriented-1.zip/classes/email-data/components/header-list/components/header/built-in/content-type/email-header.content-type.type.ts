import { MimeType } from '../../../../../../../mime-type/mime-type.class';
import { EmailHeader } from '../../email-header.class';

export class EmailHeaderContentType extends EmailHeader {
  constructor(
    public readonly mimeType: MimeType,
  ) {
    super(
      'Content-Type',
      mimeType.toString(),
    );
  }
}
