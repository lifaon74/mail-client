import {
  MimeTypeMultipartAlternative,
} from '../../../../../../../../../mime-type/built-in/multipart/mime-type.multipart-alternative.class';
import {
  IGenerateBoundaryOptions,
} from '../../../../../../../../../mime-type/components/mime-type-parameter-list/components/mime-type-parameter/built-in/boundary/generate-boundary';
import { EmailHeaderContentTypeMultipart } from './email-header.content-type.multipart.class';

export class EmailHeaderContentTypeMultipartAlternative extends EmailHeaderContentTypeMultipart {
  static override generate(
    options?: IGenerateBoundaryOptions,
  ): EmailHeaderContentTypeMultipartAlternative {
    return new EmailHeaderContentTypeMultipartAlternative(
      MimeTypeMultipartAlternative.generate(options),
    );
  }

  constructor(
    mimeType: MimeTypeMultipartAlternative,
  ) {
    super(mimeType);
  }
}

