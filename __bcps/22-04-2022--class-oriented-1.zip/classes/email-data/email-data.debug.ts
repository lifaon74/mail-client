import { EmailDataMultipartAlternative } from './built-in/multipart/email-data.multipart-alternative.class';
import { EmailDataMultipartMixed } from './built-in/multipart/email-data.multipart-mixed.class';
import { EmailData } from './email-data.class';

export async function emailDataDebug(): Promise<void> {
  // const emailData: EmailData = new EmailData(
  //   new EmailHeaderList([
  //     EmailHeaderDate.now(),
  //     EMAIL_HEADER_CONTENT_TYPE_TEXT_PLAIN_UTF8_CONSTANT,
  //     EmailHeaderContentTypeMultipartAlternative.generate(),
  //   ]),
  //   new EmailBody('abc'),
  // );

  // mimeTypeParameterBoundaryGenerate
  // const emailData: EmailData = new EmailDataTextPlain('abc');

  // const emailData: EmailData = EmailDataMultipartAlternative.fromTextAndHTML(
  //   'text',
  //   'html',
  // );

  const emailData: EmailData = await EmailDataMultipartMixed.fromFiles([
    new File(['abc'], 'file.txt', { type: 'text/plain' }),
  ]);

  // TODO continue here

  console.log(emailData);
  console.log(emailData.toString());
}
