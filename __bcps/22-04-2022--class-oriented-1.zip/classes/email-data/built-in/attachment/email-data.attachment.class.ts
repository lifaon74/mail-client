import { MimeType } from '../../../mime-type/mime-type.class';
import { EmailBody } from '../../components/body/email-body.class';
import {
  EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_BASE64_CONSTANT,
} from '../../components/header-list/components/header/built-in/content-transfer-encoding/built-in/email-header.content-transfer-encoding.base64.constant';
import {
  EMAIL_HEADER_CONTENT_TYPE_TEXT_PLAIN_UTF8_CONSTANT,
} from '../../components/header-list/components/header/built-in/content-type/built-in/email-header.content-type.text-plain.utf8.constant';
import {
  EmailHeaderContentType
} from '../../components/header-list/components/header/built-in/content-type/email-header.content-type.type';
import { EmailHeaderList } from '../../components/header-list/email-header-list.class';
import { EmailData } from '../../email-data.class';

export class EmailDataAttachment extends EmailData {
  static fromFile(
    file: File,
  ): Promise<EmailDataAttachment> {
    return file.text()
      .then((content: string): EmailDataAttachment => {
        throw 'TODO';
        // const mimeType: MimeType = MimeType.fromString(file.type);
        // if (!mimeType.parameters.map.has('name')) {
        //   mimeType.parameters.map.set('name');
        // }
        // return new EmailAttachment(
        //   (typeof name === 'string')
        //     ? ASCIIString.fromUnsafeString(name)
        //     : name,
        //   MimeType.fromString(blob.type),
        //   new Uint8Array(buffer),
        // );
      });
  }

  constructor(
    public readonly content: string,
  ) {
    super(
      new EmailHeaderList([
        new EmailHeaderContentType(
          new MimeType(),
        ),
        // Content-Disposition: attachment; filename="test.bin"
        EMAIL_HEADER_CONTENT_TRANSFER_ENCODING_BASE64_CONSTANT,
      ]),
      EmailBody.fromTextAsBase64(content),
    );
  }
}

