import {
  EmailHeaderContentTypeMultipartMixed,
} from '../../components/header-list/components/header/built-in/content-type/built-in/multipart/email-header.content-type.multipart-mixed.class';
import { EmailDataAttachment } from '../attachment/email-data.attachment.class';
import { EmailDataMultipart, IEmailDataMultipartContent } from './email-data.multipart.class';

export class EmailDataMultipartMixed extends EmailDataMultipart {

  static fromFiles(
    files: readonly File[],
  ): Promise<EmailDataMultipartMixed> {
    return Promise.all(
      files.map((file: File): Promise<EmailDataAttachment> => {
        return EmailDataAttachment.fromFile(file);
      }),
    )
      .then((attachments: EmailDataAttachment[]): EmailDataMultipartMixed => {
        return new EmailDataMultipartMixed(
          attachments,
        );
      });
  }

  constructor(
    content: IEmailDataMultipartContent,
  ) {
    super(
      EmailHeaderContentTypeMultipartMixed.generate(),
      content,
    );
  }
}

