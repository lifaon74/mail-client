import { CRLF } from '../../../../constants/crlf';
import { EmailBody } from '../../components/body/email-body.class';
import {
  EmailHeaderContentTypeMultipart,
} from '../../components/header-list/components/header/built-in/content-type/built-in/multipart/email-header.content-type.multipart.class';
import { EmailHeaderList } from '../../components/header-list/email-header-list.class';
import { EmailData } from '../../email-data.class';

export type IEmailDataMultipartContent = readonly EmailData[];

export class EmailDataMultipart extends EmailData {

  constructor(
    public readonly contentTypeHeader: EmailHeaderContentTypeMultipart,
    public readonly content: IEmailDataMultipartContent,
  ) {
    const boundary: string = contentTypeHeader.mimeType.parameters.items[0].boundary;
    const boundaryPrefixed: string = `--${boundary}`;

    super(
      new EmailHeaderList([
        contentTypeHeader,
      ]),
      new EmailBody(
        content
          .map((data: EmailData): string => {
            return boundaryPrefixed + CRLF
              + data.toString() + CRLF
              + CRLF;
          })
          .join('')
        + `--${boundary}--`,
      ),
    );
  }
}

