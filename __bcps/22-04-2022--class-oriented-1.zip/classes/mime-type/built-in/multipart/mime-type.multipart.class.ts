import {
  MimeTypeParameterListWithBoundary,
} from '../../components/mime-type-parameter-list/built-in/mime-type-parameter-list.with-boundary.class';
import {
  IGenerateBoundaryOptions,
} from '../../components/mime-type-parameter-list/components/mime-type-parameter/built-in/boundary/generate-boundary';
import { MimeType } from '../../mime-type.class';

export class MimeTypeMultipart extends MimeType {

  static generate(
    subtype: string,
    options?: IGenerateBoundaryOptions,
  ): MimeTypeMultipart {
    return new MimeTypeMultipart(
      subtype,
      MimeTypeParameterListWithBoundary.generate(options),
    );
  }

  declare readonly parameters: MimeTypeParameterListWithBoundary;

  constructor(
    subtype: string,
    parameters: MimeTypeParameterListWithBoundary,
  ) {
    super(
      'multipart',
      subtype,
      parameters,
    );
  }
}
