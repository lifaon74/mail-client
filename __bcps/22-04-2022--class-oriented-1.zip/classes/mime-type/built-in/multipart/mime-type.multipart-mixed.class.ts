import {
  MimeTypeParameterListWithBoundary,
} from '../../components/mime-type-parameter-list/built-in/mime-type-parameter-list.with-boundary.class';
import {
  IGenerateBoundaryOptions,
} from '../../components/mime-type-parameter-list/components/mime-type-parameter/built-in/boundary/generate-boundary';
import { MimeTypeMultipart } from './mime-type.multipart.class';

export class MimeTypeMultipartMixed extends MimeTypeMultipart {

  static override generate(
    options?: IGenerateBoundaryOptions,
  ): MimeTypeMultipartMixed {
    return new MimeTypeMultipartMixed(
      MimeTypeParameterListWithBoundary.generate(options),
    );
  }

  constructor(
    parameters: MimeTypeParameterListWithBoundary,
  ) {
    super(
      'mixed',
      parameters,
    );
  }
}
