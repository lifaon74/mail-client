import { MimeTypeParameter } from '../components/mime-type-parameter-list/components/mime-type-parameter/mime-type-parameter.class';
import { MimeTypeParameterList } from '../components/mime-type-parameter-list/mime-type-parameter-list.class';
import { MimeType } from '../mime-type.class';

export const MIME_TYPE_TEXT_PLAIN_UTF8_CONSTANT: MimeType = new MimeType(
  'text',
  'plain',
  new MimeTypeParameterList([
    new MimeTypeParameter('charset', 'utf8'),
  ]),
);
