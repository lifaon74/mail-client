import { HTTP_TOKEN_PATTERN } from '../../../../constants/http-token-pattern.constant';
import { MimeTypeParameter } from './components/mime-type-parameter/mime-type-parameter.class';

const NAME_AND_VALUE_REGEXP: RegExp = new RegExp(`\\s*(${HTTP_TOKEN_PATTERN}+)(?:=(${HTTP_TOKEN_PATTERN}+|(?:"(?:${HTTP_TOKEN_PATTERN}|(?:\\\\")|(?:\\\\\\\\))+")))?\\s*(?:;|$)`, 'g');


export class MimeTypeParameterList {

  static fromString(
    input: string,
  ): MimeTypeParameterList {
    let match: RegExpExecArray | null;
    let index: number = 0;
    const items: MimeTypeParameter[] = [];

    while ((match = NAME_AND_VALUE_REGEXP.exec(input)) !== null) {
      if ((index === 0) && (match.index !== 0)) {
        throw new Error(`Invalid parameters`);
      }
      items.push(
        new MimeTypeParameter(
          match[1],
          match[2] ?? '',
        )
      );
      index = match.index + match[0].length;
      console.log(match);
    }

    if (index !== input.length) {
      throw new Error(`Invalid parameters`);
    }
    console.log(index, input.length);


    return new MimeTypeParameterList(items);
  }

  public readonly map: ReadonlyMap<string, string>;

  constructor(
    public readonly items: readonly MimeTypeParameter[],
  ) {
    this.map = new Map<string, string>(
      this.items.map(({ key, value }): [string, string] => {
        return [key, value];
      }),
    );
  }

  get size(): number {
    return this.items.length;
  }

  toString(): string {
    return this.items.map((parameter: MimeTypeParameter) => parameter.toString())
      .join('; ');
  }
}
