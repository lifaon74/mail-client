export class MimeTypeParameter {
  constructor(
    public readonly key: string,
    public readonly value: string,
  ) {
  }

  toString(): string {
    return (this.value.length === 0)
      ? this.key
      : `${this.key}=${this.value}`;
  }
}
