import { MimeTypeMultipartAlternative } from './built-in/multipart/mime-type.multipart-alternative.class';
import {
  MimeTypeParameterBoundary,
} from './components/mime-type-parameter-list/components/mime-type-parameter/built-in/boundary/mime-type-parameter.boundary.type';
import { MimeTypeParameterList } from './components/mime-type-parameter-list/mime-type-parameter-list.class';
import { MimeType } from './mime-type.class';

export function mimeTypeDebug(): void {
  // const data: MimeType = new MimeType(
  //   'multipart',
  //   'mixed',
  //   new MimeTypeParameterList([
  //     MimeTypeParameterBoundary.generate(),
  //   ]),
  // );

  // const data = MimeTypeMultipartAlternative.generate();
  // const data = MimeType.fromString(`application/octet-stream; name="test.bin"`);
  // const data = MimeTypeParameterList.fromString(`name="test.bin"`);
  const data = MimeTypeParameterList.fromString(`name="test\\".bin"; abc="def"; bob `);
  // const data = MimeTypeParameterList.fromString(`abc="def"`);
  // const data = MimeTypeParameterList.fromString(`abc="def" ;`);
  // const data = MimeTypeParameterList.fromString(`abc="def`);
  // const data = MimeTypeParameterList.fromString(`abc="def"; a=`);
  // const data = MimeTypeParameterList.fromString(`name="test\\\\".bin"`);

  console.log(data);
  console.log(data.toString());
}
