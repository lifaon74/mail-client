import { HTTP_TOKEN_PATTERN } from '../../constants/http-token-pattern.constant';
import {
  MIME_TYPE_PARAMETER_LIST_NONE_CONSTANT,
} from './components/mime-type-parameter-list/constants/mime-type-parameter-list.none.constant';
import { MimeTypeParameterList } from './components/mime-type-parameter-list/mime-type-parameter-list.class';

const TYPE_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const TYPE_REGEXP = new RegExp(`^${TYPE_PATTERN}$`, 'g');

const SUBTYPE_PATTERN = `${HTTP_TOKEN_PATTERN}+`;
const SUBTYPE_REGEXP = new RegExp(`^${TYPE_PATTERN}$`, 'g');

const TYPE: RegExp = new RegExp(`^\s*(${HTTP_TOKEN_PATTERN}+)/(${HTTP_TOKEN_PATTERN}+)\s*$`, 'g');
const TYPE_AND_SUBTYPE_REGEXP: RegExp = new RegExp(`^\s*(${HTTP_TOKEN_PATTERN}+)/(${HTTP_TOKEN_PATTERN}+)\s*$`, 'g');

export class MimeType {

  static fromString(
    input: string,
  ): MimeType {
    const index: number = input.indexOf(';');
    let typeAndSubtype: string;
    let parameters: string;

    if (index === -1) {
      typeAndSubtype = input;
      parameters = '';
    } else {
      typeAndSubtype = input.slice(0, index);
      parameters = input.slice(index + 1);
    }

    const match: RegExpExecArray | null = TYPE_AND_SUBTYPE_REGEXP.exec(typeAndSubtype);
    if (match === null) {
      throw new Error(`Invalid type or subtype`);
    } else {
      return new MimeType(
        match[1],
        match[2],
        (parameters === '')
          ? MIME_TYPE_PARAMETER_LIST_NONE_CONSTANT
          : MimeTypeParameterList.fromString(parameters),
      );
    }
  }

  protected _type!: string;
  protected _subtype!: string;

  constructor(
    type: string,
    subtype: string,
    public readonly parameters: MimeTypeParameterList,
  ) {
    this._type = '';
    this.type = type;
  }

  get type(): string {
    return this._type;
  }

  set type(value: string) {
    if (TYPE_REGEXP.test(value)) {
      this._type = value;
    } else {
      throw new Error(`Invalid type`);
    }
  }


  get subtype(): string {
    return this._subtype;
  }

  set subtype(value: string) {
    if (SUBTYPE_REGEXP.test(value)) {
      this._type = value;
    } else {
      throw new Error(`Invalid subtype`);
    }
  }


  toString(): string {
    const parametersString: string = (this.parameters.size === 0)
      ? ''
      : `; ${this.parameters.toString()}`;
    return `${this.type}/${this.subtype}${parametersString}`;
  }
}

